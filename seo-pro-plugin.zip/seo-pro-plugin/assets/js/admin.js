/* SEO Pro Admin JavaScript */
jQuery(document).ready(function ($) {
  // Admin scripts here
  console.log('SEO Pro Admin loaded');
});
