<?php
/**
 * Admin Settings - Main admin panel
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Admin_Settings {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }
    
    /**
     * Add admin menu
     */
    public function add_menu() {
        add_menu_page(
            __( 'SEO Pro', 'seo-pro' ),
            __( 'SEO Pro', 'seo-pro' ),
            'manage_options',
            'seo-pro',
            array( $this, 'render_dashboard' ),
            'dashicons-chart-line',
            30
        );
        
        add_submenu_page(
            'seo-pro',
            __( 'Dashboard', 'seo-pro' ),
            __( 'Dashboard', 'seo-pro' ),
            'manage_options',
            'seo-pro',
            array( $this, 'render_dashboard' )
        );
        
        add_submenu_page(
            'seo-pro',
            __( 'General Settings', 'seo-pro' ),
            __( 'General', 'seo-pro' ),
            'manage_options',
            'seo-pro-general',
            array( $this, 'render_general_settings' )
        );
        
        add_submenu_page(
            'seo-pro',
            __( 'Local SEO', 'seo-pro' ),
            __( 'Local SEO', 'seo-pro' ),
            'manage_options',
            'seo-pro-local',
            array( $this, 'render_local_seo' )
        );
        
        add_submenu_page(
            'seo-pro',
            __( 'Social Media', 'seo-pro' ),
            __( 'Social Media', 'seo-pro' ),
            'manage_options',
            'seo-pro-social',
            array( $this, 'render_social_media' )
        );
        
        add_submenu_page(
            'seo-pro',
            __( 'Auto Linking', 'seo-pro' ),
            __( 'Auto Linking', 'seo-pro' ),
            'manage_options',
            'seo-pro-linking',
            array( $this, 'render_auto_linking' )
        );
        
        add_submenu_page(
            'seo-pro',
            __( 'Redirects', 'seo-pro' ),
            __( 'Redirects', 'seo-pro' ),
            'manage_options',
            'seo-pro-redirects',
            array( $this, 'render_redirects' )
        );
        
        add_submenu_page(
            'seo-pro',
            __( '404 Monitor', 'seo-pro' ),
            __( '404 Monitor', 'seo-pro' ),
            'manage_options',
            'seo-pro-404',
            array( $this, 'render_404_monitor' )
        );
        
        add_submenu_page(
            'seo-pro',
            __( 'Sitemap', 'seo-pro' ),
            __( 'Sitemap', 'seo-pro' ),
            'manage_options',
            'seo-pro-sitemap',
            array( $this, 'render_sitemap' )
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        // General
        register_setting( 'seo_pro_general', 'seo_separator' );
        register_setting( 'seo_pro_general', 'seo_default_image' );
        
        // Local SEO
        register_setting( 'seo_pro_local', 'seo_business_type' );
        register_setting( 'seo_pro_local', 'seo_phone' );
        register_setting( 'seo_pro_local', 'seo_street_address' );
        register_setting( 'seo_pro_local', 'seo_locality' );
        register_setting( 'seo_pro_local', 'seo_region' );
        register_setting( 'seo_pro_local', 'seo_postal_code' );
        register_setting( 'seo_pro_local', 'seo_latitude' );
        register_setting( 'seo_pro_local', 'seo_longitude' );
        register_setting( 'seo_pro_local', 'seo_price_range' );
        register_setting( 'seo_pro_local', 'seo_geo_region' );
        register_setting( 'seo_pro_local', 'seo_geo_placename' );
        register_setting( 'seo_pro_local', 'seo_geo_position' );
        
        // Social Media
        register_setting( 'seo_pro_social', 'seo_facebook_url' );
        register_setting( 'seo_pro_social', 'seo_twitter_url' );
        register_setting( 'seo_pro_social', 'seo_twitter_username' );
        register_setting( 'seo_pro_social', 'seo_instagram_url' );
        register_setting( 'seo_pro_social', 'seo_linkedin_url' );
        
        // Auto Linking
        register_setting( 'seo_pro_linking', 'seo_auto_link_keywords' );
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'seo-pro' ) === false ) {
            return;
        }
        
        wp_enqueue_style( 'seo-pro-admin', SEO_PRO_PLUGIN_URL . 'assets/css/admin.css', array(), SEO_PRO_VERSION );
        wp_enqueue_script( 'seo-pro-admin', SEO_PRO_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), SEO_PRO_VERSION, true );
    }
    
    /**
     * Render dashboard
     */
    public function render_dashboard() {
        require_once SEO_PRO_PLUGIN_DIR . 'admin/views/dashboard.php';
    }
    
    /**
     * Render general settings
     */
    public function render_general_settings() {
        require_once SEO_PRO_PLUGIN_DIR . 'admin/views/general-settings.php';
    }
    
    /**
     * Render local SEO
     */
    public function render_local_seo() {
        require_once SEO_PRO_PLUGIN_DIR . 'admin/views/local-seo.php';
    }
    
    /**
     * Render social media
     */
    public function render_social_media() {
        require_once SEO_PRO_PLUGIN_DIR . 'admin/views/social-media.php';
    }
    
    /**
     * Render auto linking
     */
    public function render_auto_linking() {
        require_once SEO_PRO_PLUGIN_DIR . 'admin/views/auto-linking.php';
    }
    
    /**
     * Render redirects
     */
    public function render_redirects() {
        require_once SEO_PRO_PLUGIN_DIR . 'admin/views/redirects.php';
    }
    
    /**
     * Render 404 monitor
     */
    public function render_404_monitor() {
        require_once SEO_PRO_PLUGIN_DIR . 'admin/views/404-monitor.php';
    }
    
    /**
     * Render sitemap
     */
    public function render_sitemap() {
        require_once SEO_PRO_PLUGIN_DIR . 'admin/views/sitemap.php';
    }
}
