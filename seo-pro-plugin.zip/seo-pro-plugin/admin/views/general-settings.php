<?php
/**
 * General Settings View
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Handle form submission
if ( isset( $_POST['submit'] ) && check_admin_referer( 'seo_pro_general_settings' ) ) {
    update_option( 'seo_pro_title_separator', sanitize_text_field( $_POST['seo_separator'] ) );
    update_option( 'seo_default_image', esc_url_raw( $_POST['seo_default_image'] ) );
    update_option( 'seo_pro_google_verification', sanitize_text_field( $_POST['google_verification'] ) );
    
    echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Settings saved successfully!', 'seo-pro' ) . '</p></div>';
}

$separator = get_option( 'seo_pro_title_separator', '|' );
$default_image = get_option( 'seo_default_image', '' );
$google_verification = get_option( 'seo_pro_google_verification', '' );
?>

<div class="wrap seo-pro-wrap">
    <h1><?php _e( 'General Settings', 'seo-pro' ); ?></h1>
    
    <div class="seo-card">
        <form method="post">
            <?php wp_nonce_field( 'seo_pro_general_settings' ); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="seo_separator"><?php _e( 'Title Separator', 'seo-pro' ); ?></label>
                    </th>
                    <td>
                        <select id="seo_separator" name="seo_separator">
                            <option value="-" <?php selected( $separator, '-' ); ?>>- (<?php _e( 'Dash', 'seo-pro' ); ?>)</option>
                            <option value="|" <?php selected( $separator, '|' ); ?>>| (<?php _e( 'Pipe', 'seo-pro' ); ?>)</option>
                            <option value="~" <?php selected( $separator, '~' ); ?>>~ (<?php _e( 'Tilde', 'seo-pro' ); ?>)</option>
                            <option value="·" <?php selected( $separator, '·' ); ?>>· (<?php _e( 'Middle Dot', 'seo-pro' ); ?>)</option>
                            <option value="•" <?php selected( $separator, '•' ); ?>>• (<?php _e( 'Bullet', 'seo-pro' ); ?>)</option>
                        </select>
                        <p class="description"><?php _e( 'Separator used in title tags', 'seo-pro' ); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="seo_default_image"><?php _e( 'Default Social Image', 'seo-pro' ); ?></label>
                    </th>
                    <td>
                        <input type="url" id="seo_default_image" name="seo_default_image" value="<?php echo esc_attr( $default_image ); ?>" class="regular-text">
                        <p class="description"><?php _e( 'Default image for social media sharing (1200x630px recommended)', 'seo-pro' ); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">
                        <label for="google_verification"><?php _e( 'Google Site Verification', 'seo-pro' ); ?></label>
                    </th>
                    <td>
                        <input type="text" id="google_verification" name="google_verification" value="<?php echo esc_attr( $google_verification ); ?>" class="regular-text" placeholder="abc123xyz...">
                        <p class="description">
                            <?php _e( 'Enter only the verification code (not the full meta tag)', 'seo-pro' ); ?><br>
                            <?php _e( 'Get it from', 'seo-pro' ); ?> <a href="https://search.google.com/search-console" target="_blank"><?php _e( 'Google Search Console', 'seo-pro' ); ?></a> → 
                            <?php _e( 'Settings → Ownership verification → HTML tag method', 'seo-pro' ); ?>
                        </p>
                        <?php if ( ! empty( $google_verification ) ) : ?>
                            <p class="description" style="color: #00a32a;">
                                <strong>✓ <?php _e( 'Verification code added! Meta tag will be output in <head> section.', 'seo-pro' ); ?></strong>
                            </p>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>
            
            <?php submit_button(); ?>
        </form>
    </div>
</div>
<?php
