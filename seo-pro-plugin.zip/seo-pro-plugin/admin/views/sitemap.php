<?php
/**
 * Sitemap View
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="wrap seo-pro-wrap">
    <h1><?php _e( '🗺️ XML Sitemap', 'seo-pro' ); ?></h1>
    
    <div class="seo-card">
        <h2><?php _e( 'Your Sitemap URLs', 'seo-pro' ); ?></h2>
        
        <p><strong><?php _e( 'Main Sitemap:', 'seo-pro' ); ?></strong></p>
        <p><a href="<?php echo home_url( '/sitemap.xml' ); ?>" target="_blank"><?php echo home_url( '/sitemap.xml' ); ?></a></p>
        
        <h3><?php _e( 'Individual Sitemaps:', 'seo-pro' ); ?></h3>
        <ul>
            <li><a href="<?php echo home_url( '/sitemap-posts.xml' ); ?>" target="_blank"><?php _e( 'Posts Sitemap', 'seo-pro' ); ?></a></li>
            <li><a href="<?php echo home_url( '/sitemap-pages.xml' ); ?>" target="_blank"><?php _e( 'Pages Sitemap', 'seo-pro' ); ?></a></li>
            <?php if ( function_exists( 'rtcl' ) ) : ?>
                <li><a href="<?php echo home_url( '/sitemap-listings.xml' ); ?>" target="_blank"><?php _e( 'Listings Sitemap', 'seo-pro' ); ?></a></li>
                <li><a href="<?php echo home_url( '/sitemap-categories.xml' ); ?>" target="_blank"><?php _e( 'Categories Sitemap', 'seo-pro' ); ?></a></li>
                <li><a href="<?php echo home_url( '/sitemap-locations.xml' ); ?>" target="_blank"><?php _e( 'Locations Sitemap', 'seo-pro' ); ?></a></li>
            <?php endif; ?>
        </ul>
        
        <h3><?php _e( 'Submit to Search Engines:', 'seo-pro' ); ?></h3>
        <ul>
            <li><a href="https://search.google.com/search-console" target="_blank"><?php _e( 'Google Search Console', 'seo-pro' ); ?></a></li>
            <li><a href="https://www.bing.com/webmasters" target="_blank"><?php _e( 'Bing Webmaster Tools', 'seo-pro' ); ?></a></li>
        </ul>
        
        <div class="notice notice-info inline">
            <p><strong><?php _e( 'Note:', 'seo-pro' ); ?></strong> <?php _e( 'Your sitemap is automatically updated when you publish new content.', 'seo-pro' ); ?></p>
        </div>
    </div>
</div>
<?php
