<?php
/**
 * Social Media View
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( isset( $_POST['submit'] ) && check_admin_referer( 'seo_pro_social_settings' ) ) {
    update_option( 'seo_facebook_url', esc_url_raw( $_POST['seo_facebook_url'] ) );
    update_option( 'seo_twitter_url', esc_url_raw( $_POST['seo_twitter_url'] ) );
    update_option( 'seo_twitter_username', sanitize_text_field( $_POST['seo_twitter_username'] ) );
    update_option( 'seo_instagram_url', esc_url_raw( $_POST['seo_instagram_url'] ) );
    update_option( 'seo_linkedin_url', esc_url_raw( $_POST['seo_linkedin_url'] ) );
    echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Social media settings saved!', 'seo-pro' ) . '</p></div>';
}
?>
<div class="wrap seo-pro-wrap">
    <h1><?php _e( '📱 Social Media Settings', 'seo-pro' ); ?></h1>
    <div class="seo-card">
        <form method="post">
            <?php wp_nonce_field( 'seo_pro_social_settings' ); ?>
            <table class="form-table">
                <tr>
                    <th><label for="seo_facebook_url"><?php _e( 'Facebook Page URL', 'seo-pro' ); ?></label></th>
                    <td><input type="url" id="seo_facebook_url" name="seo_facebook_url" value="<?php echo esc_attr( get_option( 'seo_facebook_url' ) ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="seo_twitter_url"><?php _e( 'Twitter Profile URL', 'seo-pro' ); ?></label></th>
                    <td><input type="url" id="seo_twitter_url" name="seo_twitter_url" value="<?php echo esc_attr( get_option( 'seo_twitter_url' ) ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="seo_twitter_username"><?php _e( 'Twitter Username', 'seo-pro' ); ?></label></th>
                    <td>
                        <input type="text" id="seo_twitter_username" name="seo_twitter_username" value="<?php echo esc_attr( get_option( 'seo_twitter_username' ) ); ?>" class="regular-text">
                        <p class="description"><?php _e( 'Without @ symbol', 'seo-pro' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="seo_instagram_url"><?php _e( 'Instagram Profile URL', 'seo-pro' ); ?></label></th>
                    <td><input type="url" id="seo_instagram_url" name="seo_instagram_url" value="<?php echo esc_attr( get_option( 'seo_instagram_url' ) ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="seo_linkedin_url"><?php _e( 'LinkedIn Profile URL', 'seo-pro' ); ?></label></th>
                    <td><input type="url" id="seo_linkedin_url" name="seo_linkedin_url" value="<?php echo esc_attr( get_option( 'seo_linkedin_url' ) ); ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
</div>
<?php
