<?php
/**
 * 404 Monitor View
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( isset( $_POST['clear_log'] ) && check_admin_referer( 'seo_pro_404_clear' ) ) {
    SEO_Pro_404_Monitor::clear_logs();
    echo '<div class="notice notice-success is-dismissible"><p>' . __( '404 log cleared!', 'seo-pro' ) . '</p></div>';
}

$logs = SEO_Pro_404_Monitor::get_logs( 100 );
?>
<div class="wrap seo-pro-wrap">
    <h1><?php _e( '🚫 404 Monitor', 'seo-pro' ); ?></h1>
    
    <div class="seo-card">
        <p><?php _e( 'Track 404 errors on your website to identify broken links.', 'seo-pro' ); ?></p>
        
        <?php if ( ! empty( $logs ) ) : ?>
            <form method="post" style="margin-bottom: 15px;">
                <?php wp_nonce_field( 'seo_pro_404_clear' ); ?>
                <button type="submit" name="clear_log" class="button"><?php _e( 'Clear Log', 'seo-pro' ); ?></button>
            </form>
            
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e( 'URL', 'seo-pro' ); ?></th>
                        <th><?php _e( 'Referer', 'seo-pro' ); ?></th>
                        <th><?php _e( 'IP Address', 'seo-pro' ); ?></th>
                        <th><?php _e( 'Date', 'seo-pro' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $logs as $log ) : ?>
                        <tr>
                            <td><?php echo esc_html( $log->url ); ?></td>
                            <td><?php echo esc_html( $log->referer ); ?></td>
                            <td><?php echo esc_html( $log->ip_address ); ?></td>
                            <td><?php echo esc_html( $log->date ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p><?php _e( 'No 404 errors logged yet.', 'seo-pro' ); ?></p>
        <?php endif; ?>
    </div>
</div>
<?php
