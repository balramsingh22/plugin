<?php
/**
 * Dashboard View
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;

// Get stats
$posts_count = wp_count_posts( 'post' )->publish;
$pages_count = wp_count_posts( 'page' )->publish;

$listings_count = 0;
if ( post_type_exists( 'rtcl_listing' ) ) {
    $listings_count = wp_count_posts( 'rtcl_listing' )->publish;
}

$redirects_count = 0;
$table_name = $wpdb->prefix . 'seo_pro_redirects';
if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) == $table_name ) {
    $redirects_count = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" );
}

$errors_404_count = 0;
$table_name = $wpdb->prefix . 'seo_pro_404_log';
if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) == $table_name ) {
    $errors_404_count = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name WHERE DATE(date) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)" );
}
?>

<div class="wrap seo-pro-wrap">
    <h1><?php _e( '🚀 SEO Pro Dashboard', 'seo-pro' ); ?></h1>
    
    <div class="seo-pro-dashboard">
        <!-- Welcome Card -->
        <div class="seo-card seo-card-welcome">
            <h2><?php _e( 'Welcome to SEO Pro!', 'seo-pro' ); ?></h2>
            <p><?php _e( 'Rank Math PRO quality features, completely FREE! Your all-in-one SEO solution.', 'seo-pro' ); ?></p>
            
            <div class="features-grid">
                <div class="feature-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <span><?php _e( 'Advanced Schema Markup', 'seo-pro' ); ?></span>
                </div>
                <div class="feature-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <span><?php _e( 'Auto SEO Meta Tags', 'seo-pro' ); ?></span>
                </div>
                <div class="feature-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <span><?php _e( 'Open Graph & Twitter Cards', 'seo-pro' ); ?></span>
                </div>
                <div class="feature-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <span><?php _e( 'XML Sitemap', 'seo-pro' ); ?></span>
                </div>
                <div class="feature-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <span><?php _e( 'Auto Internal Linking', 'seo-pro' ); ?></span>
                </div>
                <div class="feature-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <span><?php _e( 'SEO Score & Analysis', 'seo-pro' ); ?></span>
                </div>
                <div class="feature-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <span><?php _e( 'Redirection Manager', 'seo-pro' ); ?></span>
                </div>
                <div class="feature-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <span><?php _e( '404 Monitor', 'seo-pro' ); ?></span>
                </div>
                <div class="feature-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <span><?php _e( 'Local SEO', 'seo-pro' ); ?></span>
                </div>
                <div class="feature-item">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <span><?php _e( 'RTCL Integration', 'seo-pro' ); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="seo-stats-grid">
            <div class="seo-stat-card">
                <div class="stat-icon">📝</div>
                <div class="stat-number"><?php echo esc_html( $posts_count ); ?></div>
                <div class="stat-label"><?php _e( 'Published Posts', 'seo-pro' ); ?></div>
            </div>
            
            <div class="seo-stat-card">
                <div class="stat-icon">📄</div>
                <div class="stat-number"><?php echo esc_html( $pages_count ); ?></div>
                <div class="stat-label"><?php _e( 'Published Pages', 'seo-pro' ); ?></div>
            </div>
            
            <?php if ( $listings_count > 0 ) : ?>
            <div class="seo-stat-card">
                <div class="stat-icon">📋</div>
                <div class="stat-number"><?php echo esc_html( $listings_count ); ?></div>
                <div class="stat-label"><?php _e( 'Published Listings', 'seo-pro' ); ?></div>
            </div>
            <?php endif; ?>
            
            <div class="seo-stat-card">
                <div class="stat-icon">↪️</div>
                <div class="stat-number"><?php echo esc_html( $redirects_count ); ?></div>
                <div class="stat-label"><?php _e( 'Active Redirects', 'seo-pro' ); ?></div>
            </div>
            
            <div class="seo-stat-card">
                <div class="stat-icon">🚫</div>
                <div class="stat-number"><?php echo esc_html( $errors_404_count ); ?></div>
                <div class="stat-label"><?php _e( '404 Errors (7 days)', 'seo-pro' ); ?></div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="seo-card">
            <h2><?php _e( 'Quick Actions', 'seo-pro' ); ?></h2>
            <div class="quick-actions-grid">
                <a href="<?php echo admin_url( 'admin.php?page=seo-pro-general' ); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-admin-settings"></span>
                    <span><?php _e( 'General Settings', 'seo-pro' ); ?></span>
                </a>
                <a href="<?php echo admin_url( 'admin.php?page=seo-pro-local' ); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-location"></span>
                    <span><?php _e( 'Local SEO', 'seo-pro' ); ?></span>
                </a>
                <a href="<?php echo admin_url( 'admin.php?page=seo-pro-social' ); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-share"></span>
                    <span><?php _e( 'Social Media', 'seo-pro' ); ?></span>
                </a>
                <a href="<?php echo admin_url( 'admin.php?page=seo-pro-linking' ); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-admin-links"></span>
                    <span><?php _e( 'Auto Linking', 'seo-pro' ); ?></span>
                </a>
                <a href="<?php echo admin_url( 'admin.php?page=seo-pro-redirects' ); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-randomize"></span>
                    <span><?php _e( 'Redirects', 'seo-pro' ); ?></span>
                </a>
                <a href="<?php echo admin_url( 'admin.php?page=seo-pro-404' ); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-warning"></span>
                    <span><?php _e( '404 Monitor', 'seo-pro' ); ?></span>
                </a>
                <a href="<?php echo admin_url( 'admin.php?page=seo-pro-sitemap' ); ?>" class="quick-action-btn">
                    <span class="dashicons dashicons-networking"></span>
                    <span><?php _e( 'Sitemap', 'seo-pro' ); ?></span>
                </a>
                <a href="<?php echo home_url( '/sitemap.xml' ); ?>" class="quick-action-btn" target="_blank">
                    <span class="dashicons dashicons-external"></span>
                    <span><?php _e( 'View Sitemap', 'seo-pro' ); ?></span>
                </a>
            </div>
        </div>
        
        <!-- Resources -->
        <div class="seo-card">
            <h2><?php _e( 'Resources & Tools', 'seo-pro' ); ?></h2>
            <ul class="resources-list">
                <li>
                    <a href="https://search.google.com/search-console" target="_blank">
                        <?php _e( 'Google Search Console', 'seo-pro' ); ?> →
                    </a>
                </li>
                <li>
                    <a href="https://search.google.com/test/rich-results" target="_blank">
                        <?php _e( 'Rich Results Test', 'seo-pro' ); ?> →
                    </a>
                </li>
                <li>
                    <a href="https://pagespeed.web.dev/" target="_blank">
                        <?php _e( 'PageSpeed Insights', 'seo-pro' ); ?> →
                    </a>
                </li>
                <li>
                    <a href="https://analytics.google.com/" target="_blank">
                        <?php _e( 'Google Analytics', 'seo-pro' ); ?> →
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>

<style>
.seo-pro-wrap {
    margin: 20px 20px 20px 0;
}
.seo-pro-dashboard {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 20px;
    margin-top: 20px;
}
.seo-card {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.seo-card h2 {
    margin-top: 0;
    color: #1d2327;
    font-size: 18px;
}
.seo-card-welcome {
    grid-column: 1 / -1;
}
.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 10px;
    margin-top: 15px;
}
.feature-item {
    display: flex;
    align-items: center;
    gap: 8px;
}
.feature-item .dashicons {
    color: #00a32a;
}
.seo-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    grid-column: 1 / -1;
}
.seo-stat-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    padding: 20px;
    border-radius: 8px;
    text-align: center;
}
.seo-stat-card:nth-child(2) {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}
.seo-stat-card:nth-child(3) {
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}
.seo-stat-card:nth-child(4) {
    background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
}
.seo-stat-card:nth-child(5) {
    background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
}
.stat-icon {
    font-size: 32px;
    margin-bottom: 10px;
}
.stat-number {
    font-size: 36px;
    font-weight: 700;
    margin-bottom: 5px;
}
.stat-label {
    font-size: 13px;
    opacity: 0.9;
}
.quick-actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 10px;
}
.quick-action-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    padding: 15px;
    background: #f0f0f1;
    border-radius: 6px;
    text-decoration: none;
    color: #1d2327;
    transition: all 0.2s;
}
.quick-action-btn:hover {
    background: #2271b1;
    color: #fff;
    transform: translateY(-2px);
}
.quick-action-btn .dashicons {
    font-size: 24px;
    width: 24px;
    height: 24px;
}
.resources-list {
    list-style: none;
    padding: 0;
    margin: 0;
}
.resources-list li {
    padding: 10px 0;
    border-bottom: 1px solid #f0f0f1;
}
.resources-list li:last-child {
    border-bottom: none;
}
.resources-list a {
    text-decoration: none;
    color: #2271b1;
    font-weight: 500;
}
.resources-list a:hover {
    color: #135e96;
}
</style>
<?php
