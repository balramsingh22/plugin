<?php
/**
 * Local SEO View
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Handle form submission
if ( isset( $_POST['submit'] ) && check_admin_referer( 'seo_pro_local_settings' ) ) {
    $fields = array(
        'seo_business_type', 'seo_phone', 'seo_street_address', 'seo_locality',
        'seo_region', 'seo_postal_code', 'seo_latitude', 'seo_longitude',
        'seo_price_range', 'seo_geo_region', 'seo_geo_placename', 'seo_geo_position'
    );
    
    foreach ( $fields as $field ) {
        update_option( $field, sanitize_text_field( $_POST[ $field ] ) );
    }
    
    echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Local SEO settings saved!', 'seo-pro' ) . '</p></div>';
}
?>

<div class="wrap seo-pro-wrap">
    <h1><?php _e( '📍 Local SEO Settings', 'seo-pro' ); ?></h1>
    
    <div class="seo-card">
        <form method="post">
            <?php wp_nonce_field( 'seo_pro_local_settings' ); ?>
            
            <h2><?php _e( 'Business Information', 'seo-pro' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th><label for="seo_business_type"><?php _e( 'Business Type', 'seo-pro' ); ?></label></th>
                    <td>
                        <select id="seo_business_type" name="seo_business_type" class="regular-text">
                            <option value="LocalBusiness" <?php selected( get_option( 'seo_business_type' ), 'LocalBusiness' ); ?>><?php _e( 'Local Business', 'seo-pro' ); ?></option>
                            <option value="Restaurant" <?php selected( get_option( 'seo_business_type' ), 'Restaurant' ); ?>><?php _e( 'Restaurant', 'seo-pro' ); ?></option>
                            <option value="Store" <?php selected( get_option( 'seo_business_type' ), 'Store' ); ?>><?php _e( 'Store', 'seo-pro' ); ?></option>
                            <option value="RealEstateAgent" <?php selected( get_option( 'seo_business_type' ), 'RealEstateAgent' ); ?>><?php _e( 'Real Estate Agent', 'seo-pro' ); ?></option>
                            <option value="ProfessionalService" <?php selected( get_option( 'seo_business_type' ), 'ProfessionalService' ); ?>><?php _e( 'Professional Service', 'seo-pro' ); ?></option>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <th><label for="seo_phone"><?php _e( 'Phone Number', 'seo-pro' ); ?></label></th>
                    <td>
                        <input type="text" id="seo_phone" name="seo_phone" value="<?php echo esc_attr( get_option( 'seo_phone', '+91-1234567890' ) ); ?>" class="regular-text">
                        <p class="description"><?php _e( 'Format: +91-1234567890', 'seo-pro' ); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th><label for="seo_price_range"><?php _e( 'Price Range', 'seo-pro' ); ?></label></th>
                    <td>
                        <select id="seo_price_range" name="seo_price_range">
                            <option value="₹" <?php selected( get_option( 'seo_price_range' ), '₹' ); ?>>₹ (<?php _e( 'Budget', 'seo-pro' ); ?>)</option>
                            <option value="₹₹" <?php selected( get_option( 'seo_price_range' ), '₹₹' ); ?>>₹₹ (<?php _e( 'Moderate', 'seo-pro' ); ?>)</option>
                            <option value="₹₹₹" <?php selected( get_option( 'seo_price_range' ), '₹₹₹' ); ?>>₹₹₹ (<?php _e( 'Expensive', 'seo-pro' ); ?>)</option>
                            <option value="₹₹₹₹" <?php selected( get_option( 'seo_price_range' ), '₹₹₹₹' ); ?>>₹₹₹₹ (<?php _e( 'Very Expensive', 'seo-pro' ); ?>)</option>
                        </select>
                    </td>
                </tr>
            </table>
            
            <h2><?php _e( 'Address', 'seo-pro' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th><label for="seo_street_address"><?php _e( 'Street Address', 'seo-pro' ); ?></label></th>
                    <td><input type="text" id="seo_street_address" name="seo_street_address" value="<?php echo esc_attr( get_option( 'seo_street_address' ) ); ?>" class="regular-text"></td>
                </tr>
                
                <tr>
                    <th><label for="seo_locality"><?php _e( 'City/Locality', 'seo-pro' ); ?></label></th>
                    <td><input type="text" id="seo_locality" name="seo_locality" value="<?php echo esc_attr( get_option( 'seo_locality', 'Mumbai' ) ); ?>" class="regular-text"></td>
                </tr>
                
                <tr>
                    <th><label for="seo_region"><?php _e( 'State/Region', 'seo-pro' ); ?></label></th>
                    <td><input type="text" id="seo_region" name="seo_region" value="<?php echo esc_attr( get_option( 'seo_region', 'Maharashtra' ) ); ?>" class="regular-text"></td>
                </tr>
                
                <tr>
                    <th><label for="seo_postal_code"><?php _e( 'Postal Code', 'seo-pro' ); ?></label></th>
                    <td><input type="text" id="seo_postal_code" name="seo_postal_code" value="<?php echo esc_attr( get_option( 'seo_postal_code', '400001' ) ); ?>" class="regular-text"></td>
                </tr>
            </table>
            
            <h2><?php _e( 'Geo Coordinates', 'seo-pro' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th><label for="seo_latitude"><?php _e( 'Latitude', 'seo-pro' ); ?></label></th>
                    <td><input type="text" id="seo_latitude" name="seo_latitude" value="<?php echo esc_attr( get_option( 'seo_latitude', '19.0760' ) ); ?>" class="regular-text"></td>
                </tr>
                
                <tr>
                    <th><label for="seo_longitude"><?php _e( 'Longitude', 'seo-pro' ); ?></label></th>
                    <td><input type="text" id="seo_longitude" name="seo_longitude" value="<?php echo esc_attr( get_option( 'seo_longitude', '72.8777' ) ); ?>" class="regular-text"></td>
                </tr>
                
                <tr>
                    <th><label for="seo_geo_region"><?php _e( 'Geo Region', 'seo-pro' ); ?></label></th>
                    <td>
                        <input type="text" id="seo_geo_region" name="seo_geo_region" value="<?php echo esc_attr( get_option( 'seo_geo_region', 'IN-MH' ) ); ?>" class="regular-text">
                        <p class="description"><?php _e( 'Format: IN-MH (Country-State)', 'seo-pro' ); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th><label for="seo_geo_placename"><?php _e( 'Geo Placename', 'seo-pro' ); ?></label></th>
                    <td><input type="text" id="seo_geo_placename" name="seo_geo_placename" value="<?php echo esc_attr( get_option( 'seo_geo_placename', 'Mumbai' ) ); ?>" class="regular-text"></td>
                </tr>
                
                <tr>
                    <th><label for="seo_geo_position"><?php _e( 'Geo Position', 'seo-pro' ); ?></label></th>
                    <td>
                        <input type="text" id="seo_geo_position" name="seo_geo_position" value="<?php echo esc_attr( get_option( 'seo_geo_position', '19.0760;72.8777' ) ); ?>" class="regular-text">
                        <p class="description"><?php _e( 'Format: latitude;longitude', 'seo-pro' ); ?></p>
                    </td>
                </tr>
            </table>
            
            <?php submit_button(); ?>
        </form>
    </div>
</div>
<?php
