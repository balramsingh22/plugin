<?php
/**
 * Auto Linking - Complete Management Interface
 * All features in one page: Keywords, Advanced Settings, Analytics
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// Check user capabilities
if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( __( 'You do not have sufficient permissions to access this page.', 'seo-pro' ) );
}

// Handle analytics reset
if ( isset( $_POST['reset_analytics'] ) && check_admin_referer( 'seo_pro_linking_settings' ) ) {
    if ( class_exists( 'SEO_Pro_Auto_Linking' ) ) {
        SEO_Pro_Auto_Linking::reset_analytics();
        echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Analytics data reset!', 'seo-pro' ) . '</p></div>';
    }
}

// Handle global settings
if ( isset( $_POST['save_global_settings'] ) && check_admin_referer( 'seo_pro_linking_settings' ) ) {
    update_option( 'seo_auto_link_exclude_headings', isset( $_POST['exclude_headings'] ) );
    echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Global settings saved!', 'seo-pro' ) . '</p></div>';
}

// Handle keyword save
if ( isset( $_POST['submit'] ) && check_admin_referer( 'seo_pro_linking_settings' ) ) {
    $keywords = array();
    
    // First, get all keywords from hidden inputs (from all pages)
    if ( isset( $_POST['all_keywords'] ) && is_array( $_POST['all_keywords'] ) ) {
        foreach ( $_POST['all_keywords'] as $keyword_data ) {
            if ( ! empty( $keyword_data['keyword'] ) && ! empty( $keyword_data['url'] ) ) {
                $keywords[] = array(
                    'keyword' => sanitize_text_field( $keyword_data['keyword'] ),
                    'url' => esc_url_raw( $keyword_data['url'] ),
                    'limit' => isset( $keyword_data['limit'] ) ? intval( $keyword_data['limit'] ) : 3,
                    'priority' => isset( $keyword_data['priority'] ) ? intval( $keyword_data['priority'] ) : 7,
                    'nofollow' => isset( $keyword_data['nofollow'] ) && $keyword_data['nofollow'] == '1',
                    'target_blank' => isset( $keyword_data['target_blank'] ) && $keyword_data['target_blank'] == '1',
                    'case_sensitive' => isset( $keyword_data['case_sensitive'] ) && $keyword_data['case_sensitive'] == '1',
                    'first_only' => isset( $keyword_data['first_only'] ) && $keyword_data['first_only'] == '1',
                    'title' => isset( $keyword_data['title'] ) ? sanitize_text_field( $keyword_data['title'] ) : '',
                    'post_types' => isset( $keyword_data['post_types'] ) ? $keyword_data['post_types'] : array(),
                );
            }
        }
    }
    
    // Then, update with visible keywords from current page
    if ( isset( $_POST['keywords'] ) && is_array( $_POST['keywords'] ) ) {
        $current_page_keywords = array();
        foreach ( $_POST['keywords'] as $index => $keyword ) {
            if ( ! empty( $keyword ) && ! empty( $_POST['urls'][ $index ] ) ) {
                $current_page_keywords[] = array(
                    'keyword' => sanitize_text_field( $keyword ),
                    'url' => esc_url_raw( $_POST['urls'][ $index ] ),
                    'limit' => isset( $_POST['limits'][ $index ] ) ? intval( $_POST['limits'][ $index ] ) : 3,
                    'priority' => isset( $_POST['priorities'][ $index ] ) ? intval( $_POST['priorities'][ $index ] ) : 7,
                    'nofollow' => isset( $_POST['nofollow_' . $index] ) && $_POST['nofollow_' . $index] == '1',
                    'target_blank' => isset( $_POST['target_blank_' . $index] ) && $_POST['target_blank_' . $index] == '1',
                    'case_sensitive' => isset( $_POST['case_sensitives'][ $index ] ) && $_POST['case_sensitives'][ $index ] == '1',
                    'first_only' => isset( $_POST['first_only_' . $index] ) && $_POST['first_only_' . $index] == '1',
                    'title' => isset( $_POST['titles'][ $index ] ) ? sanitize_text_field( $_POST['titles'][ $index ] ) : '',
                    'post_types' => isset( $_POST['post_types'][ $index ] ) ? $_POST['post_types'][ $index ] : array(),
                );
            }
        }
        
        if ( ! empty( $current_page_keywords ) ) {
            $per_page = 100;
            $current_page = isset( $_POST['current_page'] ) ? max( 1, intval( $_POST['current_page'] ) ) : 1;
            $offset = ( $current_page - 1 ) * $per_page;
            array_splice( $keywords, $offset, $per_page, $current_page_keywords );
        }
    }
    
    update_option( 'seo_auto_link_keywords', $keywords );
    echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Auto linking settings saved!', 'seo-pro' ) . '</p></div>';
}


$keywords = get_option( 'seo_auto_link_keywords', array() );
$exclude_headings = get_option( 'seo_auto_link_exclude_headings', true );

// Get analytics data (with safety check)
$analytics = array();
if ( class_exists( 'SEO_Pro_Auto_Linking' ) ) {
    $analytics = SEO_Pro_Auto_Linking::get_analytics();
}

// Pagination settings
$per_page = 100;
$current_page = isset( $_GET['paged'] ) ? max( 1, intval( $_GET['paged'] ) ) : 1;
$total_keywords = count( $keywords );
$total_pages = ceil( $total_keywords / $per_page );
$offset = ( $current_page - 1 ) * $per_page;
$keywords_paginated = array_slice( $keywords, $offset, $per_page );

// Get available post types
$post_types = get_post_types( array( 'public' => true ), 'objects' );

// Active tab
$active_tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'keywords';
?>

<div class="wrap seo-pro-wrap">
    <h1><?php _e( '🔗 Auto Internal Linking - Complete Management', 'seo-pro' ); ?></h1>
    
    <!-- Tabs -->
    <h2 class="nav-tab-wrapper">
        <a href="?page=seo-pro-auto-linking&tab=keywords" class="nav-tab <?php echo $active_tab === 'keywords' ? 'nav-tab-active' : ''; ?>">
            📝 <?php _e( 'Keywords Management', 'seo-pro' ); ?>
        </a>
        <a href="?page=seo-pro-auto-linking&tab=analytics" class="nav-tab <?php echo $active_tab === 'analytics' ? 'nav-tab-active' : ''; ?>">
            📊 <?php _e( 'Analytics Dashboard', 'seo-pro' ); ?>
        </a>
        <a href="?page=seo-pro-auto-linking&tab=settings" class="nav-tab <?php echo $active_tab === 'settings' ? 'nav-tab-active' : ''; ?>">
            ⚙️ <?php _e( 'Global Settings', 'seo-pro' ); ?>
        </a>
        <a href="?page=seo-pro-auto-linking&tab=guide" class="nav-tab <?php echo $active_tab === 'guide' ? 'nav-tab-active' : ''; ?>">
            📚 <?php _e( 'Feature Guide', 'seo-pro' ); ?>
        </a>
    </h2>
    
    <div class="tab-content" style="margin-top: 20px;">
        
        <?php if ( $active_tab === 'keywords' ) : ?>
            <!-- KEYWORDS MANAGEMENT TAB -->
            
            <?php if ( $total_keywords > 0 ) : ?>
                <div class="seo-card" style="background: #f0f6fc; border-left: 4px solid #0073aa; padding: 15px; margin-bottom: 20px;">
                    <p style="margin: 0; font-size: 14px;">
                        <strong><?php _e( 'Total Keywords:', 'seo-pro' ); ?></strong> <?php echo number_format( $total_keywords ); ?>
                        <?php if ( $total_pages > 1 ) : ?>
                            | <strong><?php _e( 'Page:', 'seo-pro' ); ?></strong> <?php echo $current_page; ?> / <?php echo $total_pages; ?>
                            | <strong><?php _e( 'Showing:', 'seo-pro' ); ?></strong> <?php echo ( $offset + 1 ); ?> - <?php echo min( $offset + $per_page, $total_keywords ); ?>
                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
            
            <div class="seo-card">
                <p><?php _e( 'Automatically link specific keywords to URLs throughout your content with advanced SEO options.', 'seo-pro' ); ?></p>
                
                <!-- BULK TEMPLATE GENERATOR -->
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <h3 style="margin-top: 0; color: white;">🚀 Bulk Template Generator - Smart Work!</h3>
                    <p style="margin-bottom: 15px;">एक साथ multiple keywords बनाएं! Template use करें और cities/locations add करें।</p>
                    
                    <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 5px; margin-bottom: 15px;">
                        <button type="button" id="toggle-bulk-generator" class="button button-large" style="background: white; color: #667eea; border: none; font-weight: bold;">
                            📝 Open Bulk Generator
                        </button>
                    </div>
                    
                    <div id="bulk-generator-panel" style="display: none; background: white; color: #333; padding: 20px; border-radius: 5px;">
                        <h4 style="margin-top: 0; color: #667eea;">Step 1: Keyword Templates</h4>
                        <p style="font-size: 13px; color: #666;">Use <code>{CITY}</code> placeholder जहां city name आना है।</p>
                        <textarea id="bulk-templates" rows="5" style="width: 100%; font-family: monospace;" placeholder="Example:
{CITY} Escorts
{CITY} Escorts Service
Escorts in {CITY}
{CITY} Call Girls
{CITY} Escort"></textarea>
                        
                        <h4 style="margin-top: 20px; color: #667eea;">Step 2: Cities/Locations (comma separated)</h4>
                        <input type="text" id="bulk-cities" style="width: 100%;" placeholder="Example: Chembur, Bandra, Nerul, Andheri, Juhu">
                        
                        <h4 style="margin-top: 20px; color: #667eea;">Step 3: Base URL Template</h4>
                        <p style="font-size: 13px; color: #666;">Use <code>{CITY}</code> for dynamic URL या fixed URL दें।</p>
                        <input type="text" id="bulk-url" style="width: 100%;" placeholder="Example: https://1datings.com/{CITY}-escorts/">
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-top: 20px;">
                            <div>
                                <label><strong>Priority:</strong></label>
                                <select id="bulk-priority" style="width: 100%;">
                                    <?php for ( $i = 1; $i <= 10; $i++ ) : ?>
                                        <option value="<?php echo $i; ?>" <?php selected( 7, $i ); ?>><?php echo $i; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div>
                                <label><strong>Max Links:</strong></label>
                                <input type="number" id="bulk-limit" value="3" min="1" max="10" style="width: 100%;">
                            </div>
                            <div>
                                <label><strong>Options:</strong></label><br>
                                <label><input type="checkbox" id="bulk-nofollow"> NoFollow</label><br>
                                <label><input type="checkbox" id="bulk-target-blank"> New Tab</label><br>
                                <label><input type="checkbox" id="bulk-first-only" checked> First Only</label>
                            </div>
                        </div>
                        
                        <div style="margin-top: 20px; padding: 15px; background: #f0f6fc; border-left: 4px solid #0073aa; border-radius: 3px;">
                            <strong>Preview:</strong>
                            <div id="bulk-preview" style="margin-top: 10px; font-size: 13px; color: #666;">
                                Templates और cities enter करें preview देखने के लिए...
                            </div>
                        </div>
                        
                        <div style="margin-top: 20px; text-align: center;">
                            <button type="button" id="generate-bulk-keywords" class="button button-primary button-large">
                                ✨ Generate Keywords (Preview First)
                            </button>
                            <button type="button" id="preview-bulk-keywords" class="button button-secondary button-large">
                                👁️ Preview
                            </button>
                        </div>
                    </div>
                </div>
                
                <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 10px; margin-bottom: 15px;">
                    <strong>💡 Tip:</strong> Click on <span class="dashicons dashicons-arrow-down-alt2"></span> button to expand advanced options (Title, Case Sensitivity, Post Types)
                </div>
                
                <form method="post" id="auto-linking-form">
                    <?php wp_nonce_field( 'seo_pro_linking_settings' ); ?>
                    <input type="hidden" name="current_page" value="<?php echo $current_page; ?>">
                    
                    <!-- Hidden inputs for all keywords -->
                    <?php if ( ! empty( $keywords ) ) : ?>
                        <?php foreach ( $keywords as $idx => $keyword_data ) : ?>
                            <input type="hidden" name="all_keywords[<?php echo $idx; ?>][keyword]" value="<?php echo esc_attr( $keyword_data['keyword'] ); ?>">
                            <input type="hidden" name="all_keywords[<?php echo $idx; ?>][url]" value="<?php echo esc_attr( $keyword_data['url'] ); ?>">
                            <input type="hidden" name="all_keywords[<?php echo $idx; ?>][limit]" value="<?php echo esc_attr( $keyword_data['limit'] ); ?>">
                            <input type="hidden" name="all_keywords[<?php echo $idx; ?>][priority]" value="<?php echo esc_attr( isset( $keyword_data['priority'] ) ? $keyword_data['priority'] : 7 ); ?>">
                            <input type="hidden" name="all_keywords[<?php echo $idx; ?>][nofollow]" value="<?php echo isset( $keyword_data['nofollow'] ) && $keyword_data['nofollow'] ? '1' : '0'; ?>">
                            <input type="hidden" name="all_keywords[<?php echo $idx; ?>][target_blank]" value="<?php echo isset( $keyword_data['target_blank'] ) && $keyword_data['target_blank'] ? '1' : '0'; ?>">
                            <input type="hidden" name="all_keywords[<?php echo $idx; ?>][case_sensitive]" value="<?php echo isset( $keyword_data['case_sensitive'] ) && $keyword_data['case_sensitive'] ? '1' : '0'; ?>">
                            <input type="hidden" name="all_keywords[<?php echo $idx; ?>][first_only]" value="<?php echo isset( $keyword_data['first_only'] ) && $keyword_data['first_only'] ? '1' : '0'; ?>">
                            <input type="hidden" name="all_keywords[<?php echo $idx; ?>][title]" value="<?php echo esc_attr( isset( $keyword_data['title'] ) ? $keyword_data['title'] : '' ); ?>">
                        <?php endforeach; ?>
                    <?php endif; ?>
                    
                    <table class="widefat seo-auto-link-table" id="linking-table">
                        <thead>
                            <tr>
                                <th style="width: 3%;"><?php _e( '#', 'seo-pro' ); ?></th>
                                <th style="width: 20%;"><?php _e( 'Keyword', 'seo-pro' ); ?></th>
                                <th style="width: 25%;"><?php _e( 'Link To URL', 'seo-pro' ); ?></th>
                                <th style="width: 8%;"><?php _e( 'Max Links', 'seo-pro' ); ?></th>
                                <th style="width: 8%;"><?php _e( 'Priority', 'seo-pro' ); ?></th>
                                <th style="width: 26%;"><?php _e( 'Options', 'seo-pro' ); ?></th>
                                <th style="width: 5%;"><?php _e( 'More', 'seo-pro' ); ?></th>
                                <th style="width: 5%;"><?php _e( 'Action', 'seo-pro' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ( ! empty( $keywords_paginated ) ) : ?>
                                <?php foreach ( $keywords_paginated as $idx => $keyword_data ) : 
                                    $global_index = $offset + $idx;
                                    $nofollow = isset( $keyword_data['nofollow'] ) && $keyword_data['nofollow'];
                                    $target_blank = isset( $keyword_data['target_blank'] ) && $keyword_data['target_blank'];
                                    $case_sensitive = isset( $keyword_data['case_sensitive'] ) && $keyword_data['case_sensitive'];
                                    $first_only = isset( $keyword_data['first_only'] ) && $keyword_data['first_only'];
                                ?>
                                    <tr data-index="<?php echo $global_index; ?>" class="main-row">
                                        <td><strong><?php echo ( $global_index + 1 ); ?></strong></td>
                                        <td><input type="text" name="keywords[]" value="<?php echo esc_attr( $keyword_data['keyword'] ); ?>" class="regular-text" required></td>
                                        <td><input type="url" name="urls[]" value="<?php echo esc_attr( $keyword_data['url'] ); ?>" class="regular-text" required></td>
                                        <td><input type="number" name="limits[]" value="<?php echo esc_attr( $keyword_data['limit'] ); ?>" min="1" max="10" style="width: 60px;"></td>
                                        <td>
                                            <select name="priorities[]" style="width: 60px;">
                                                <?php for ( $i = 1; $i <= 10; $i++ ) : ?>
                                                    <option value="<?php echo $i; ?>" <?php selected( isset( $keyword_data['priority'] ) ? $keyword_data['priority'] : 7, $i ); ?>><?php echo $i; ?></option>
                                                <?php endfor; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <label style="margin-right: 10px;">
                                                <input type="hidden" name="nofollow_<?php echo $idx; ?>" value="0">
                                                <input type="checkbox" name="nofollow_<?php echo $idx; ?>" value="1" <?php checked( $nofollow ); ?>>
                                                NoFollow
                                            </label>
                                            <label style="margin-right: 10px;">
                                                <input type="hidden" name="target_blank_<?php echo $idx; ?>" value="0">
                                                <input type="checkbox" name="target_blank_<?php echo $idx; ?>" value="1" <?php checked( $target_blank ); ?>>
                                                New Tab
                                            </label>
                                            <label>
                                                <input type="hidden" name="first_only_<?php echo $idx; ?>" value="0">
                                                <input type="checkbox" name="first_only_<?php echo $idx; ?>" value="1" <?php checked( $first_only ); ?>>
                                                First Only
                                            </label>
                                        </td>
                                        <td>
                                            <button type="button" class="button button-small toggle-advanced" data-row="<?php echo $global_index; ?>" title="<?php _e( 'Show advanced options', 'seo-pro' ); ?>">
                                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                                            </button>
                                        </td>
                                        <td>
                                            <button type="button" class="button button-small remove-row" data-global-index="<?php echo $global_index; ?>" title="<?php _e( 'Remove', 'seo-pro' ); ?>">
                                                <span class="dashicons dashicons-trash"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="advanced-row" id="advanced-<?php echo $global_index; ?>" style="display: none;">
                                        <td colspan="8" style="background: #f9f9f9; padding: 15px;">
                                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                                <div>
                                                    <label><strong><?php _e( 'Title Attribute (SEO):', 'seo-pro' ); ?></strong></label><br>
                                                    <input type="text" name="titles[]" value="<?php echo esc_attr( isset( $keyword_data['title'] ) ? $keyword_data['title'] : '' ); ?>" class="regular-text" placeholder="e.g., Learn more about...">
                                                    <p class="description"><?php _e( 'Adds tooltip and improves SEO', 'seo-pro' ); ?></p>
                                                </div>
                                                <div>
                                                    <label>
                                                        <input type="checkbox" name="case_sensitives[]" value="1" <?php checked( $case_sensitive ); ?>>
                                                        <strong><?php _e( 'Case Sensitive Matching', 'seo-pro' ); ?></strong>
                                                    </label>
                                                    <p class="description"><?php _e( 'Match exact case (e.g., "SEO" won\'t match "seo")', 'seo-pro' ); ?></p>
                                                </div>
                                            </div>
                                            <div style="margin-top: 15px;">
                                                <label><strong><?php _e( 'Show on Post Types:', 'seo-pro' ); ?></strong></label><br>
                                                <div style="display: flex; gap: 15px; flex-wrap: wrap; margin-top: 5px;">
                                                    <?php foreach ( $post_types as $post_type ) : ?>
                                                        <label>
                                                            <input type="checkbox" name="post_types[<?php echo $global_index; ?>][]" value="<?php echo esc_attr( $post_type->name ); ?>" 
                                                                <?php echo isset( $keyword_data['post_types'] ) && in_array( $post_type->name, $keyword_data['post_types'] ) ? 'checked' : ''; ?>>
                                                            <?php echo esc_html( $post_type->label ); ?>
                                                        </label>
                                                    <?php endforeach; ?>
                                                </div>
                                                <p class="description"><?php _e( 'Leave unchecked to show on all post types', 'seo-pro' ); ?></p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <tr class="main-row">
                                    <td><strong>1</strong></td>
                                    <td><input type="text" name="keywords[]" class="regular-text" placeholder="e.g., SEO Tips" required></td>
                                    <td><input type="url" name="urls[]" class="regular-text" placeholder="https://example.com/seo-tips" required></td>
                                    <td><input type="number" name="limits[]" value="3" min="1" max="10" style="width: 60px;"></td>
                                    <td>
                                        <select name="priorities[]" style="width: 60px;">
                                            <?php for ( $i = 1; $i <= 10; $i++ ) : ?>
                                                <option value="<?php echo $i; ?>" <?php selected( 7, $i ); ?>><?php echo $i; ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </td>
                                    <td>
                                        <label style="margin-right: 10px;"><input type="checkbox" name="nofollows[]" value="1"> NoFollow</label>
                                        <label style="margin-right: 10px;"><input type="checkbox" name="target_blanks[]" value="1"> New Tab</label>
                                        <label><input type="checkbox" name="first_onlys[]" value="1"> First Only</label>
                                    </td>
                                    <td><button type="button" class="button button-small toggle-advanced" data-row="0"><span class="dashicons dashicons-arrow-down-alt2"></span></button></td>
                                    <td><button type="button" class="button button-small remove-row"><span class="dashicons dashicons-trash"></span></button></td>
                                </tr>
                                <tr class="advanced-row" id="advanced-0" style="display: none;">
                                    <td colspan="8" style="background: #f9f9f9; padding: 15px;">
                                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                            <div>
                                                <label><strong><?php _e( 'Title Attribute (SEO):', 'seo-pro' ); ?></strong></label><br>
                                                <input type="text" name="titles[]" class="regular-text" placeholder="e.g., Learn more about...">
                                            </div>
                                            <div>
                                                <label><input type="checkbox" name="case_sensitives[]" value="1"> <strong><?php _e( 'Case Sensitive Matching', 'seo-pro' ); ?></strong></label>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <?php if ( $total_pages > 1 ) : ?>
                        <div class="tablenav" style="margin-top: 20px;">
                            <div class="tablenav-pages">
                                <span class="displaying-num"><?php printf( __( '%s items', 'seo-pro' ), number_format( $total_keywords ) ); ?></span>
                                <span class="pagination-links">
                                    <?php if ( $current_page > 1 ) : ?>
                                        <a class="first-page button" href="<?php echo add_query_arg( array( 'paged' => 1, 'tab' => 'keywords' ) ); ?>">
                                            <span aria-hidden="true">«</span>
                                        </a>
                                        <a class="prev-page button" href="<?php echo add_query_arg( array( 'paged' => $current_page - 1, 'tab' => 'keywords' ) ); ?>">
                                            <span aria-hidden="true">‹</span>
                                        </a>
                                    <?php else : ?>
                                        <span class="tablenav-pages-navspan button disabled" aria-hidden="true">«</span>
                                        <span class="tablenav-pages-navspan button disabled" aria-hidden="true">‹</span>
                                    <?php endif; ?>
                                    
                                    <span class="paging-input">
                                        <input class="current-page" id="current-page-selector" type="text" value="<?php echo $current_page; ?>" size="<?php echo strlen( $total_pages ); ?>">
                                        <span class="tablenav-paging-text"> of <span class="total-pages"><?php echo $total_pages; ?></span></span>
                                    </span>
                                    
                                    <?php if ( $current_page < $total_pages ) : ?>
                                        <a class="next-page button" href="<?php echo add_query_arg( array( 'paged' => $current_page + 1, 'tab' => 'keywords' ) ); ?>">
                                            <span aria-hidden="true">›</span>
                                        </a>
                                        <a class="last-page button" href="<?php echo add_query_arg( array( 'paged' => $total_pages, 'tab' => 'keywords' ) ); ?>">
                                            <span aria-hidden="true">»</span>
                                        </a>
                                    <?php else : ?>
                                        <span class="tablenav-pages-navspan button disabled" aria-hidden="true">›</span>
                                        <span class="tablenav-pages-navspan button disabled" aria-hidden="true">»</span>
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <p style="margin-top: 20px;">
                        <button type="button" id="add-row" class="button"><?php _e( '➕ Add New Keyword', 'seo-pro' ); ?></button>
                    </p>
                    <?php submit_button( __( 'Save All Changes', 'seo-pro' ), 'primary large' ); ?>
                </form>
            </div>
            
        <?php elseif ( $active_tab === 'analytics' ) : ?>
            <!-- ANALYTICS TAB -->
            
            <div class="seo-card">
                <h2><?php _e( '📊 Link Analytics Dashboard', 'seo-pro' ); ?></h2>
                
                <?php if ( ! empty( $analytics ) ) : ?>
                    <div style="background: #f0f6fc; border-left: 4px solid #0073aa; padding: 15px; margin-bottom: 20px;">
                        <p style="margin: 0;">
                            <strong><?php _e( 'Total Keywords Tracked:', 'seo-pro' ); ?></strong> <?php echo count( $analytics ); ?>
                            | <strong><?php _e( 'Total Links Created:', 'seo-pro' ); ?></strong> <?php echo array_sum( array_column( $analytics, 'total_links' ) ); ?>
                        </p>
                    </div>
                    
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th><?php _e( 'Rank', 'seo-pro' ); ?></th>
                                <th><?php _e( 'Keyword', 'seo-pro' ); ?></th>
                                <th><?php _e( 'Target URL', 'seo-pro' ); ?></th>
                                <th><?php _e( 'Total Links Created', 'seo-pro' ); ?></th>
                                <th><?php _e( 'Last Used', 'seo-pro' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            uasort( $analytics, function( $a, $b ) {
                                return $b['total_links'] - $a['total_links'];
                            });
                            
                            $rank = 1;
                            foreach ( $analytics as $data ) : 
                            ?>
                                <tr>
                                    <td><strong>#<?php echo $rank++; ?></strong></td>
                                    <td><strong><?php echo esc_html( $data['keyword'] ); ?></strong></td>
                                    <td><a href="<?php echo esc_url( $data['url'] ); ?>" target="_blank"><?php echo esc_html( $data['url'] ); ?></a></td>
                                    <td>
                                        <span style="background: #0073aa; color: white; padding: 3px 10px; border-radius: 3px; font-weight: bold;">
                                            <?php echo number_format( $data['total_links'] ); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html( $data['last_used'] ); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <form method="post" style="margin-top: 20px;">
                        <?php wp_nonce_field( 'seo_pro_linking_settings' ); ?>
                        <button type="submit" name="reset_analytics" class="button button-secondary" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to reset all analytics data?', 'seo-pro' ); ?>');">
                            🗑️ <?php _e( 'Reset Analytics', 'seo-pro' ); ?>
                        </button>
                    </form>
                <?php else : ?>
                    <div style="text-align: center; padding: 40px;">
                        <span class="dashicons dashicons-chart-line" style="font-size: 64px; color: #ccc;"></span>
                        <p style="font-size: 16px; color: #666;"><?php _e( 'No analytics data available yet.', 'seo-pro' ); ?></p>
                        <p><?php _e( 'Links will be tracked automatically as they are created on your pages.', 'seo-pro' ); ?></p>
                    </div>
                <?php endif; ?>
            </div>
            
        <?php elseif ( $active_tab === 'settings' ) : ?>
            <!-- GLOBAL SETTINGS TAB -->
            
            <div class="seo-card">
                <h2><?php _e( '⚙️ Global Settings', 'seo-pro' ); ?></h2>
                
                <form method="post">
                    <?php wp_nonce_field( 'seo_pro_linking_settings' ); ?>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="exclude_headings"><?php _e( 'Exclude Headings', 'seo-pro' ); ?></label>
                            </th>
                            <td>
                                <label>
                                    <input type="checkbox" name="exclude_headings" id="exclude_headings" value="1" <?php checked( $exclude_headings, true ); ?>>
                                    <?php _e( 'Don\'t add links inside H1, H2, H3, H4, H5, H6 tags', 'seo-pro' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( '✅ Recommended for better SEO. Headings should remain clean and focused.', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" name="save_global_settings" class="button button-primary">
                            <?php _e( 'Save Global Settings', 'seo-pro' ); ?>
                        </button>
                    </p>
                </form>
                
                <hr style="margin: 30px 0;">
                
                <h3><?php _e( '📖 Settings Explanation', 'seo-pro' ); ?></h3>
                
                <div style="background: #f9f9f9; padding: 20px; border-radius: 5px;">
                    <h4 style="margin-top: 0;">🚫 Exclude Headings</h4>
                    <p><strong><?php _e( 'What it does:', 'seo-pro' ); ?></strong> <?php _e( 'Prevents auto-linking from adding links inside heading tags (H1-H6).', 'seo-pro' ); ?></p>
                    <p><strong><?php _e( 'Why it matters:', 'seo-pro' ); ?></strong></p>
                    <ul>
                        <li>✅ Headings are important SEO signals and should be clean</li>
                        <li>✅ Better accessibility for screen readers</li>
                        <li>✅ Improved user experience</li>
                        <li>✅ Follows SEO best practices</li>
                    </ul>
                    <p><strong><?php _e( 'Recommendation:', 'seo-pro' ); ?></strong> <span style="background: #46b450; color: white; padding: 2px 8px; border-radius: 3px;">Keep it ENABLED</span></p>
                </div>
            </div>
            
        <?php else : ?>
            <!-- FEATURE GUIDE TAB -->
            
            <div class="seo-card">
                <h2><?php _e( '📚 Advanced Features Guide', 'seo-pro' ); ?></h2>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 20px;">
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px; background: #fff;">
                        <h3 style="margin-top: 0; color: #0073aa;">🎯 Priority (1-10)</h3>
                        <p><strong>Purpose:</strong> Control which keywords are processed first.</p>
                        <p><strong>Use case:</strong> Set priority 9-10 for money keywords, 5-6 for general terms.</p>
                        <p><strong>SEO Benefit:</strong> Important pages get linked first, better link distribution.</p>
                    </div>
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px; background: #fff;">
                        <h3 style="margin-top: 0; color: #0073aa;">🔗 NoFollow</h3>
                        <p><strong>Purpose:</strong> Add rel="nofollow" attribute to links.</p>
                        <p><strong>Use case:</strong> Affiliate links, sponsored content, external resources.</p>
                        <p><strong>SEO Benefit:</strong> Control PageRank flow, avoid penalties.</p>
                    </div>
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px; background: #fff;">
                        <h3 style="margin-top: 0; color: #0073aa;">🎯 Target Blank</h3>
                        <p><strong>Purpose:</strong> Open links in new tab (with security).</p>
                        <p><strong>Use case:</strong> External links, downloads, resources.</p>
                        <p><strong>SEO Benefit:</strong> Better UX, keeps users on your site.</p>
                    </div>
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px; background: #fff;">
                        <h3 style="margin-top: 0; color: #0073aa;">📝 Title Attribute</h3>
                        <p><strong>Purpose:</strong> Add SEO-friendly tooltip to links.</p>
                        <p><strong>Use case:</strong> "Learn more about SEO tips"</p>
                        <p><strong>SEO Benefit:</strong> Better accessibility, improved SEO signals.</p>
                    </div>
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px; background: #fff;">
                        <h3 style="margin-top: 0; color: #0073aa;">🔤 Case Sensitive</h3>
                        <p><strong>Purpose:</strong> Match keywords with exact case.</p>
                        <p><strong>Use case:</strong> Brand names (iPhone, WordPress), acronyms (SEO, API).</p>
                        <p><strong>SEO Benefit:</strong> Precise targeting, brand consistency.</p>
                    </div>
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px; background: #fff;">
                        <h3 style="margin-top: 0; color: #0073aa;">1️⃣ First Only</h3>
                        <p><strong>Purpose:</strong> Link only the first occurrence of keyword.</p>
                        <p><strong>Use case:</strong> Natural linking pattern, avoid over-optimization.</p>
                        <p><strong>SEO Benefit:</strong> Better UX, follows Google guidelines.</p>
                    </div>
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px; background: #fff;">
                        <h3 style="margin-top: 0; color: #0073aa;">📄 Post Type Filter</h3>
                        <p><strong>Purpose:</strong> Show links only on specific post types.</p>
                        <p><strong>Use case:</strong> Different strategy for Posts vs Pages.</p>
                        <p><strong>SEO Benefit:</strong> Targeted internal linking strategy.</p>
                    </div>
                    
                    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 5px; background: #fff;">
                        <h3 style="margin-top: 0; color: #0073aa;">🚫 Exclude Headings</h3>
                        <p><strong>Purpose:</strong> Don't add links in H1-H6 tags.</p>
                        <p><strong>Use case:</strong> Keep headings clean for SEO.</p>
                        <p><strong>SEO Benefit:</strong> Better heading structure, improved rankings.</p>
                    </div>
                    
                </div>
                
                <hr style="margin: 30px 0;">
                
                <div style="background: #f0f6fc; border-left: 4px solid #0073aa; padding: 20px; margin-top: 30px;">
                    <h3 style="margin-top: 0;">💡 Pro Tips for Maximum SEO Impact</h3>
                    <ul style="margin: 0; line-height: 1.8;">
                        <li><strong>Priority Strategy:</strong> 10 (Homepage) → 9 (Services) → 8 (Categories) → 5-7 (Content)</li>
                        <li><strong>First Only:</strong> Enable for most keywords to avoid over-optimization</li>
                        <li><strong>NoFollow:</strong> Use for affiliate links and external resources</li>
                        <li><strong>Title Attribute:</strong> Make it descriptive and action-oriented</li>
                        <li><strong>Analytics:</strong> Monitor regularly and adjust strategy based on data</li>
                        <li><strong>Link Frequency:</strong> 1-2 links per 500 words is optimal</li>
                    </ul>
                </div>
            </div>
            
        <?php endif; ?>
        
    </div>
</div>

<style>
.seo-pro-wrap .nav-tab-wrapper {
    margin-bottom: 0;
}
.seo-pro-wrap .tablenav-pages {
    float: right;
}
.seo-pro-wrap .tablenav-pages .pagination-links {
    display: inline-block;
    margin-left: 10px;
}
.seo-pro-wrap .tablenav-pages .button {
    margin: 0 2px;
}
.seo-pro-wrap .current-page {
    width: 50px;
    text-align: center;
    margin: 0 5px;
}
.seo-auto-link-table th {
    font-weight: 600;
}
.seo-auto-link-table td {
    vertical-align: middle;
}
.advanced-row td {
    border-top: none !important;
}
.toggle-advanced .dashicons {
    transition: transform 0.3s;
}
.toggle-advanced.active .dashicons {
    transform: rotate(180deg);
}
.seo-card {
    background: #fff;
    padding: 20px;
    border: 1px solid #ccd0d4;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}
.seo-card h2 {
    margin-top: 0;
    padding-bottom: 10px;
    border-bottom: 2px solid #0073aa;
}
</style>

<script>
jQuery(document).ready(function($) {
    var nextIndex = <?php echo $total_keywords; ?>;
    
    // Toggle advanced options
    $(document).on('click', '.toggle-advanced', function() {
        var row = $(this).data('row');
        var advancedRow = $('#advanced-' + row);
        advancedRow.toggle();
        $(this).toggleClass('active');
    });
    
    // Add new row
    $('#add-row').on('click', function() {
        nextIndex++;
        var mainRow = '<tr data-index="' + nextIndex + '" class="main-row">' +
            '<td><strong>' + (nextIndex + 1) + '</strong></td>' +
            '<td><input type="text" name="keywords[]" class="regular-text" required></td>' +
            '<td><input type="url" name="urls[]" class="regular-text" required></td>' +
            '<td><input type="number" name="limits[]" value="3" min="1" max="10" style="width: 60px;"></td>' +
            '<td><select name="priorities[]" style="width: 60px;">';
        for (var i = 1; i <= 10; i++) {
            mainRow += '<option value="' + i + '"' + (i === 7 ? ' selected' : '') + '>' + i + '</option>';
        }
        mainRow += '</select></td>' +
            '<td>' +
            '<label style="margin-right: 10px;"><input type="checkbox" name="nofollows[]" value="1"> NoFollow</label>' +
            '<label style="margin-right: 10px;"><input type="checkbox" name="target_blanks[]" value="1"> New Tab</label>' +
            '<label><input type="checkbox" name="first_onlys[]" value="1"> First Only</label>' +
            '</td>' +
            '<td><button type="button" class="button button-small toggle-advanced" data-row="' + nextIndex + '"><span class="dashicons dashicons-arrow-down-alt2"></span></button></td>' +
            '<td><button type="button" class="button button-small remove-row"><span class="dashicons dashicons-trash"></span></button></td>' +
            '</tr>';
        
        var advancedRow = '<tr class="advanced-row" id="advanced-' + nextIndex + '" style="display: none;">' +
            '<td colspan="8" style="background: #f9f9f9; padding: 15px;">' +
            '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">' +
            '<div><label><strong>Title Attribute (SEO):</strong></label><br><input type="text" name="titles[]" class="regular-text" placeholder="e.g., Learn more about..."></div>' +
            '<div><label><input type="checkbox" name="case_sensitives[]" value="1"> <strong>Case Sensitive Matching</strong></label></div>' +
            '</div>' +
            '</td>' +
            '</tr>';
        
        $('#linking-table tbody').append(mainRow + advancedRow);
    });
    
    // Remove row
    $(document).on('click', '.remove-row', function() {
        var globalIndex = $(this).data('global-index');
        if (globalIndex !== undefined) {
            $('input[name="all_keywords[' + globalIndex + '][keyword]"]').remove();
            $('input[name="all_keywords[' + globalIndex + '][url]"]').remove();
            $('input[name="all_keywords[' + globalIndex + '][limit]"]').remove();
            $('input[name="all_keywords[' + globalIndex + '][priority]"]').remove();
            $('input[name="all_keywords[' + globalIndex + '][nofollow]"]').remove();
            $('input[name="all_keywords[' + globalIndex + '][target_blank]"]').remove();
            $('input[name="all_keywords[' + globalIndex + '][case_sensitive]"]').remove();
            $('input[name="all_keywords[' + globalIndex + '][first_only]"]').remove();
            $('input[name="all_keywords[' + globalIndex + '][title]"]').remove();
        }
        var row = $(this).closest('tr');
        var index = row.data('index');
        $('#advanced-' + index).remove();
        row.remove();
    });
    
    // Handle page navigation
    $('#current-page-selector').on('keypress', function(e) {
        if (e.which == 13) {
            e.preventDefault();
            var page = parseInt($(this).val());
            if (page > 0 && page <= <?php echo $total_pages; ?>) {
                window.location.href = '<?php echo admin_url( 'admin.php?page=seo-pro-auto-linking&tab=keywords' ); ?>&paged=' + page;
            }
        }
    });
    
    // BULK TEMPLATE GENERATOR
    $('#toggle-bulk-generator').on('click', function() {
        $('#bulk-generator-panel').slideToggle();
        $(this).text($(this).text().includes('Open') ? '📝 Close Bulk Generator' : '📝 Open Bulk Generator');
    });
    
    // Preview bulk keywords
    $('#preview-bulk-keywords').on('click', function() {
        var templates = $('#bulk-templates').val().trim().split('\n');
        var cities = $('#bulk-cities').val().trim().split(',').map(c => c.trim()).filter(c => c);
        var urlTemplate = $('#bulk-url').val().trim();
        
        if (!templates.length || !cities.length || !urlTemplate) {
            alert('कृपया सभी fields भरें!');
            return;
        }
        
        var preview = '<strong>Total Keywords: ' + (templates.length * cities.length) + '</strong><br><br>';
        var count = 0;
        
        cities.forEach(function(city) {
            preview += '<strong style="color: #667eea;">' + city + ':</strong><br>';
            templates.forEach(function(template) {
                if (template.trim()) {
                    var keyword = template.replace(/{CITY}/gi, city);
                    var url = urlTemplate.replace(/{CITY}/gi, city.toLowerCase().replace(/\s+/g, '-'));
                    preview += '• ' + keyword + ' → ' + url + '<br>';
                    count++;
                }
            });
            preview += '<br>';
        });
        
        $('#bulk-preview').html(preview);
    });
    
    // Generate bulk keywords
    $('#generate-bulk-keywords').on('click', function() {
        var templates = $('#bulk-templates').val().trim().split('\n');
        var cities = $('#bulk-cities').val().trim().split(',').map(c => c.trim()).filter(c => c);
        var urlTemplate = $('#bulk-url').val().trim();
        var priority = $('#bulk-priority').val();
        var limit = $('#bulk-limit').val();
        var nofollow = $('#bulk-nofollow').is(':checked');
        var targetBlank = $('#bulk-target-blank').is(':checked');
        var firstOnly = $('#bulk-first-only').is(':checked');
        
        if (!templates.length || !cities.length || !urlTemplate) {
            alert('कृपया सभी fields भरें!');
            return;
        }
        
        var totalKeywords = templates.length * cities.length;
        if (!confirm('क्या आप ' + totalKeywords + ' keywords generate करना चाहते हैं?')) {
            return;
        }
        
        // Generate and add rows
        cities.forEach(function(city) {
            templates.forEach(function(template) {
                if (template.trim()) {
                    nextIndex++;
                    var keyword = template.replace(/{CITY}/gi, city);
                    var url = urlTemplate.replace(/{CITY}/gi, city.toLowerCase().replace(/\s+/g, '-'));
                    
                    var mainRow = '<tr data-index="' + nextIndex + '" class="main-row">' +
                        '<td><strong>' + (nextIndex + 1) + '</strong></td>' +
                        '<td><input type="text" name="keywords[]" value="' + keyword + '" class="regular-text" required></td>' +
                        '<td><input type="url" name="urls[]" value="' + url + '" class="regular-text" required></td>' +
                        '<td><input type="number" name="limits[]" value="' + limit + '" min="1" max="10" style="width: 60px;"></td>' +
                        '<td><select name="priorities[]" style="width: 60px;">';
                    
                    for (var i = 1; i <= 10; i++) {
                        mainRow += '<option value="' + i + '"' + (i == priority ? ' selected' : '') + '>' + i + '</option>';
                    }
                    
                    mainRow += '</select></td>' +
                        '<td>' +
                        '<label style="margin-right: 10px;"><input type="checkbox" name="nofollows[]" value="1"' + (nofollow ? ' checked' : '') + '> NoFollow</label>' +
                        '<label style="margin-right: 10px;"><input type="checkbox" name="target_blanks[]" value="1"' + (targetBlank ? ' checked' : '') + '> New Tab</label>' +
                        '<label><input type="checkbox" name="first_onlys[]" value="1"' + (firstOnly ? ' checked' : '') + '> First Only</label>' +
                        '</td>' +
                        '<td><button type="button" class="button button-small toggle-advanced" data-row="' + nextIndex + '"><span class="dashicons dashicons-arrow-down-alt2"></span></button></td>' +
                        '<td><button type="button" class="button button-small remove-row"><span class="dashicons dashicons-trash"></span></button></td>' +
                        '</tr>';
                    
                    var advancedRow = '<tr class="advanced-row" id="advanced-' + nextIndex + '" style="display: none;">' +
                        '<td colspan="8" style="background: #f9f9f9; padding: 15px;">' +
                        '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">' +
                        '<div><label><strong>Title Attribute (SEO):</strong></label><br><input type="text" name="titles[]" class="regular-text" placeholder="e.g., Learn more about..."></div>' +
                        '<div><label><input type="checkbox" name="case_sensitives[]" value="1"> <strong>Case Sensitive Matching</strong></label></div>' +
                        '</div>' +
                        '</td>' +
                        '</tr>';
                    
                    $('#linking-table tbody').append(mainRow + advancedRow);
                }
            });
        });
        
        alert('✅ ' + totalKeywords + ' keywords successfully added!\n\nScroll down देखने के लिए और Save करना न भूलें!');
        $('#bulk-generator-panel').slideUp();
        $('#toggle-bulk-generator').text('📝 Open Bulk Generator');
        
        // Clear form
        $('#bulk-templates').val('');
        $('#bulk-cities').val('');
        $('#bulk-url').val('');
        $('#bulk-preview').html('Templates और cities enter करें preview देखने के लिए...');
    });
});
</script>
<?php
