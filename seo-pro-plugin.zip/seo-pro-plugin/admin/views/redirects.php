<?php
/**
 * Redirects View
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// Handle add/delete
if ( isset( $_POST['add_redirect'] ) && check_admin_referer( 'seo_pro_add_redirect' ) ) {
    SEO_Pro_Redirects::add_redirect(
        sanitize_text_field( $_POST['from_url'] ),
        esc_url_raw( $_POST['to_url'] ),
        intval( $_POST['redirect_type'] )
    );
    echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Redirect added!', 'seo-pro' ) . '</p></div>';
}

if ( isset( $_GET['delete'] ) && check_admin_referer( 'delete_redirect_' . $_GET['delete'] ) ) {
    SEO_Pro_Redirects::delete_redirect( intval( $_GET['delete'] ) );
    echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Redirect deleted!', 'seo-pro' ) . '</p></div>';
}

$redirects = SEO_Pro_Redirects::get_redirects();
?>
<div class="wrap seo-pro-wrap">
    <h1><?php _e( '↪️ Redirection Manager', 'seo-pro' ); ?></h1>
    
    <div class="seo-card">
        <h2><?php _e( 'Add New Redirect', 'seo-pro' ); ?></h2>
        <form method="post">
            <?php wp_nonce_field( 'seo_pro_add_redirect' ); ?>
            <table class="form-table">
                <tr>
                    <th><label for="from_url"><?php _e( 'From URL', 'seo-pro' ); ?></label></th>
                    <td><input type="text" id="from_url" name="from_url" class="regular-text" placeholder="/old-page" required></td>
                </tr>
                <tr>
                    <th><label for="to_url"><?php _e( 'To URL', 'seo-pro' ); ?></label></th>
                    <td><input type="url" id="to_url" name="to_url" class="regular-text" placeholder="https://example.com/new-page" required></td>
                </tr>
                <tr>
                    <th><label for="redirect_type"><?php _e( 'Redirect Type', 'seo-pro' ); ?></label></th>
                    <td>
                        <select id="redirect_type" name="redirect_type">
                            <option value="301"><?php _e( '301 (Permanent)', 'seo-pro' ); ?></option>
                            <option value="302"><?php _e( '302 (Temporary)', 'seo-pro' ); ?></option>
                        </select>
                    </td>
                </tr>
            </table>
            <p><button type="submit" name="add_redirect" class="button button-primary"><?php _e( 'Add Redirect', 'seo-pro' ); ?></button></p>
        </form>
    </div>
    
    <div class="seo-card">
        <h2><?php _e( 'Active Redirects', 'seo-pro' ); ?></h2>
        <?php if ( ! empty( $redirects ) ) : ?>
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e( 'From URL', 'seo-pro' ); ?></th>
                        <th><?php _e( 'To URL', 'seo-pro' ); ?></th>
                        <th><?php _e( 'Type', 'seo-pro' ); ?></th>
                        <th><?php _e( 'Hits', 'seo-pro' ); ?></th>
                        <th><?php _e( 'Action', 'seo-pro' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $redirects as $redirect ) : ?>
                        <tr>
                            <td><?php echo esc_html( $redirect->from_url ); ?></td>
                            <td><?php echo esc_html( $redirect->to_url ); ?></td>
                            <td><?php echo esc_html( $redirect->type ); ?></td>
                            <td><?php echo esc_html( $redirect->hits ); ?></td>
                            <td>
                                <a href="<?php echo wp_nonce_url( admin_url( 'admin.php?page=seo-pro-redirects&delete=' . $redirect->id ), 'delete_redirect_' . $redirect->id ); ?>" class="button button-small" onclick="return confirm('<?php _e( 'Are you sure?', 'seo-pro' ); ?>');">
                                    <?php _e( 'Delete', 'seo-pro' ); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p><?php _e( 'No redirects found.', 'seo-pro' ); ?></p>
        <?php endif; ?>
    </div>
</div>
<?php
