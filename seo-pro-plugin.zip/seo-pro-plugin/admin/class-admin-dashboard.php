<?php
/**
 * Admin Dashboard - Main dashboard class
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Admin_Dashboard {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Dashboard widgets
        add_action( 'wp_dashboard_setup', array( $this, 'add_dashboard_widgets' ) );
    }
    
    /**
     * Add dashboard widgets
     */
    public function add_dashboard_widgets() {
        wp_add_dashboard_widget(
            'seo_pro_dashboard_widget',
            __( 'SEO Pro Overview', 'seo-pro' ),
            array( $this, 'render_dashboard_widget' )
        );
    }
    
    /**
     * Render dashboard widget
     */
    public function render_dashboard_widget() {
        global $wpdb;
        
        // Get stats
        $posts_count = wp_count_posts( 'post' )->publish;
        $pages_count = wp_count_posts( 'page' )->publish;
        
        $redirects_count = 0;
        $table_name = $wpdb->prefix . 'seo_pro_redirects';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) == $table_name ) {
            $redirects_count = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" );
        }
        
        $errors_404_count = 0;
        $table_name = $wpdb->prefix . 'seo_pro_404_log';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) == $table_name ) {
            $errors_404_count = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name WHERE DATE(date) = CURDATE()" );
        }
        
        ?>
        <div class="seo-pro-dashboard-widget">
            <div class="seo-stats">
                <div class="stat-box">
                    <div class="stat-number"><?php echo esc_html( $posts_count ); ?></div>
                    <div class="stat-label"><?php _e( 'Published Posts', 'seo-pro' ); ?></div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo esc_html( $pages_count ); ?></div>
                    <div class="stat-label"><?php _e( 'Published Pages', 'seo-pro' ); ?></div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo esc_html( $redirects_count ); ?></div>
                    <div class="stat-label"><?php _e( 'Active Redirects', 'seo-pro' ); ?></div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo esc_html( $errors_404_count ); ?></div>
                    <div class="stat-label"><?php _e( '404 Errors Today', 'seo-pro' ); ?></div>
                </div>
            </div>
            
            <div class="seo-quick-links">
                <a href="<?php echo admin_url( 'admin.php?page=seo-pro' ); ?>" class="button button-primary">
                    <?php _e( 'SEO Dashboard', 'seo-pro' ); ?>
                </a>
                <a href="<?php echo home_url( '/sitemap.xml' ); ?>" class="button" target="_blank">
                    <?php _e( 'View Sitemap', 'seo-pro' ); ?>
                </a>
            </div>
        </div>
        
        <style>
            .seo-pro-dashboard-widget .seo-stats {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
                margin-bottom: 15px;
            }
            .seo-pro-dashboard-widget .stat-box {
                background: #f0f0f1;
                padding: 15px;
                border-radius: 4px;
                text-align: center;
            }
            .seo-pro-dashboard-widget .stat-number {
                font-size: 32px;
                font-weight: 600;
                color: #2271b1;
            }
            .seo-pro-dashboard-widget .stat-label {
                font-size: 13px;
                color: #646970;
                margin-top: 5px;
            }
            .seo-pro-dashboard-widget .seo-quick-links {
                display: flex;
                gap: 10px;
            }
        </style>
        <?php
    }
}
