<?php
/**
 * Plugin Name: SEO Pro - Ultimate Unlimited Edition
 * Plugin URI: https://yoursite.com/seo-pro
 * Description: World's Most Advanced FREE SEO Plugin - UNLIMITED EVERYTHING! E-E-A-T, Core Web Vitals, 150+ Features, No Limits!
 * Version: 2.0.0 UNLIMITED
 * Author: Your Name
 * Author URI: https://yoursite.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: seo-pro
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.2
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Plugin constants
define( 'SEO_PRO_VERSION', '2.0.0' );
define( 'SEO_PRO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SEO_PRO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// UNLIMITED CONSTANTS - NO LIMITS!
define( 'SEO_PRO_UNLIMITED', true );
define( 'SEO_PRO_MAX_KEYWORDS', 999999 ); // Unlimited keywords
define( 'SEO_PRO_MAX_POSTS', 999999 ); // Unlimited posts
define( 'SEO_PRO_MAX_LINKS', 999999 ); // Unlimited links
define( 'SEO_PRO_MAX_REDIRECTS', 999999 ); // Unlimited redirects
define( 'SEO_PRO_MAX_404_LOGS', 999999 ); // Unlimited 404 logs
define( 'SEO_PRO_MAX_SITEMAPS', 999999 ); // Unlimited sitemap entries
define( 'SEO_PRO_MAX_SCHEMAS', 999999 ); // Unlimited schemas
define( 'SEO_PRO_MAX_ANALYTICS', 999999 ); // Unlimited analytics data
define( 'SEO_PRO_PREMIUM_FEATURES', true ); // All premium features enabled
define( 'SEO_PRO_NO_RESTRICTIONS', true ); // No restrictions whatsoever

/**
 * Main SEO Pro Plugin Class
 */
class SEO_Pro_Plugin {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Activation/Deactivation hooks
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
        register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );
        
        // Initialize plugin
        add_action( 'plugins_loaded', array( $this, 'init' ) );
        
        // Load textdomain
        add_action( 'init', array( $this, 'load_textdomain' ) );
        
        // Check for conflicts
        add_action( 'admin_init', array( $this, 'check_conflicts' ) );
        
        // Add unlimited notice
        add_action( 'admin_notices', array( $this, 'unlimited_notice' ) );
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables
        $this->create_tables();
        
        // Set default options - ALL UNLIMITED!
        $defaults = array(
            'seo_pro_title_separator' => '|',
            'seo_pro_lazy_load' => 1,
            'seo_pro_disable_emojis' => 1,
            'seo_pro_unlimited_mode' => 1, // UNLIMITED MODE ON!
            'seo_pro_max_keywords' => 999999,
            'seo_pro_max_posts' => 999999,
            'seo_pro_max_links' => 999999,
            'seo_pro_premium_unlocked' => 1, // ALL PREMIUM FEATURES!
        );
        
        foreach ( $defaults as $key => $value ) {
            if ( ! get_option( $key ) ) {
                add_option( $key, $value );
            }
        }
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Create database tables - UNLIMITED SIZE!
     */
    private function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Redirects table - UNLIMITED
        $table_redirects = $wpdb->prefix . 'seo_pro_redirects';
        $sql_redirects = "CREATE TABLE IF NOT EXISTS $table_redirects (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            from_url varchar(2000) NOT NULL,
            to_url varchar(2000) NOT NULL,
            type int(3) NOT NULL DEFAULT 301,
            hits bigint(20) UNSIGNED NOT NULL DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY from_url (from_url(191))
        ) $charset_collate;";
        
        // 404 log table - UNLIMITED
        $table_404 = $wpdb->prefix . 'seo_pro_404_log';
        $sql_404 = "CREATE TABLE IF NOT EXISTS $table_404 (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            url varchar(2000) NOT NULL,
            referer varchar(2000) DEFAULT NULL,
            user_agent varchar(1000) DEFAULT NULL,
            ip_address varchar(100) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY url (url(191)),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql_redirects );
        dbDelta( $sql_404 );
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Load core files
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-manager.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-titles-meta.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-settings.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-metabox.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-schema.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-sitemap.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-redirects.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-404-monitor.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-auto-linking.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-breadcrumbs.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-tools.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-analytics.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-advanced-schema.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-integrations.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-audit.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-link-building.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-content-optimizer.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-eeat-analyzer.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-core-web-vitals.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-performance-optimizer.php';
        
        // NEW: Advanced Features - v2.0.0
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-noindex-manager.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-image-optimizer.php';
        require_once SEO_PRO_PLUGIN_DIR . 'includes/class-seo-mobile-optimizer.php';
        
        // Admin files
        if ( is_admin() ) {
            require_once SEO_PRO_PLUGIN_DIR . 'admin/class-admin-settings.php';
            require_once SEO_PRO_PLUGIN_DIR . 'admin/class-admin-dashboard.php';
        }
        
        // Initialize components - ALL UNLIMITED!
        SEO_Pro_Manager::instance();
        SEO_Pro_Titles_Meta::instance();
        SEO_Pro_Settings::instance();
        SEO_Pro_Metabox::instance();
        SEO_Pro_Schema::instance();
        SEO_Pro_Sitemap::instance();
        SEO_Pro_Redirects::instance();
        SEO_Pro_404_Monitor::instance();
        SEO_Pro_Auto_Linking::instance();
        SEO_Pro_Breadcrumbs::instance();
        SEO_Pro_Tools::instance();
        SEO_Pro_Analytics::instance();
        SEO_Pro_Advanced_Schema::instance();
        SEO_Pro_Integrations::instance();
        SEO_Pro_Audit::instance();
        SEO_Pro_Link_Building::instance();
        SEO_Pro_Content_Optimizer::instance();
        SEO_Pro_EEAT_Analyzer::instance();
        SEO_Pro_Core_Web_Vitals::instance();
        SEO_Pro_Performance_Optimizer::instance();
        
        // NEW: Advanced Features - v2.0.0
        SEO_Pro_Noindex_Manager::instance();
        SEO_Pro_Image_Optimizer::instance();
        SEO_Pro_Mobile_Optimizer::instance();
        
        // Initialize admin components
        if ( is_admin() ) {
            SEO_Pro_Admin_Settings::instance();
            SEO_Pro_Admin_Dashboard::instance();
        }
    }
    
    /**
     * Load textdomain
     */
    public function load_textdomain() {
        load_plugin_textdomain( 'seo-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }
    
    /**
     * Check for conflicts with other SEO plugins
     */
    public function check_conflicts() {
        $conflicting_plugins = array(
            'wordpress-seo/wp-seo.php' => 'Yoast SEO',
            'wordpress-seo-premium/wp-seo-premium.php' => 'Yoast SEO Premium',
            'seo-by-rank-math/rank-math.php' => 'Rank Math',
            'seo-by-rank-math-pro/rank-math-pro.php' => 'Rank Math PRO',
            'all-in-one-seo-pack/all_in_one_seo_pack.php' => 'All in One SEO',
            'all-in-one-seo-pack-pro/all_in_one_seo_pack.php' => 'All in One SEO Pro',
        );
        
        foreach ( $conflicting_plugins as $plugin => $name ) {
            if ( is_plugin_active( $plugin ) ) {
                add_action( 'admin_notices', function() use ( $name ) {
                    ?>
                    <div class="notice notice-warning is-dismissible">
                        <p>
                            <strong><?php _e( 'SEO Pro:', 'seo-pro' ); ?></strong>
                            <?php printf( __( 'We detected %s is active. For best results, please deactivate it to avoid conflicts.', 'seo-pro' ), $name ); ?>
                        </p>
                    </div>
                    <?php
                } );
            }
        }
    }
    
    /**
     * Show unlimited notice
     */
    public function unlimited_notice() {
        $screen = get_current_screen();
        
        if ( strpos( $screen->id, 'seo-pro' ) !== false ) {
            ?>
            <div class="notice notice-success">
                <p>
                    <strong>🚀 SEO Pro UNLIMITED Edition:</strong>
                    <?php _e( 'All features unlocked! No limits on keywords, posts, links, redirects, or any other feature. Enjoy unlimited power!', 'seo-pro' ); ?>
                </p>
            </div>
            <?php
        }
    }
}

// Initialize plugin
function seo_pro() {
    return SEO_Pro_Plugin::instance();
}

// Start the plugin
seo_pro();

/**
 * Helper functions for unlimited features
 */

// Check if unlimited mode is enabled (always true!)
function seo_pro_is_unlimited() {
    return true; // ALWAYS UNLIMITED!
}

// Get max keywords (unlimited)
function seo_pro_max_keywords() {
    return 999999; // UNLIMITED!
}

// Get max posts (unlimited)
function seo_pro_max_posts() {
    return 999999; // UNLIMITED!
}

// Get max links (unlimited)
function seo_pro_max_links() {
    return 999999; // UNLIMITED!
}

// Check if premium features are enabled (always true!)
function seo_pro_is_premium() {
    return true; // ALL PREMIUM FEATURES ENABLED!
}

// Get plugin version
function seo_pro_version() {
    return SEO_PRO_VERSION;
}

// Display unlimited badge
function seo_pro_unlimited_badge() {
    return '<span style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 4px 12px; border-radius: 12px; font-size: 11px; font-weight: 700; margin-left: 10px;">♾️ UNLIMITED</span>';
}
