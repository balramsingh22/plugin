<?php
/**
 * Uninstall SEO Pro Plugin
 * 
 * Removes all plugin data when uninstalled
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

// If uninstall not called from WordPress, exit
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// Delete all plugin options
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'seo_%'" );
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'seo_pro_%'" );

// Delete all post meta
$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_seo_pro_%'" );

// Drop custom tables
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}seo_pro_redirects" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}seo_pro_404_log" );

// Clear any cached data
wp_cache_flush();
