<?php
/**
 * SEO Advanced Schema - Additional schema types
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Advanced_Schema {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add schema metabox
        add_action( 'add_meta_boxes', array( $this, 'add_schema_metabox' ) );
        add_action( 'save_post', array( $this, 'save_schema_data' ) );
        
        // Output advanced schemas
        add_action( 'wp_head', array( $this, 'output_advanced_schemas' ), 15 );
    }
    
    /**
     * Add schema metabox
     */
    public function add_schema_metabox() {
        $post_types = array( 'post', 'page', 'rtcl_listing' );
        
        foreach ( $post_types as $post_type ) {
            add_meta_box(
                'seo_pro_advanced_schema',
                __( 'Advanced Schema', 'seo-pro' ),
                array( $this, 'render_schema_metabox' ),
                $post_type,
                'side',
                'default'
            );
        }
    }
    
    /**
     * Render schema metabox
     */
    public function render_schema_metabox( $post ) {
        wp_nonce_field( 'seo_pro_schema', 'seo_pro_schema_nonce' );
        
        $schema_type = get_post_meta( $post->ID, '_seo_pro_schema_type', true );
        $review_rating = get_post_meta( $post->ID, '_seo_pro_review_rating', true );
        $review_count = get_post_meta( $post->ID, '_seo_pro_review_count', true );
        $video_url = get_post_meta( $post->ID, '_seo_pro_video_url', true );
        $event_date = get_post_meta( $post->ID, '_seo_pro_event_date', true );
        $event_location = get_post_meta( $post->ID, '_seo_pro_event_location', true );
        
        ?>
        <p>
            <label for="seo_pro_schema_type"><strong><?php _e( 'Schema Type', 'seo-pro' ); ?></strong></label>
            <select id="seo_pro_schema_type" name="seo_pro_schema_type" style="width: 100%;">
                <option value=""><?php _e( 'None', 'seo-pro' ); ?></option>
                <option value="review" <?php selected( $schema_type, 'review' ); ?>><?php _e( 'Review/Rating', 'seo-pro' ); ?></option>
                <option value="video" <?php selected( $schema_type, 'video' ); ?>><?php _e( 'Video', 'seo-pro' ); ?></option>
                <option value="event" <?php selected( $schema_type, 'event' ); ?>><?php _e( 'Event', 'seo-pro' ); ?></option>
                <option value="howto" <?php selected( $schema_type, 'howto' ); ?>><?php _e( 'How-To', 'seo-pro' ); ?></option>
            </select>
        </p>
        
        <div id="review-fields" style="display: <?php echo $schema_type === 'review' ? 'block' : 'none'; ?>;">
            <p>
                <label for="seo_pro_review_rating"><?php _e( 'Rating (1-5)', 'seo-pro' ); ?></label>
                <input type="number" id="seo_pro_review_rating" name="seo_pro_review_rating" value="<?php echo esc_attr( $review_rating ); ?>" min="1" max="5" step="0.1" style="width: 100%;">
            </p>
            <p>
                <label for="seo_pro_review_count"><?php _e( 'Review Count', 'seo-pro' ); ?></label>
                <input type="number" id="seo_pro_review_count" name="seo_pro_review_count" value="<?php echo esc_attr( $review_count ); ?>" min="1" style="width: 100%;">
            </p>
        </div>
        
        <div id="video-fields" style="display: <?php echo $schema_type === 'video' ? 'block' : 'none'; ?>;">
            <p>
                <label for="seo_pro_video_url"><?php _e( 'Video URL', 'seo-pro' ); ?></label>
                <input type="url" id="seo_pro_video_url" name="seo_pro_video_url" value="<?php echo esc_attr( $video_url ); ?>" style="width: 100%;">
            </p>
        </div>
        
        <div id="event-fields" style="display: <?php echo $schema_type === 'event' ? 'block' : 'none'; ?>;">
            <p>
                <label for="seo_pro_event_date"><?php _e( 'Event Date', 'seo-pro' ); ?></label>
                <input type="datetime-local" id="seo_pro_event_date" name="seo_pro_event_date" value="<?php echo esc_attr( $event_date ); ?>" style="width: 100%;">
            </p>
            <p>
                <label for="seo_pro_event_location"><?php _e( 'Event Location', 'seo-pro' ); ?></label>
                <input type="text" id="seo_pro_event_location" name="seo_pro_event_location" value="<?php echo esc_attr( $event_location ); ?>" style="width: 100%;">
            </p>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('#seo_pro_schema_type').on('change', function() {
                var type = $(this).val();
                $('#review-fields, #video-fields, #event-fields').hide();
                if (type === 'review') $('#review-fields').show();
                if (type === 'video') $('#video-fields').show();
                if (type === 'event') $('#event-fields').show();
            });
        });
        </script>
        <?php
    }
    
    /**
     * Save schema data
     */
    public function save_schema_data( $post_id ) {
        if ( ! isset( $_POST['seo_pro_schema_nonce'] ) || ! wp_verify_nonce( $_POST['seo_pro_schema_nonce'], 'seo_pro_schema' ) ) {
            return;
        }
        
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
        
        $fields = array(
            '_seo_pro_schema_type' => 'sanitize_text_field',
            '_seo_pro_review_rating' => 'floatval',
            '_seo_pro_review_count' => 'intval',
            '_seo_pro_video_url' => 'esc_url_raw',
            '_seo_pro_event_date' => 'sanitize_text_field',
            '_seo_pro_event_location' => 'sanitize_text_field',
        );
        
        foreach ( $fields as $field => $sanitize_callback ) {
            $key = str_replace( '_seo_pro_', 'seo_pro_', $field );
            
            if ( isset( $_POST[ $key ] ) && $_POST[ $key ] !== '' ) {
                update_post_meta( $post_id, $field, call_user_func( $sanitize_callback, $_POST[ $key ] ) );
            } else {
                delete_post_meta( $post_id, $field );
            }
        }
    }
    
    /**
     * Output advanced schemas
     */
    public function output_advanced_schemas() {
        if ( ! is_singular() ) {
            return;
        }
        
        global $post;
        
        $schema_type = get_post_meta( $post->ID, '_seo_pro_schema_type', true );
        
        if ( empty( $schema_type ) ) {
            return;
        }
        
        $schema = null;
        
        switch ( $schema_type ) {
            case 'review':
                $schema = $this->get_review_schema( $post );
                break;
            case 'video':
                $schema = $this->get_video_schema( $post );
                break;
            case 'event':
                $schema = $this->get_event_schema( $post );
                break;
            case 'howto':
                $schema = $this->get_howto_schema( $post );
                break;
        }
        
        if ( $schema ) {
            echo "\n<!-- Advanced Schema (SEO Pro) -->\n";
            echo '<script type="application/ld+json">' . "\n";
            echo wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
            echo "\n" . '</script>' . "\n";
            echo "<!-- /Advanced Schema -->\n\n";
        }
    }
    
    /**
     * Get Review Schema
     */
    private function get_review_schema( $post ) {
        $rating = get_post_meta( $post->ID, '_seo_pro_review_rating', true );
        $count = get_post_meta( $post->ID, '_seo_pro_review_count', true );
        
        if ( empty( $rating ) ) {
            return null;
        }
        
        return array(
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => get_the_title( $post ),
            'description' => wp_trim_words( wp_strip_all_tags( get_the_excerpt( $post ) ), 30 ),
            'image' => get_the_post_thumbnail_url( $post->ID, 'full' ),
            'aggregateRating' => array(
                '@type' => 'AggregateRating',
                'ratingValue' => $rating,
                'reviewCount' => $count ? $count : 1,
                'bestRating' => '5',
                'worstRating' => '1',
            ),
        );
    }
    
    /**
     * Get Video Schema
     */
    private function get_video_schema( $post ) {
        $video_url = get_post_meta( $post->ID, '_seo_pro_video_url', true );
        
        if ( empty( $video_url ) ) {
            return null;
        }
        
        return array(
            '@context' => 'https://schema.org',
            '@type' => 'VideoObject',
            'name' => get_the_title( $post ),
            'description' => wp_trim_words( wp_strip_all_tags( get_the_excerpt( $post ) ), 30 ),
            'thumbnailUrl' => get_the_post_thumbnail_url( $post->ID, 'full' ),
            'contentUrl' => $video_url,
            'uploadDate' => get_the_date( 'c', $post ),
        );
    }
    
    /**
     * Get Event Schema
     */
    private function get_event_schema( $post ) {
        $event_date = get_post_meta( $post->ID, '_seo_pro_event_date', true );
        $event_location = get_post_meta( $post->ID, '_seo_pro_event_location', true );
        
        if ( empty( $event_date ) ) {
            return null;
        }
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Event',
            'name' => get_the_title( $post ),
            'description' => wp_trim_words( wp_strip_all_tags( get_the_excerpt( $post ) ), 30 ),
            'startDate' => date( 'c', strtotime( $event_date ) ),
            'image' => get_the_post_thumbnail_url( $post->ID, 'full' ),
        );
        
        if ( $event_location ) {
            $schema['location'] = array(
                '@type' => 'Place',
                'name' => $event_location,
            );
        }
        
        return $schema;
    }
    
    /**
     * Get HowTo Schema
     */
    private function get_howto_schema( $post ) {
        $content = get_the_content( null, false, $post );
        
        // Extract steps from content (looking for ordered lists or headings)
        $steps = array();
        
        // Simple extraction - you can make this more sophisticated
        preg_match_all( '/<li>(.*?)<\/li>/s', $content, $matches );
        
        if ( ! empty( $matches[1] ) ) {
            foreach ( $matches[1] as $index => $step_text ) {
                $steps[] = array(
                    '@type' => 'HowToStep',
                    'position' => $index + 1,
                    'text' => wp_strip_all_tags( $step_text ),
                );
            }
        }
        
        if ( empty( $steps ) ) {
            return null;
        }
        
        return array(
            '@context' => 'https://schema.org',
            '@type' => 'HowTo',
            'name' => get_the_title( $post ),
            'description' => wp_trim_words( wp_strip_all_tags( get_the_excerpt( $post ) ), 30 ),
            'image' => get_the_post_thumbnail_url( $post->ID, 'full' ),
            'step' => $steps,
        );
    }
}
