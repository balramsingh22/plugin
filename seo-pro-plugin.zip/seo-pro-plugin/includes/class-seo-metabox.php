<?php
/**
 * SEO Metabox - Post/Page SEO settings
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Metabox {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_metabox' ) );
        add_action( 'save_post', array( $this, 'save_metabox' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
    }
    
    /**
     * Add SEO meta box
     */
    public function add_metabox() {
        $post_types = get_post_types( array( 'public' => true ), 'names' );
        
        foreach ( $post_types as $post_type ) {
            add_meta_box(
                'seo_pro_metabox',
                __( 'SEO Pro Settings', 'seo-pro' ),
                array( $this, 'render_metabox' ),
                $post_type,
                'normal',
                'high'
            );
        }
    }
    
    /**
     * Enqueue scripts
     */
    public function enqueue_scripts( $hook ) {
        if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ) ) ) {
            return;
        }
        
        wp_enqueue_media();
        
        wp_add_inline_style( 'wp-admin', '
            .seo-pro-metabox { padding: 10px; }
            .seo-pro-metabox .seo-field { margin-bottom: 20px; }
            .seo-pro-metabox label { display: block; font-weight: 600; margin-bottom: 5px; }
            .seo-pro-metabox input[type="text"],
            .seo-pro-metabox textarea { width: 100%; padding: 8px; }
            .seo-pro-metabox textarea { min-height: 80px; resize: vertical; }
            .seo-pro-metabox .seo-preview { background: #f5f5f5; padding: 15px; border-radius: 4px; margin-top: 20px; }
            .seo-pro-metabox .seo-preview h4 { margin-top: 0; }
            .seo-pro-metabox .seo-preview-title { color: #1a0dab; font-size: 18px; margin-bottom: 5px; cursor: pointer; }
            .seo-pro-metabox .seo-preview-url { color: #006621; font-size: 14px; margin-bottom: 5px; }
            .seo-pro-metabox .seo-preview-description { color: #545454; font-size: 13px; line-height: 1.4; }
            .seo-pro-metabox .seo-score { padding: 10px; border-radius: 4px; margin-top: 10px; }
            .seo-pro-metabox .seo-score.good { background: #d4edda; color: #155724; }
            .seo-pro-metabox .seo-score.average { background: #fff3cd; color: #856404; }
            .seo-pro-metabox .seo-score.poor { background: #f8d7da; color: #721c24; }
            .seo-pro-metabox .char-count { font-size: 12px; color: #666; margin-top: 5px; }
            .seo-pro-metabox .char-count.good { color: #155724; }
            .seo-pro-metabox .char-count.warning { color: #856404; }
            .seo-pro-metabox .char-count.error { color: #721c24; }
        ' );
    }
    
    /**
     * Render meta box
     */
    public function render_metabox( $post ) {
        wp_nonce_field( 'seo_pro_metabox', 'seo_pro_nonce' );
        
        $focus_keyword = get_post_meta( $post->ID, '_seo_pro_focus_keyword', true );
        $title = get_post_meta( $post->ID, '_seo_pro_title', true );
        $description = get_post_meta( $post->ID, '_seo_pro_description', true );
        $keywords = get_post_meta( $post->ID, '_seo_pro_keywords', true );
        $canonical = get_post_meta( $post->ID, '_seo_pro_canonical', true );
        $noindex = get_post_meta( $post->ID, '_seo_pro_noindex', true );
        $nofollow = get_post_meta( $post->ID, '_seo_pro_nofollow', true );
        
        $default_title = get_the_title( $post );
        $default_url = get_permalink( $post );
        
        ?>
        <div class="seo-pro-metabox">
            <div class="seo-field">
                <label for="seo_pro_focus_keyword"><?php _e( 'Focus Keyword', 'seo-pro' ); ?></label>
                <input type="text" id="seo_pro_focus_keyword" name="seo_pro_focus_keyword" value="<?php echo esc_attr( $focus_keyword ); ?>" placeholder="<?php _e( 'Enter your focus keyword', 'seo-pro' ); ?>">
                <p class="description"><?php _e( 'Main keyword you want to rank for', 'seo-pro' ); ?></p>
            </div>
            
            <div class="seo-field">
                <label for="seo_pro_title"><?php _e( 'SEO Title', 'seo-pro' ); ?></label>
                <input type="text" id="seo_pro_title" name="seo_pro_title" value="<?php echo esc_attr( $title ); ?>" placeholder="<?php echo esc_attr( $default_title ); ?>">
                <div class="char-count">
                    <span id="title-length">0</span> <?php _e( 'characters (Recommended: 50-60)', 'seo-pro' ); ?>
                </div>
            </div>
            
            <div class="seo-field">
                <label for="seo_pro_description"><?php _e( 'Meta Description', 'seo-pro' ); ?></label>
                <textarea id="seo_pro_description" name="seo_pro_description" placeholder="<?php _e( 'Enter meta description', 'seo-pro' ); ?>"><?php echo esc_textarea( $description ); ?></textarea>
                <div class="char-count">
                    <span id="description-length">0</span> <?php _e( 'characters (Recommended: 150-160)', 'seo-pro' ); ?>
                </div>
            </div>
            
            <div class="seo-field">
                <label for="seo_pro_keywords"><?php _e( 'Meta Keywords', 'seo-pro' ); ?></label>
                <input type="text" id="seo_pro_keywords" name="seo_pro_keywords" value="<?php echo esc_attr( $keywords ); ?>" placeholder="keyword1, keyword2, keyword3">
                <p class="description"><?php _e( 'Comma-separated keywords', 'seo-pro' ); ?></p>
            </div>
            
            <div class="seo-field">
                <label for="seo_pro_canonical"><?php _e( 'Canonical URL', 'seo-pro' ); ?></label>
                <input type="text" id="seo_pro_canonical" name="seo_pro_canonical" value="<?php echo esc_attr( $canonical ); ?>" placeholder="<?php echo esc_url( $default_url ); ?>">
                <p class="description"><?php _e( 'Leave empty to use default permalink', 'seo-pro' ); ?></p>
            </div>
            
            <div class="seo-field">
                <label>
                    <input type="checkbox" name="seo_pro_noindex" value="1" <?php checked( $noindex, 1 ); ?>>
                    <?php _e( 'No Index (Hide from search engines)', 'seo-pro' ); ?>
                </label>
            </div>
            
            <div class="seo-field">
                <label>
                    <input type="checkbox" name="seo_pro_nofollow" value="1" <?php checked( $nofollow, 1 ); ?>>
                    <?php _e( 'No Follow (Don\'t follow links on this page)', 'seo-pro' ); ?>
                </label>
            </div>
            
            <div class="seo-preview">
                <h4><?php _e( 'Search Engine Preview', 'seo-pro' ); ?></h4>
                <div class="seo-preview-title" id="preview-title"><?php echo esc_html( $default_title ); ?></div>
                <div class="seo-preview-url"><?php echo esc_url( $default_url ); ?></div>
                <div class="seo-preview-description" id="preview-description"><?php _e( 'Your meta description will appear here...', 'seo-pro' ); ?></div>
            </div>
            
            <div class="seo-score" id="seo-score">
                <strong><?php _e( 'SEO Score:', 'seo-pro' ); ?></strong> <span id="score-value">0</span>/100
                <div id="score-feedback"></div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            function updatePreview() {
                var title = $('#seo_pro_title').val() || '<?php echo esc_js( $default_title ); ?>';
                var description = $('#seo_pro_description').val() || '<?php _e( 'Your meta description will appear here...', 'seo-pro' ); ?>';
                
                $('#preview-title').text(title);
                $('#preview-description').text(description);
                
                var titleLength = title.length;
                var descLength = description.length;
                
                $('#title-length').text(titleLength);
                $('#description-length').text(descLength);
                
                // Color code character counts
                var $titleCount = $('#title-length').parent();
                $titleCount.removeClass('good warning error');
                if (titleLength >= 50 && titleLength <= 60) {
                    $titleCount.addClass('good');
                } else if (titleLength > 0) {
                    $titleCount.addClass('warning');
                }
                
                var $descCount = $('#description-length').parent();
                $descCount.removeClass('good warning error');
                if (descLength >= 150 && descLength <= 160) {
                    $descCount.addClass('good');
                } else if (descLength > 0) {
                    $descCount.addClass('warning');
                }
                
                calculateSEOScore();
            }
            
            function calculateSEOScore() {
                var score = 0;
                var feedback = [];
                
                var title = $('#seo_pro_title').val();
                var description = $('#seo_pro_description').val();
                var focusKeyword = $('#seo_pro_focus_keyword').val().toLowerCase();
                var content = '';
                
                // Get content from editor
                if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
                    content = tinymce.get('content').getContent({format: 'text'}).toLowerCase();
                } else if ($('#content').length) {
                    content = $('#content').val().toLowerCase();
                }
                
                // Title checks
                if (title.length >= 50 && title.length <= 60) {
                    score += 15;
                } else if (title.length > 0) {
                    feedback.push('<?php _e( 'Title should be 50-60 characters', 'seo-pro' ); ?>');
                }
                
                // Description checks
                if (description.length >= 150 && description.length <= 160) {
                    score += 15;
                } else if (description.length > 0) {
                    feedback.push('<?php _e( 'Description should be 150-160 characters', 'seo-pro' ); ?>');
                }
                
                // Focus keyword checks
                if (focusKeyword) {
                    // In title
                    if (title.toLowerCase().includes(focusKeyword)) {
                        score += 20;
                    } else {
                        feedback.push('<?php _e( 'Focus keyword should be in title', 'seo-pro' ); ?>');
                    }
                    
                    // In description
                    if (description.toLowerCase().includes(focusKeyword)) {
                        score += 15;
                    } else {
                        feedback.push('<?php _e( 'Focus keyword should be in description', 'seo-pro' ); ?>');
                    }
                    
                    // In content
                    if (content.includes(focusKeyword)) {
                        score += 20;
                        
                        // Keyword density
                        var wordCount = content.split(/\s+/).length;
                        var keywordCount = (content.match(new RegExp(focusKeyword, 'g')) || []).length;
                        var density = (keywordCount / wordCount) * 100;
                        
                        if (density >= 0.5 && density <= 2.5) {
                            score += 15;
                        } else {
                            feedback.push('<?php _e( 'Keyword density should be 0.5-2.5%', 'seo-pro' ); ?>');
                        }
                    } else {
                        feedback.push('<?php _e( 'Focus keyword should be in content', 'seo-pro' ); ?>');
                    }
                } else {
                    feedback.push('<?php _e( 'Add a focus keyword', 'seo-pro' ); ?>');
                }
                
                // Update score display
                $('#score-value').text(score);
                
                var $scoreBox = $('#seo-score');
                $scoreBox.removeClass('good average poor');
                
                if (score >= 80) {
                    $scoreBox.addClass('good');
                } else if (score >= 50) {
                    $scoreBox.addClass('average');
                } else {
                    $scoreBox.addClass('poor');
                }
                
                if (feedback.length > 0) {
                    $('#score-feedback').html('<ul><li>' + feedback.join('</li><li>') + '</li></ul>');
                } else {
                    $('#score-feedback').html('<p><?php _e( 'Great! Your SEO looks good.', 'seo-pro' ); ?></p>');
                }
            }
            
            $('#seo_pro_title, #seo_pro_description, #seo_pro_focus_keyword').on('input', updatePreview);
            
            // Listen for content changes
            if (typeof tinymce !== 'undefined') {
                tinymce.on('AddEditor', function(e) {
                    e.editor.on('input change', updatePreview);
                });
            }
            $('#content').on('input', updatePreview);
            
            updatePreview();
        });
        </script>
        <?php
    }
    
    /**
     * Save meta box
     */
    public function save_metabox( $post_id ) {
        if ( ! isset( $_POST['seo_pro_nonce'] ) || ! wp_verify_nonce( $_POST['seo_pro_nonce'], 'seo_pro_metabox' ) ) {
            return;
        }
        
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
        
        $fields = array(
            '_seo_pro_focus_keyword' => 'sanitize_text_field',
            '_seo_pro_title' => 'sanitize_text_field',
            '_seo_pro_description' => 'sanitize_textarea_field',
            '_seo_pro_keywords' => 'sanitize_text_field',
            '_seo_pro_canonical' => 'esc_url_raw',
        );
        
        foreach ( $fields as $field => $sanitize_callback ) {
            $key = str_replace( '_seo_pro_', 'seo_pro_', $field );
            
            if ( isset( $_POST[ $key ] ) && $_POST[ $key ] !== '' ) {
                update_post_meta( $post_id, $field, call_user_func( $sanitize_callback, $_POST[ $key ] ) );
            } else {
                delete_post_meta( $post_id, $field );
            }
        }
        
        // Checkboxes
        $checkbox_fields = array( '_seo_pro_noindex', '_seo_pro_nofollow' );
        
        foreach ( $checkbox_fields as $field ) {
            $key = str_replace( '_seo_pro_', 'seo_pro_', $field );
            
            if ( isset( $_POST[ $key ] ) && $_POST[ $key ] == '1' ) {
                update_post_meta( $post_id, $field, 1 );
            } else {
                delete_post_meta( $post_id, $field );
            }
        }
    }
}
