<?php
/**
 * SEO Analytics - Advanced SEO analytics and reporting
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Analytics {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add analytics menu
        add_action( 'admin_menu', array( $this, 'add_analytics_menu' ), 25 );
        
        // Track SEO scores
        add_action( 'save_post', array( $this, 'track_seo_score' ), 20, 2 );
    }
    
    /**
     * Add analytics menu
     */
    public function add_analytics_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'SEO Analytics', 'seo-pro' ),
            __( 'Analytics', 'seo-pro' ),
            'manage_options',
            'seo-pro-analytics',
            array( $this, 'render_analytics_page' )
        );
    }
    
    /**
     * Track SEO score
     */
    public function track_seo_score( $post_id, $post ) {
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
            return;
        }
        
        $focus_keyword = get_post_meta( $post_id, '_seo_pro_focus_keyword', true );
        $title = get_post_meta( $post_id, '_seo_pro_title', true );
        $description = get_post_meta( $post_id, '_seo_pro_description', true );
        
        $score = $this->calculate_seo_score( $post_id, $focus_keyword, $title, $description );
        
        update_post_meta( $post_id, '_seo_pro_score', $score );
        update_post_meta( $post_id, '_seo_pro_score_date', current_time( 'mysql' ) );
    }
    
    /**
     * Calculate SEO score
     */
    private function calculate_seo_score( $post_id, $focus_keyword, $title, $description ) {
        $score = 0;
        $post = get_post( $post_id );
        $content = $post->post_content;
        
        // Title checks (20 points)
        if ( ! empty( $title ) ) {
            $title_length = strlen( $title );
            if ( $title_length >= 50 && $title_length <= 60 ) {
                $score += 10;
            }
            if ( ! empty( $focus_keyword ) && stripos( $title, $focus_keyword ) !== false ) {
                $score += 10;
            }
        }
        
        // Description checks (20 points)
        if ( ! empty( $description ) ) {
            $desc_length = strlen( $description );
            if ( $desc_length >= 150 && $desc_length <= 160 ) {
                $score += 10;
            }
            if ( ! empty( $focus_keyword ) && stripos( $description, $focus_keyword ) !== false ) {
                $score += 10;
            }
        }
        
        // Content checks (40 points)
        if ( ! empty( $focus_keyword ) && ! empty( $content ) ) {
            $content_text = wp_strip_all_tags( $content );
            
            // Keyword in content
            if ( stripos( $content_text, $focus_keyword ) !== false ) {
                $score += 15;
                
                // Keyword density
                $word_count = str_word_count( $content_text );
                $keyword_count = substr_count( strtolower( $content_text ), strtolower( $focus_keyword ) );
                $density = ( $keyword_count / $word_count ) * 100;
                
                if ( $density >= 0.5 && $density <= 2.5 ) {
                    $score += 15;
                }
            }
            
            // Content length
            if ( $word_count >= 300 ) {
                $score += 10;
            }
        }
        
        // Image alt text (10 points)
        if ( has_post_thumbnail( $post_id ) ) {
            $score += 5;
        }
        
        // Internal links (10 points)
        $internal_links = substr_count( $content, home_url() );
        if ( $internal_links >= 3 ) {
            $score += 10;
        } elseif ( $internal_links > 0 ) {
            $score += 5;
        }
        
        return min( 100, $score );
    }
    
    /**
     * Render analytics page
     */
    public function render_analytics_page() {
        global $wpdb;
        
        // Get all posts with SEO scores - UNLIMITED!
        $posts_with_scores = $wpdb->get_results( "
            SELECT p.ID, p.post_title, p.post_type, pm.meta_value as score
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_seo_pro_score'
            WHERE p.post_status = 'publish'
            AND p.post_type IN ('post', 'page', 'rtcl_listing')
            ORDER BY CAST(pm.meta_value AS UNSIGNED) DESC
        " );
        
        // Calculate averages
        $total_posts = count( $posts_with_scores );
        $total_score = 0;
        $score_distribution = array(
            'excellent' => 0, // 80-100
            'good' => 0,      // 60-79
            'average' => 0,   // 40-59
            'poor' => 0,      // 0-39
        );
        
        foreach ( $posts_with_scores as $post_data ) {
            $score = intval( $post_data->score );
            $total_score += $score;
            
            if ( $score >= 80 ) {
                $score_distribution['excellent']++;
            } elseif ( $score >= 60 ) {
                $score_distribution['good']++;
            } elseif ( $score >= 40 ) {
                $score_distribution['average']++;
            } else {
                $score_distribution['poor']++;
            }
        }
        
        $average_score = $total_posts > 0 ? round( $total_score / $total_posts ) : 0;
        
        ?>
        <div class="wrap seo-pro-wrap">
            <h1><?php _e( '📊 SEO Analytics Dashboard', 'seo-pro' ); ?></h1>
            
            <!-- Overview Cards -->
            <div class="seo-analytics-overview">
                <div class="analytics-card">
                    <div class="card-icon">📝</div>
                    <div class="card-content">
                        <div class="card-value"><?php echo esc_html( $total_posts ); ?></div>
                        <div class="card-label"><?php _e( 'Total Posts Analyzed', 'seo-pro' ); ?></div>
                    </div>
                </div>
                
                <div class="analytics-card">
                    <div class="card-icon">⭐</div>
                    <div class="card-content">
                        <div class="card-value"><?php echo esc_html( $average_score ); ?>/100</div>
                        <div class="card-label"><?php _e( 'Average SEO Score', 'seo-pro' ); ?></div>
                    </div>
                </div>
                
                <div class="analytics-card">
                    <div class="card-icon">✅</div>
                    <div class="card-content">
                        <div class="card-value"><?php echo esc_html( $score_distribution['excellent'] ); ?></div>
                        <div class="card-label"><?php _e( 'Excellent Posts (80+)', 'seo-pro' ); ?></div>
                    </div>
                </div>
                
                <div class="analytics-card">
                    <div class="card-icon">⚠️</div>
                    <div class="card-content">
                        <div class="card-value"><?php echo esc_html( $score_distribution['poor'] ); ?></div>
                        <div class="card-label"><?php _e( 'Needs Improvement (<40)', 'seo-pro' ); ?></div>
                    </div>
                </div>
            </div>
            
            <!-- Score Distribution Chart -->
            <div class="seo-card">
                <h2><?php _e( 'SEO Score Distribution', 'seo-pro' ); ?></h2>
                <div class="score-distribution-chart">
                    <div class="chart-bar excellent" style="width: <?php echo $total_posts > 0 ? ( $score_distribution['excellent'] / $total_posts * 100 ) : 0; ?>%;">
                        <span class="bar-label"><?php echo esc_html( $score_distribution['excellent'] ); ?> Excellent (80-100)</span>
                    </div>
                    <div class="chart-bar good" style="width: <?php echo $total_posts > 0 ? ( $score_distribution['good'] / $total_posts * 100 ) : 0; ?>%;">
                        <span class="bar-label"><?php echo esc_html( $score_distribution['good'] ); ?> Good (60-79)</span>
                    </div>
                    <div class="chart-bar average" style="width: <?php echo $total_posts > 0 ? ( $score_distribution['average'] / $total_posts * 100 ) : 0; ?>%;">
                        <span class="bar-label"><?php echo esc_html( $score_distribution['average'] ); ?> Average (40-59)</span>
                    </div>
                    <div class="chart-bar poor" style="width: <?php echo $total_posts > 0 ? ( $score_distribution['poor'] / $total_posts * 100 ) : 0; ?>%;">
                        <span class="bar-label"><?php echo esc_html( $score_distribution['poor'] ); ?> Poor (0-39)</span>
                    </div>
                </div>
            </div>
            
            <!-- Top/Bottom Performing Posts -->
            <div class="seo-card">
                <h2><?php _e( 'Post Performance', 'seo-pro' ); ?></h2>
                
                <?php if ( ! empty( $posts_with_scores ) ) : ?>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th><?php _e( 'Post Title', 'seo-pro' ); ?></th>
                                <th><?php _e( 'Type', 'seo-pro' ); ?></th>
                                <th><?php _e( 'SEO Score', 'seo-pro' ); ?></th>
                                <th><?php _e( 'Status', 'seo-pro' ); ?></th>
                                <th><?php _e( 'Action', 'seo-pro' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $posts_with_scores as $post_data ) : 
                                $score = intval( $post_data->score );
                                $status_class = '';
                                $status_text = '';
                                
                                if ( $score >= 80 ) {
                                    $status_class = 'excellent';
                                    $status_text = __( 'Excellent', 'seo-pro' );
                                } elseif ( $score >= 60 ) {
                                    $status_class = 'good';
                                    $status_text = __( 'Good', 'seo-pro' );
                                } elseif ( $score >= 40 ) {
                                    $status_class = 'average';
                                    $status_text = __( 'Average', 'seo-pro' );
                                } else {
                                    $status_class = 'poor';
                                    $status_text = __( 'Poor', 'seo-pro' );
                                }
                            ?>
                                <tr>
                                    <td><?php echo esc_html( $post_data->post_title ); ?></td>
                                    <td><?php echo esc_html( $post_data->post_type ); ?></td>
                                    <td><strong><?php echo esc_html( $score ); ?>/100</strong></td>
                                    <td><span class="seo-status <?php echo esc_attr( $status_class ); ?>"><?php echo esc_html( $status_text ); ?></span></td>
                                    <td>
                                        <a href="<?php echo get_edit_post_link( $post_data->ID ); ?>" class="button button-small">
                                            <?php _e( 'Edit', 'seo-pro' ); ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <p><?php _e( 'No posts analyzed yet. Start optimizing your content!', 'seo-pro' ); ?></p>
                <?php endif; ?>
            </div>
        </div>
        
        <style>
            .seo-analytics-overview {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .analytics-card {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                padding: 20px;
                border-radius: 8px;
                display: flex;
                align-items: center;
                gap: 15px;
            }
            .analytics-card:nth-child(2) {
                background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            }
            .analytics-card:nth-child(3) {
                background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            }
            .analytics-card:nth-child(4) {
                background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            }
            .analytics-card .card-icon {
                font-size: 40px;
            }
            .analytics-card .card-value {
                font-size: 32px;
                font-weight: 700;
            }
            .analytics-card .card-label {
                font-size: 13px;
                opacity: 0.9;
            }
            .score-distribution-chart {
                margin-top: 20px;
            }
            .chart-bar {
                height: 50px;
                margin-bottom: 10px;
                display: flex;
                align-items: center;
                padding: 0 15px;
                border-radius: 4px;
                color: #fff;
                font-weight: 600;
                transition: all 0.3s;
            }
            .chart-bar:hover {
                transform: translateX(5px);
            }
            .chart-bar.excellent {
                background: linear-gradient(90deg, #00a32a 0%, #00d936 100%);
            }
            .chart-bar.good {
                background: linear-gradient(90deg, #2271b1 0%, #4a9eff 100%);
            }
            .chart-bar.average {
                background: linear-gradient(90deg, #f0b849 0%, #ffcf5c 100%);
            }
            .chart-bar.poor {
                background: linear-gradient(90deg, #d63638 0%, #ff5a5f 100%);
            }
            .seo-status {
                padding: 4px 12px;
                border-radius: 12px;
                font-size: 12px;
                font-weight: 600;
            }
            .seo-status.excellent {
                background: #d4edda;
                color: #155724;
            }
            .seo-status.good {
                background: #d1ecf1;
                color: #0c5460;
            }
            .seo-status.average {
                background: #fff3cd;
                color: #856404;
            }
            .seo-status.poor {
                background: #f8d7da;
                color: #721c24;
            }
        </style>
        <?php
    }
}
