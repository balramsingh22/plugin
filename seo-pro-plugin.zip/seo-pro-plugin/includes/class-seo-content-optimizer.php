<?php
/**
 * SEO Content Optimizer - Readability score & LSI keywords
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Content_Optimizer {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add content optimizer to metabox
        add_action( 'add_meta_boxes', array( $this, 'add_content_optimizer_metabox' ) );
    }
    
    /**
     * Add content optimizer metabox
     */
    public function add_content_optimizer_metabox() {
        $post_types = array( 'post', 'page', 'rtcl_listing' );
        
        foreach ( $post_types as $post_type ) {
            add_meta_box(
                'seo_pro_content_optimizer',
                __( '📝 Content Optimizer', 'seo-pro' ),
                array( $this, 'render_content_optimizer_metabox' ),
                $post_type,
                'normal',
                'high'
            );
        }
    }
    
    /**
     * Render content optimizer metabox
     */
    public function render_content_optimizer_metabox( $post ) {
        $content = $post->post_content;
        $content_text = wp_strip_all_tags( $content );
        
        // Calculate readability score
        $readability = $this->calculate_readability( $content_text );
        
        // Get LSI keywords
        $focus_keyword = get_post_meta( $post->ID, '_seo_pro_focus_keyword', true );
        $lsi_keywords = $this->get_lsi_keywords( $focus_keyword );
        
        // Content statistics
        $word_count = str_word_count( $content_text );
        $sentence_count = $this->count_sentences( $content_text );
        $paragraph_count = substr_count( $content, '</p>' );
        $avg_words_per_sentence = $sentence_count > 0 ? round( $word_count / $sentence_count, 1 ) : 0;
        
        ?>
        <div class="content-optimizer-wrap">
            <!-- Readability Score -->
            <div class="optimizer-section">
                <h3><?php _e( 'Readability Score', 'seo-pro' ); ?></h3>
                <div class="readability-score">
                    <div class="score-circle <?php echo $this->get_readability_class( $readability['score'] ); ?>">
                        <span class="score-value"><?php echo esc_html( $readability['score'] ); ?></span>
                        <span class="score-max">/100</span>
                    </div>
                    <div class="score-details">
                        <p><strong><?php echo esc_html( $readability['level'] ); ?></strong></p>
                        <p><?php echo esc_html( $readability['description'] ); ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Content Statistics -->
            <div class="optimizer-section">
                <h3><?php _e( 'Content Statistics', 'seo-pro' ); ?></h3>
                <div class="content-stats">
                    <div class="stat-item">
                        <span class="stat-label"><?php _e( 'Word Count:', 'seo-pro' ); ?></span>
                        <span class="stat-value <?php echo $word_count >= 300 ? 'good' : 'warning'; ?>">
                            <?php echo esc_html( $word_count ); ?>
                        </span>
                        <?php if ( $word_count < 300 ) : ?>
                            <span class="stat-hint"><?php _e( '(Recommended: 300+)', 'seo-pro' ); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="stat-item">
                        <span class="stat-label"><?php _e( 'Sentences:', 'seo-pro' ); ?></span>
                        <span class="stat-value"><?php echo esc_html( $sentence_count ); ?></span>
                    </div>
                    
                    <div class="stat-item">
                        <span class="stat-label"><?php _e( 'Paragraphs:', 'seo-pro' ); ?></span>
                        <span class="stat-value"><?php echo esc_html( $paragraph_count ); ?></span>
                    </div>
                    
                    <div class="stat-item">
                        <span class="stat-label"><?php _e( 'Avg Words/Sentence:', 'seo-pro' ); ?></span>
                        <span class="stat-value <?php echo $avg_words_per_sentence <= 20 ? 'good' : 'warning'; ?>">
                            <?php echo esc_html( $avg_words_per_sentence ); ?>
                        </span>
                        <?php if ( $avg_words_per_sentence > 20 ) : ?>
                            <span class="stat-hint"><?php _e( '(Keep under 20)', 'seo-pro' ); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- LSI Keywords -->
            <?php if ( ! empty( $focus_keyword ) ) : ?>
                <div class="optimizer-section">
                    <h3><?php _e( 'LSI Keywords (Latent Semantic Indexing)', 'seo-pro' ); ?></h3>
                    <p class="description"><?php _e( 'Use these related keywords naturally in your content to improve SEO.', 'seo-pro' ); ?></p>
                    
                    <?php if ( ! empty( $lsi_keywords ) ) : ?>
                        <div class="lsi-keywords">
                            <?php foreach ( $lsi_keywords as $keyword ) : 
                                $used = stripos( $content_text, $keyword ) !== false;
                            ?>
                                <span class="lsi-keyword <?php echo $used ? 'used' : ''; ?>">
                                    <?php echo esc_html( $keyword ); ?>
                                    <?php if ( $used ) : ?>
                                        <span class="checkmark">✓</span>
                                    <?php endif; ?>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <p><?php _e( 'No LSI keywords found. Try a different focus keyword.', 'seo-pro' ); ?></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <!-- Readability Tips -->
            <div class="optimizer-section">
                <h3><?php _e( '💡 Readability Tips', 'seo-pro' ); ?></h3>
                <ul class="readability-tips">
                    <li><?php _e( 'Use short sentences (15-20 words)', 'seo-pro' ); ?></li>
                    <li><?php _e( 'Break content into short paragraphs (3-4 sentences)', 'seo-pro' ); ?></li>
                    <li><?php _e( 'Use headings (H2, H3) to structure content', 'seo-pro' ); ?></li>
                    <li><?php _e( 'Use bullet points and numbered lists', 'seo-pro' ); ?></li>
                    <li><?php _e( 'Avoid complex words and jargon', 'seo-pro' ); ?></li>
                    <li><?php _e( 'Use active voice instead of passive', 'seo-pro' ); ?></li>
                    <li><?php _e( 'Add images to break up text', 'seo-pro' ); ?></li>
                </ul>
            </div>
        </div>
        
        <style>
            .content-optimizer-wrap {
                background: #fff;
                padding: 15px;
            }
            .optimizer-section {
                margin-bottom: 25px;
                padding-bottom: 20px;
                border-bottom: 1px solid #f0f0f1;
            }
            .optimizer-section:last-child {
                border-bottom: none;
            }
            .optimizer-section h3 {
                margin-top: 0;
                color: #1d2327;
            }
            .readability-score {
                display: flex;
                align-items: center;
                gap: 20px;
            }
            .score-circle {
                width: 100px;
                height: 100px;
                border-radius: 50%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                border: 4px solid;
                background: #f9f9f9;
            }
            .score-circle.excellent {
                border-color: #00a32a;
                color: #00a32a;
            }
            .score-circle.good {
                border-color: #2271b1;
                color: #2271b1;
            }
            .score-circle.average {
                border-color: #f0b849;
                color: #f0b849;
            }
            .score-circle.poor {
                border-color: #d63638;
                color: #d63638;
            }
            .score-value {
                font-size: 32px;
                font-weight: 700;
            }
            .score-max {
                font-size: 14px;
            }
            .score-details strong {
                font-size: 16px;
            }
            .content-stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 15px;
            }
            .stat-item {
                background: #f9f9f9;
                padding: 12px;
                border-radius: 4px;
            }
            .stat-label {
                display: block;
                font-size: 13px;
                color: #666;
                margin-bottom: 5px;
            }
            .stat-value {
                font-size: 24px;
                font-weight: 700;
                color: #1d2327;
            }
            .stat-value.good {
                color: #00a32a;
            }
            .stat-value.warning {
                color: #f0b849;
            }
            .stat-hint {
                display: block;
                font-size: 11px;
                color: #666;
                margin-top: 3px;
            }
            .lsi-keywords {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                margin-top: 10px;
            }
            .lsi-keyword {
                background: #f0f0f1;
                padding: 6px 12px;
                border-radius: 12px;
                font-size: 13px;
                display: inline-flex;
                align-items: center;
                gap: 5px;
            }
            .lsi-keyword.used {
                background: #d4edda;
                color: #155724;
            }
            .lsi-keyword .checkmark {
                color: #00a32a;
                font-weight: 700;
            }
            .readability-tips {
                margin: 10px 0;
                padding-left: 20px;
            }
            .readability-tips li {
                margin-bottom: 8px;
                line-height: 1.5;
            }
        </style>
        <?php
    }
    
    /**
     * Calculate readability score (Flesch Reading Ease)
     */
    private function calculate_readability( $text ) {
        $word_count = str_word_count( $text );
        $sentence_count = $this->count_sentences( $text );
        $syllable_count = $this->count_syllables( $text );
        
        if ( $word_count === 0 || $sentence_count === 0 ) {
            return array(
                'score' => 0,
                'level' => 'N/A',
                'description' => 'Add content to calculate readability.',
            );
        }
        
        // Flesch Reading Ease formula
        $score = 206.835 - 1.015 * ( $word_count / $sentence_count ) - 84.6 * ( $syllable_count / $word_count );
        $score = max( 0, min( 100, round( $score ) ) );
        
        // Determine level
        if ( $score >= 90 ) {
            $level = 'Very Easy';
            $description = 'Easily understood by an average 11-year-old student.';
        } elseif ( $score >= 80 ) {
            $level = 'Easy';
            $description = 'Conversational English for consumers.';
        } elseif ( $score >= 70 ) {
            $level = 'Fairly Easy';
            $description = 'Easily understood by 13- to 15-year-old students.';
        } elseif ( $score >= 60 ) {
            $level = 'Standard';
            $description = 'Easily understood by 15- to 17-year-old students.';
        } elseif ( $score >= 50 ) {
            $level = 'Fairly Difficult';
            $description = 'Fairly difficult to read.';
        } elseif ( $score >= 30 ) {
            $level = 'Difficult';
            $description = 'Difficult to read. Best understood by college graduates.';
        } else {
            $level = 'Very Difficult';
            $description = 'Very difficult to read. Best understood by university graduates.';
        }
        
        return array(
            'score' => $score,
            'level' => $level,
            'description' => $description,
        );
    }
    
    /**
     * Count sentences
     */
    private function count_sentences( $text ) {
        $text = preg_replace( '/\s+/', ' ', $text );
        $sentences = preg_split( '/[.!?]+/', $text, -1, PREG_SPLIT_NO_EMPTY );
        return count( $sentences );
    }
    
    /**
     * Count syllables (simplified)
     */
    private function count_syllables( $text ) {
        $words = str_word_count( strtolower( $text ), 1 );
        $syllable_count = 0;
        
        foreach ( $words as $word ) {
            $syllable_count += $this->count_word_syllables( $word );
        }
        
        return $syllable_count;
    }
    
    /**
     * Count syllables in a word
     */
    private function count_word_syllables( $word ) {
        $word = strtolower( trim( $word ) );
        $syllables = 0;
        
        // Count vowel groups
        $vowels = array( 'a', 'e', 'i', 'o', 'u', 'y' );
        $previous_was_vowel = false;
        
        for ( $i = 0; $i < strlen( $word ); $i++ ) {
            $is_vowel = in_array( $word[ $i ], $vowels );
            
            if ( $is_vowel && ! $previous_was_vowel ) {
                $syllables++;
            }
            
            $previous_was_vowel = $is_vowel;
        }
        
        // Adjust for silent 'e'
        if ( substr( $word, -1 ) === 'e' ) {
            $syllables--;
        }
        
        // Minimum 1 syllable per word
        return max( 1, $syllables );
    }
    
    /**
     * Get LSI keywords
     */
    private function get_lsi_keywords( $focus_keyword ) {
        if ( empty( $focus_keyword ) ) {
            return array();
        }
        
        // Generate LSI keywords based on focus keyword
        $lsi_keywords = array();
        
        // Common LSI patterns
        $patterns = array(
            'best ' . $focus_keyword,
            $focus_keyword . ' service',
            $focus_keyword . ' near me',
            'cheap ' . $focus_keyword,
            'affordable ' . $focus_keyword,
            $focus_keyword . ' online',
            'top ' . $focus_keyword,
            $focus_keyword . ' reviews',
            $focus_keyword . ' guide',
            'how to ' . $focus_keyword,
        );
        
        // Filter and return unique keywords
        foreach ( $patterns as $pattern ) {
            if ( strlen( $pattern ) <= 50 ) {
                $lsi_keywords[] = $pattern;
            }
        }
        
        return array_slice( array_unique( $lsi_keywords ), 0, 10 );
    }
    
    /**
     * Get readability class
     */
    private function get_readability_class( $score ) {
        if ( $score >= 70 ) {
            return 'excellent';
        } elseif ( $score >= 60 ) {
            return 'good';
        } elseif ( $score >= 50 ) {
            return 'average';
        }
        return 'poor';
    }
}
