<?php
/**
 * SEO Tools - Additional SEO utilities
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Tools {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Image alt text optimizer
        add_filter( 'wp_get_attachment_image_attributes', array( $this, 'optimize_image_alt' ), 10, 2 );
        
        // Add settings page
        add_action( 'admin_menu', array( $this, 'add_tools_menu' ), 20 );
    }
    
    /**
     * Optimize image alt text
     */
    public function optimize_image_alt( $attr, $attachment ) {
        // If alt is empty, use image title or filename
        if ( empty( $attr['alt'] ) ) {
            $alt = get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );
            
            if ( empty( $alt ) ) {
                $alt = $attachment->post_title;
            }
            
            if ( empty( $alt ) ) {
                $alt = basename( get_attached_file( $attachment->ID ), '.' . pathinfo( get_attached_file( $attachment->ID ), PATHINFO_EXTENSION ) );
                $alt = str_replace( array( '-', '_' ), ' ', $alt );
            }
            
            $attr['alt'] = $alt;
        }
        
        return $attr;
    }
    
    /**
     * Add tools menu
     */
    public function add_tools_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'SEO Tools', 'seo-pro' ),
            __( 'Tools', 'seo-pro' ),
            'manage_options',
            'seo-pro-tools',
            array( $this, 'render_tools_page' )
        );
    }
    
    /**
     * Render tools page
     */
    public function render_tools_page() {
        // Handle robots.txt update
        if ( isset( $_POST['update_robots'] ) && check_admin_referer( 'seo_pro_robots' ) ) {
            update_option( 'seo_pro_robots_txt', wp_kses_post( $_POST['robots_content'] ) );
            echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Robots.txt updated!', 'seo-pro' ) . '</p></div>';
        }
        
        // Handle import
        if ( isset( $_POST['import_settings'] ) && check_admin_referer( 'seo_pro_import' ) ) {
            if ( ! empty( $_FILES['import_file']['tmp_name'] ) ) {
                $json = file_get_contents( $_FILES['import_file']['tmp_name'] );
                $settings = json_decode( $json, true );
                
                if ( $settings && is_array( $settings ) ) {
                    foreach ( $settings as $key => $value ) {
                        update_option( $key, $value );
                    }
                    echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Settings imported successfully!', 'seo-pro' ) . '</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>' . __( 'Invalid import file!', 'seo-pro' ) . '</p></div>';
                }
            }
        }
        
        // Handle export
        if ( isset( $_POST['export_settings'] ) && check_admin_referer( 'seo_pro_export' ) ) {
            $this->export_settings();
            return;
        }
        
        $robots_content = get_option( 'seo_pro_robots_txt', $this->get_default_robots() );
        
        ?>
        <div class="wrap seo-pro-wrap">
            <h1><?php _e( '🛠️ SEO Tools', 'seo-pro' ); ?></h1>
            
            <!-- Robots.txt Editor -->
            <div class="seo-card">
                <h2><?php _e( 'Robots.txt Editor', 'seo-pro' ); ?></h2>
                <p><?php _e( 'Edit your robots.txt file content. This will override the default WordPress robots.txt.', 'seo-pro' ); ?></p>
                
                <form method="post">
                    <?php wp_nonce_field( 'seo_pro_robots' ); ?>
                    <textarea name="robots_content" rows="15" style="width: 100%; font-family: monospace;"><?php echo esc_textarea( $robots_content ); ?></textarea>
                    <p>
                        <button type="submit" name="update_robots" class="button button-primary"><?php _e( 'Update Robots.txt', 'seo-pro' ); ?></button>
                        <a href="<?php echo home_url( '/robots.txt' ); ?>" target="_blank" class="button"><?php _e( 'View Robots.txt', 'seo-pro' ); ?></a>
                    </p>
                </form>
            </div>
            
            <!-- Import/Export Settings -->
            <div class="seo-card">
                <h2><?php _e( 'Import/Export Settings', 'seo-pro' ); ?></h2>
                
                <h3><?php _e( 'Export Settings', 'seo-pro' ); ?></h3>
                <p><?php _e( 'Download all SEO Pro settings as a JSON file.', 'seo-pro' ); ?></p>
                <form method="post">
                    <?php wp_nonce_field( 'seo_pro_export' ); ?>
                    <button type="submit" name="export_settings" class="button"><?php _e( 'Export Settings', 'seo-pro' ); ?></button>
                </form>
                
                <hr>
                
                <h3><?php _e( 'Import Settings', 'seo-pro' ); ?></h3>
                <p><?php _e( 'Upload a previously exported JSON file to restore settings.', 'seo-pro' ); ?></p>
                <form method="post" enctype="multipart/form-data">
                    <?php wp_nonce_field( 'seo_pro_import' ); ?>
                    <input type="file" name="import_file" accept=".json" required>
                    <button type="submit" name="import_settings" class="button"><?php _e( 'Import Settings', 'seo-pro' ); ?></button>
                </form>
            </div>
            
            <!-- Bulk Actions -->
            <div class="seo-card">
                <h2><?php _e( 'Bulk Actions', 'seo-pro' ); ?></h2>
                <p><?php _e( 'Perform bulk SEO operations.', 'seo-pro' ); ?></p>
                
                <p>
                    <a href="<?php echo admin_url( 'edit.php?post_type=post' ); ?>" class="button">
                        <?php _e( 'Bulk Edit Posts', 'seo-pro' ); ?>
                    </a>
                    <a href="<?php echo admin_url( 'edit.php?post_type=page' ); ?>" class="button">
                        <?php _e( 'Bulk Edit Pages', 'seo-pro' ); ?>
                    </a>
                    <?php if ( post_type_exists( 'rtcl_listing' ) ) : ?>
                        <a href="<?php echo admin_url( 'edit.php?post_type=rtcl_listing' ); ?>" class="button">
                            <?php _e( 'Bulk Edit Listings', 'seo-pro' ); ?>
                        </a>
                    <?php endif; ?>
                </p>
            </div>
            
            <!-- Flush Rewrite Rules -->
            <div class="seo-card">
                <h2><?php _e( 'Flush Rewrite Rules', 'seo-pro' ); ?></h2>
                <p><?php _e( 'If sitemaps or redirects are not working, flush rewrite rules.', 'seo-pro' ); ?></p>
                <form method="post">
                    <?php wp_nonce_field( 'seo_pro_flush' ); ?>
                    <button type="submit" name="flush_rules" class="button" onclick="return confirm('<?php _e( 'Are you sure?', 'seo-pro' ); ?>');">
                        <?php _e( 'Flush Rewrite Rules', 'seo-pro' ); ?>
                    </button>
                </form>
                <?php
                if ( isset( $_POST['flush_rules'] ) && check_admin_referer( 'seo_pro_flush' ) ) {
                    flush_rewrite_rules();
                    echo '<div class="notice notice-success inline"><p>' . __( 'Rewrite rules flushed!', 'seo-pro' ) . '</p></div>';
                }
                ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Get default robots.txt
     */
    private function get_default_robots() {
        $site_url = parse_url( site_url(), PHP_URL_HOST );
        
        return "User-agent: *
Disallow: /wp-admin/
Disallow: /wp-includes/
Disallow: /wp-content/plugins/
Disallow: /wp-content/themes/
Allow: /wp-content/uploads/

Sitemap: " . home_url( '/sitemap.xml' );
    }
    
    /**
     * Export settings
     */
    private function export_settings() {
        $settings = array();
        
        // Get all SEO Pro options
        global $wpdb;
        $options = $wpdb->get_results( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE 'seo_%'" );
        
        foreach ( $options as $option ) {
            $settings[ $option->option_name ] = maybe_unserialize( $option->option_value );
        }
        
        $json = wp_json_encode( $settings, JSON_PRETTY_PRINT );
        
        header( 'Content-Type: application/json' );
        header( 'Content-Disposition: attachment; filename="seo-pro-settings-' . date( 'Y-m-d' ) . '.json"' );
        echo $json;
        exit;
    }
}

// Override robots.txt
add_filter( 'robots_txt', function( $output, $public ) {
    $custom_robots = get_option( 'seo_pro_robots_txt' );
    
    if ( $custom_robots ) {
        return $custom_robots;
    }
    
    return $output;
}, 10, 2 );
