<?php
/**
 * SEO Performance Optimizer - Remove unwanted code & make site ultra-fast
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Performance_Optimizer {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add Performance menu
        add_action( 'admin_menu', array( $this, 'add_performance_menu' ), 60 );
        
        // Apply optimizations
        $this->apply_optimizations();
    }
    
    /**
     * Add Performance menu
     */
    public function add_performance_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'Performance', 'seo-pro' ),
            __( 'Performance', 'seo-pro' ),
            'manage_options',
            'seo-pro-performance',
            array( $this, 'render_performance_page' )
        );
    }
    
    /**
     * Apply optimizations
     */
    private function apply_optimizations() {
        // Remove WordPress bloat
        if ( get_option( 'seo_pro_remove_wp_bloat', 1 ) ) {
            $this->remove_wordpress_bloat();
        }
        
        // Disable emojis
        if ( get_option( 'seo_pro_disable_emojis', 1 ) ) {
            $this->disable_emojis();
        }
        
        // Remove query strings
        if ( get_option( 'seo_pro_remove_query_strings', 1 ) ) {
            $this->remove_query_strings();
        }
        
        // Defer JavaScript
        if ( get_option( 'seo_pro_defer_javascript', 1 ) ) {
            add_filter( 'script_loader_tag', array( $this, 'defer_scripts' ), 10, 2 );
            // Add cleanup filter at very high priority to fix duplicates from other plugins
            add_filter( 'script_loader_tag', array( $this, 'cleanup_script_tags' ), 999, 2 );
        }
        
        // Defer CSS (disabled - causes issues)
        // Add CSS cleanup filter to fix broken tags from other plugins/themes
        add_filter( 'style_loader_tag', array( $this, 'cleanup_css_tags' ), 999, 2 );
        
        // Remove unnecessary meta tags
        if ( get_option( 'seo_pro_remove_meta_tags', 1 ) ) {
            $this->remove_unnecessary_meta();
        }
        
        // HTML Minification
        if ( get_option( 'seo_pro_minify_html', 0 ) || get_option( 'seo_pro_minify_html_full', 0 ) ) {
            add_action( 'template_redirect', array( $this, 'start_html_minification' ), 0 );
        }
        
        // Optimize database
        if ( get_option( 'seo_pro_optimize_database', 0 ) ) {
            add_action( 'wp_scheduled_delete', array( $this, 'optimize_database' ) );
        }
        
        // Mobile Performance Optimizations
        if ( get_option( 'seo_pro_mobile_optimization', 1 ) ) {
            add_action( 'wp_head', array( $this, 'add_mobile_optimizations' ), 1 );
            add_filter( 'wp_lazy_loading_enabled', '__return_true' );
        }
        
        // Preconnect to external domains
        add_action( 'wp_head', array( $this, 'add_resource_hints' ), 1 );
        
        // Optimize images for mobile
        add_filter( 'wp_get_attachment_image_attributes', array( $this, 'optimize_image_attributes' ), 10, 2 );

    }
    
    /**
     * Remove WordPress bloat
     */
    private function remove_wordpress_bloat() {
        // Remove WP version
        remove_action( 'wp_head', 'wp_generator' );
        
        // Remove RSD link
        remove_action( 'wp_head', 'rsd_link' );
        
        // Remove wlwmanifest link
        remove_action( 'wp_head', 'wlwmanifest_link' );
        
        // Remove shortlink
        remove_action( 'wp_head', 'wp_shortlink_wp_head' );
        
        // Remove REST API link
        remove_action( 'wp_head', 'rest_output_link_wp_head' );
        
        // Remove oEmbed discovery links
        remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
        
        // Remove feed links
        remove_action( 'wp_head', 'feed_links', 2 );
        remove_action( 'wp_head', 'feed_links_extra', 3 );
        
        // Remove DNS prefetch
        add_filter( 'wp_resource_hints', array( $this, 'remove_dns_prefetch' ), 10, 2 );
    }
    
    /**
     * Disable emojis
     */
    private function disable_emojis() {
        remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
        remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
        remove_action( 'wp_print_styles', 'print_emoji_styles' );
        remove_action( 'admin_print_styles', 'print_emoji_styles' );
        remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
        remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
        remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
        
        add_filter( 'tiny_mce_plugins', array( $this, 'disable_emojis_tinymce' ) );
        add_filter( 'wp_resource_hints', array( $this, 'disable_emojis_dns_prefetch' ), 10, 2 );
    }
    
    /**
     * Remove query strings
     */
    private function remove_query_strings() {
        add_filter( 'script_loader_src', array( $this, 'remove_query_string' ), 15, 1 );
        add_filter( 'style_loader_src', array( $this, 'remove_query_string' ), 15, 1 );
    }
    
    /**
     * Remove unnecessary meta tags
     */
    private function remove_unnecessary_meta() {
        // Remove adjacent posts links
        remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head' );
        
        // Remove Windows Live Writer
        remove_action( 'wp_head', 'wlwmanifest_link' );
        
        // Remove index link
        remove_action( 'wp_head', 'index_rel_link' );
        
        // Remove start link
        remove_action( 'wp_head', 'start_post_rel_link' );
        
        // Remove parent post link
        remove_action( 'wp_head', 'parent_post_rel_link' );
    }
    
    /**
     * Defer scripts - BULLETPROOF VERSION (No Duplicates)
     */
    public function defer_scripts( $tag, $handle ) {
        // Don't defer jQuery and critical scripts
        $critical_scripts = array( 'jquery', 'jquery-core', 'jquery-migrate' );
        
        if ( in_array( $handle, $critical_scripts ) ) {
            return $tag;
        }
        
        // FIRST: Clean up any duplicate defer/async attributes (fix existing issues)
        // Remove duplicate "defer defer" or "async async"
        $tag = preg_replace( '/\bdefer\s+defer\b/', 'defer', $tag );
        $tag = preg_replace( '/\basync\s+async\b/', 'async', $tag );
        
        // Check if defer or async already exists (multiple patterns)
        // Pattern 1: defer as standalone attribute
        // Pattern 2: defer="defer"
        // Pattern 3: async as standalone or async="async"
        if ( 
            stripos( $tag, ' defer' ) !== false || 
            stripos( $tag, ' async' ) !== false ||
            preg_match( '/\bdefer\b/i', $tag ) || 
            preg_match( '/\basync\b/i', $tag )
        ) {
            // Already has defer or async, don't add again
            return $tag;
        }
        
        // Add defer attribute (only if not already present)
        return str_replace( ' src', ' defer src', $tag );
    }
    
    /**
     * Cleanup Script tags - Fix duplicate defer/async from other plugins/themes
     * This runs at priority 999 to clean up after all other filters
     */
    public function cleanup_script_tags( $tag, $handle ) {
        // Remove duplicate "defer defer" or "defer  defer" (with multiple spaces)
        $tag = preg_replace( '/\bdefer\s+defer\b/i', 'defer', $tag );
        
        // Remove duplicate "async async" or "async  async"
        $tag = preg_replace( '/\basync\s+async\b/i', 'async', $tag );
        
        // Remove triple or more duplicates (just in case)
        $tag = preg_replace( '/(\bdefer\b\s*){2,}/i', 'defer ', $tag );
        $tag = preg_replace( '/(\basync\b\s*){2,}/i', 'async ', $tag );
        
        // Clean up extra spaces that might be left
        $tag = preg_replace( '/\s{2,}/', ' ', $tag );
        
        return $tag;
    }

    
    /**
     * Cleanup CSS tags - Fix broken tags from other plugins/themes
     * This runs at priority 999 to clean up after all other filters
     */
    public function cleanup_css_tags( $html, $handle ) {
        // Fix duplicate onload attributes
        // Pattern: media='print' onload="this.media='print' onload="this.media='all'""
        // Should be: media='all'
        
        // Remove the broken pattern completely and restore normal CSS loading
        $html = preg_replace(
            '/media=[\'"]print[\'"]\\s+onload=["\']this\\.media=[\'"]print[\'"]\\s+onload=["\']this\\.media=[\'"]all[\'"]["\']["\']/',
            'media=\'all\'',
            $html
        );
        
        // Also fix single onload pattern (in case it exists)
        $html = preg_replace(
            '/media=[\'"]print[\'"]\\s+onload=["\']this\\.media=[\'"]all[\'"]["\']/',
            'media=\'all\'',
            $html
        );
        
        // Remove any remaining duplicate quotes
        $html = preg_replace('/""/', '"', $html);
        
        return $html;
    }
    
    /**
     * Defer styles - DISABLED (causes layout issues)
     */
    public function defer_styles( $html, $handle ) {
        // CSS defer disabled - it causes FOUC and layout breaking
        // CSS should load synchronously for proper rendering
        return $html;
        
        /* DISABLED CODE - DO NOT USE
        // Don't defer critical CSS
        $critical_styles = array( 'admin-bar', 'dashicons' );
        
        if ( in_array( $handle, $critical_styles ) ) {
            return $html;
        }
        
        // Add media="print" and onload to defer CSS
        $html = str_replace( "media='all'", "media='print' onload=\"this.media='all'\"", $html );
        
        return $html;
        */
    }
    
    /**
     * Remove query string
     */
    public function remove_query_string( $src ) {
        if ( strpos( $src, '?ver=' ) ) {
            $src = remove_query_arg( 'ver', $src );
        }
        return $src;
    }
    
    /**
     * Remove DNS prefetch
     */
    public function remove_dns_prefetch( $urls, $relation_type ) {
        if ( 'dns-prefetch' === $relation_type ) {
            return array();
        }
        return $urls;
    }
    
    /**
     * Add mobile-specific optimizations
     */
    public function add_mobile_optimizations() {
        // Viewport meta for mobile
        echo '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5, user-scalable=yes">' . "\n";
        
        // Mobile-friendly meta
        echo '<meta name="mobile-web-app-capable" content="yes">' . "\n";
        echo '<meta name="apple-mobile-web-app-capable" content="yes">' . "\n";
        echo '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">' . "\n";
        
        // Reduce mobile data usage
        echo '<meta http-equiv="Accept-CH" content="DPR, Viewport-Width, Width">' . "\n";
    }
    
    /**
     * Add resource hints for faster loading
     */
    public function add_resource_hints() {
        // Preconnect to critical domains
        $domains = array(
            'https://fonts.googleapis.com',
            'https://fonts.gstatic.com',
        );
        
        foreach ( $domains as $domain ) {
            echo '<link rel="preconnect" href="' . esc_url( $domain ) . '" crossorigin>' . "\n";
            echo '<link rel="dns-prefetch" href="' . esc_url( $domain ) . '">' . "\n";
        }
        
        // Preload critical resources
        echo '<link rel="preload" as="style" href="' . get_stylesheet_uri() . '">' . "\n";
    }
    
    /**
     * Optimize image attributes for mobile
     */
    public function optimize_image_attributes( $attr, $attachment ) {
        // Add loading="lazy" for better mobile performance
        if ( ! isset( $attr['loading'] ) ) {
            $attr['loading'] = 'lazy';
        }
        
        // Add decoding="async" for non-blocking image decode
        if ( ! isset( $attr['decoding'] ) ) {
            $attr['decoding'] = 'async';
        }
        
        // Add fetchpriority for above-the-fold images
        if ( ! isset( $attr['fetchpriority'] ) && is_singular() ) {
            // First image gets high priority
            static $first_image = true;
            if ( $first_image ) {
                $attr['fetchpriority'] = 'high';
                $attr['loading'] = 'eager'; // Don't lazy load first image
                $first_image = false;
            }
        }
        
        return $attr;
    }
    
    /**
     * Disable emojis in TinyMCE
     */
    public function disable_emojis_tinymce( $plugins ) {
        if ( is_array( $plugins ) ) {
            return array_diff( $plugins, array( 'wpemoji' ) );
        }
        return array();
    }
    
    /**
     * Disable emojis DNS prefetch
     */
    public function disable_emojis_dns_prefetch( $urls, $relation_type ) {
        if ( 'dns-prefetch' === $relation_type ) {
            $emoji_svg_url = apply_filters( 'emoji_svg_url', 'https://s.w.org/images/core/emoji/2/svg/' );
            $urls = array_diff( $urls, array( $emoji_svg_url ) );
        }
        return $urls;
    }
    
    /**
     * Optimize database
     */
    public function optimize_database() {
        global $wpdb;
        
        // Clean post revisions
        $wpdb->query( "DELETE FROM $wpdb->posts WHERE post_type = 'revision'" );
        
        // Clean auto-drafts
        $wpdb->query( "DELETE FROM $wpdb->posts WHERE post_status = 'auto-draft'" );
        
        // Clean trashed posts
        $wpdb->query( "DELETE FROM $wpdb->posts WHERE post_status = 'trash'" );
        
        // Clean spam comments
        $wpdb->query( "DELETE FROM $wpdb->comments WHERE comment_approved = 'spam'" );
        
        // Clean trashed comments
        $wpdb->query( "DELETE FROM $wpdb->comments WHERE comment_approved = 'trash'" );
        
        // Clean orphaned post meta
        $wpdb->query( "DELETE pm FROM $wpdb->postmeta pm LEFT JOIN $wpdb->posts wp ON wp.ID = pm.post_id WHERE wp.ID IS NULL" );
        
        // Clean orphaned comment meta
        $wpdb->query( "DELETE FROM $wpdb->commentmeta WHERE comment_id NOT IN (SELECT comment_id FROM $wpdb->comments)" );
        
        // Optimize tables
        $tables = $wpdb->get_results( "SHOW TABLES", ARRAY_N );
        foreach ( $tables as $table ) {
            $wpdb->query( "OPTIMIZE TABLE {$table[0]}" );
        }
    }
    
    /**
     * Start HTML minification
     */
    public function start_html_minification() {
        // Don't minify admin pages, AJAX requests, or feeds
        if ( is_admin() || defined( 'DOING_AJAX' ) || is_feed() || is_robots() || is_trackback() ) {
            return;
        }
        
        ob_start( array( $this, 'minify_html_output' ) );
    }
    
    /**
     * Minify HTML output - DUAL MODE VERSION
     */
    public function minify_html_output( $html ) {
        // Quick validation
        if ( empty( $html ) || strlen( $html ) < 100 ) {
            return $html;
        }
        
        // Check if it's HTML
        if ( stripos( $html, '<html' ) === false && stripos( $html, '<!DOCTYPE' ) === false ) {
            return $html;
        }
        
        // Check which mode is enabled
        $full_minify = get_option( 'seo_pro_minify_html_full', 0 );
        
        if ( $full_minify ) {
            // FULL AGGRESSIVE MINIFICATION - Single line output
            return $this->minify_html_aggressive( $html );
        } else {
            // ULTRA-SAFE MINIFICATION - Only remove comments and line whitespace
            return $this->minify_html_safe( $html );
        }
    }
    
    /**
     * Safe HTML minification - removes comments and excess whitespace only
     */
    private function minify_html_safe( $html ) {
        // Remove HTML comments (keep IE conditional)
        $html = preg_replace( '/<!--(?!\[if)(?!<!)[^\[<>].*?-->/s', '', $html );
        
        // Remove leading whitespace from lines
        $html = preg_replace( '/^\s+/m', '', $html );
        
        // Remove trailing whitespace from lines
        $html = preg_replace( '/\s+$/m', '', $html );
        
        // Remove multiple consecutive blank lines
        $html = preg_replace( '/\n\n+/', "\n", $html );
        
        return trim( $html );
    }
    
    /**
     * Aggressive HTML minification - removes ALL whitespace, creates single-line output
     */
    private function minify_html_aggressive( $html ) {
        // Protect <pre>, <textarea>, <script>, and <style> content
        $protected = array();
        $protect_tags = array( 'pre', 'textarea', 'script', 'style' );
        
        foreach ( $protect_tags as $tag ) {
            if ( preg_match_all( '/<' . $tag . '[^>]*>.*?<\/' . $tag . '>/is', $html, $matches ) ) {
                foreach ( $matches[0] as $i => $match ) {
                    $placeholder = '___PROTECTED_' . strtoupper( $tag ) . '_' . $i . '___';
                    $protected[ $placeholder ] = $match;
                    $html = str_replace( $match, $placeholder, $html );
                }
            }
        }
        
        // Remove HTML comments (keep IE conditional comments)
        $html = preg_replace( '/<!--(?!\[if)(?!<!)[^\[<>].*?-->/s', '', $html );
        
        // Remove whitespace between tags
        $html = preg_replace( '/>\s+</', '><', $html );
        
        // Remove ALL newlines and carriage returns
        $html = str_replace( array( "\r\n", "\r", "\n" ), '', $html );
        
        // Remove multiple spaces (but keep single spaces within tags)
        $html = preg_replace( '/\s{2,}/', ' ', $html );
        
        // Remove spaces around = in attributes
        $html = preg_replace( '/\s*=\s*/', '=', $html );
        
        // Remove spaces after opening tags and before closing tags
        $html = preg_replace( '/(<[^\/][^>]*>)\s+/', '$1', $html );
        $html = preg_replace( '/\s+(<\/[^>]+>)/', '$1', $html );
        
        // Restore protected content
        foreach ( $protected as $placeholder => $content ) {
            $html = str_replace( $placeholder, $content, $html );
        }
        
        return trim( $html );
    }

    
    /**
     * Render Performance page
     */
    public function render_performance_page() {
        // Handle form submission
        if ( isset( $_POST['save_performance'] ) && check_admin_referer( 'seo_pro_performance' ) ) {
            update_option( 'seo_pro_remove_wp_bloat', isset( $_POST['remove_wp_bloat'] ) ? 1 : 0 );
            update_option( 'seo_pro_disable_emojis', isset( $_POST['disable_emojis'] ) ? 1 : 0 );
            update_option( 'seo_pro_remove_query_strings', isset( $_POST['remove_query_strings'] ) ? 1 : 0 );
            update_option( 'seo_pro_defer_javascript', isset( $_POST['defer_javascript'] ) ? 1 : 0 );
            update_option( 'seo_pro_defer_css', isset( $_POST['defer_css'] ) ? 1 : 0 );
            update_option( 'seo_pro_remove_meta_tags', isset( $_POST['remove_meta_tags'] ) ? 1 : 0 );
            update_option( 'seo_pro_minify_html', isset( $_POST['minify_html'] ) ? 1 : 0 );
            update_option( 'seo_pro_minify_html_full', isset( $_POST['minify_html_full'] ) ? 1 : 0 );
            update_option( 'seo_pro_optimize_database', isset( $_POST['optimize_database'] ) ? 1 : 0 );
            update_option( 'seo_pro_mobile_optimization', isset( $_POST['mobile_optimization'] ) ? 1 : 0 );
            
            echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Performance settings saved!', 'seo-pro' ) . '</p></div>';
        }
        
        // Handle manual optimization
        if ( isset( $_POST['optimize_now'] ) && check_admin_referer( 'seo_pro_performance' ) ) {
            $this->optimize_database();
            echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Database optimized successfully!', 'seo-pro' ) . '</p></div>';
        }
        
        $remove_wp_bloat = get_option( 'seo_pro_remove_wp_bloat', 1 );
        $disable_emojis = get_option( 'seo_pro_disable_emojis', 1 );
        $remove_query_strings = get_option( 'seo_pro_remove_query_strings', 1 );
        $defer_javascript = get_option( 'seo_pro_defer_javascript', 1 );
        $defer_css = get_option( 'seo_pro_defer_css', 1 );
        $remove_meta_tags = get_option( 'seo_pro_remove_meta_tags', 1 );
        $minify_html = get_option( 'seo_pro_minify_html', 0 );
        $optimize_database = get_option( 'seo_pro_optimize_database', 0 );
        $mobile_optimization = get_option( 'seo_pro_mobile_optimization', 1 );

        
        ?>
        <div class="wrap seo-pro-wrap">
            <h1><?php _e( '⚡ Performance Optimizer', 'seo-pro' ); ?></h1>
            <p><?php _e( 'Remove unwanted code and make your site ultra-fast!', 'seo-pro' ); ?></p>
            
            <form method="post">
                <?php wp_nonce_field( 'seo_pro_performance' ); ?>
                
                <!-- Remove WordPress Bloat -->
                <div class="seo-card">
                    <h2><?php _e( '🗑️ Remove WordPress Bloat', 'seo-pro' ); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><?php _e( 'Remove WP Bloat', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="remove_wp_bloat" value="1" <?php checked( $remove_wp_bloat, 1 ); ?>>
                                    <?php _e( 'Remove unnecessary WordPress code from <head>', 'seo-pro' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( 'Removes: WP version, RSD link, wlwmanifest, shortlink, REST API link, oEmbed, feed links', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Disable Emojis', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="disable_emojis" value="1" <?php checked( $disable_emojis, 1 ); ?>>
                                    <?php _e( 'Disable WordPress emoji scripts and styles', 'seo-pro' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( 'Saves 2 HTTP requests and reduces page size', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Remove Meta Tags', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="remove_meta_tags" value="1" <?php checked( $remove_meta_tags, 1 ); ?>>
                                    <?php _e( 'Remove unnecessary meta tags', 'seo-pro' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( 'Removes: adjacent posts, Windows Live Writer, index/start links', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Optimize Resources -->
                <div class="seo-card">
                    <h2><?php _e( '🚀 Optimize Resources', 'seo-pro' ); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><?php _e( 'Remove Query Strings', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="remove_query_strings" value="1" <?php checked( $remove_query_strings, 1 ); ?>>
                                    <?php _e( 'Remove ?ver= from CSS and JS files', 'seo-pro' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( 'Improves caching and GTmetrix score', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Defer JavaScript', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="defer_javascript" value="1" <?php checked( $defer_javascript, 1 ); ?>>
                                    <?php _e( 'Defer non-critical JavaScript', 'seo-pro' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( 'Improves page load speed (jQuery excluded)', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Defer CSS', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="defer_css" value="1" <?php checked( $defer_css, 1 ); ?> disabled>
                                    <?php _e( 'Defer non-critical CSS (Disabled)', 'seo-pro' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( '⚠️ This feature is disabled as it causes layout breaking and FOUC (Flash of Unstyled Content). Not recommended for production sites.', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Minify HTML', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="minify_html" value="1" <?php checked( $minify_html, 1 ); ?>>
                                    <?php _e( 'Minify HTML (Ultra-Safe)', 'seo-pro' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( 'Removes comments and line whitespace only - won\'t interfere with scripts/styles (reduces page size by 3-5%)', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Full HTML Minification', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="minify_html_full" value="1" <?php checked( get_option( 'seo_pro_minify_html_full', 0 ), 1 ); ?>>
                                    <?php _e( 'Full HTML Minification (Aggressive)', 'seo-pro' ); ?>
                                </label>
                                <p class="description" style="color: #d63638;">
                                    <?php _e( '⚡ <strong>ADVANCED:</strong> Removes ALL whitespace and newlines - creates single-line HTML output like: &lt;!DOCTYPE html&gt;&lt;html lang="en"&gt;&lt;head&gt;&lt;meta charset="UTF-8"&gt;... (reduces page size by 10-15%)', 'seo-pro' ); ?>
                                    <br>
                                    <?php _e( '⚠️ <strong>WARNING:</strong> This is very aggressive! Test thoroughly before using on production. Protects &lt;pre&gt;, &lt;textarea&gt;, &lt;script&gt;, and &lt;style&gt; tags.', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Mobile Optimization -->
                <div class="seo-card">
                    <h2><?php _e( '📱 Mobile Optimization', 'seo-pro' ); ?></h2>
                    <p><?php _e( 'Boost your mobile PageSpeed score to 90+', 'seo-pro' ); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th><?php _e( 'Mobile Performance', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="mobile_optimization" value="1" <?php checked( $mobile_optimization, 1 ); ?>>
                                    <?php _e( 'Enable mobile-specific optimizations', 'seo-pro' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( '✅ Adds viewport meta tags, resource hints, preconnect, lazy loading, and image optimization for mobile devices', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Database Optimization -->
                <div class="seo-card">
                    <h2><?php _e( '💾 Database Optimization', 'seo-pro' ); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><?php _e( 'Auto-Optimize Database', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="optimize_database" value="1" <?php checked( $optimize_database, 1 ); ?>>
                                    <?php _e( 'Automatically optimize database weekly', 'seo-pro' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( 'Cleans revisions, auto-drafts, spam, and optimizes tables', 'seo-pro' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                    
                    <p>
                        <button type="submit" name="optimize_now" class="button button-secondary">
                            <?php _e( 'Optimize Database Now', 'seo-pro' ); ?>
                        </button>
                    </p>
                </div>
                
                <!-- Performance Tips -->
                <div class="seo-card">
                    <h2><?php _e( '💡 Performance Tips', 'seo-pro' ); ?></h2>
                    
                    <div class="tips-grid">
                        <div class="tip-box">
                            <h3><?php _e( 'What Gets Removed', 'seo-pro' ); ?></h3>
                            <ul>
                                <li>✅ <?php _e( 'WordPress version number', 'seo-pro' ); ?></li>
                                <li>✅ <?php _e( 'RSD and wlwmanifest links', 'seo-pro' ); ?></li>
                                <li>✅ <?php _e( 'Shortlink and REST API links', 'seo-pro' ); ?></li>
                                <li>✅ <?php _e( 'oEmbed discovery links', 'seo-pro' ); ?></li>
                                <li>✅ <?php _e( 'RSS feed links', 'seo-pro' ); ?></li>
                                <li>✅ <?php _e( 'Emoji scripts and styles', 'seo-pro' ); ?></li>
                                <li>✅ <?php _e( 'Query strings (?ver=)', 'seo-pro' ); ?></li>
                                <li>✅ <?php _e( 'HTML whitespace & comments', 'seo-pro' ); ?></li>
                            </ul>
                        </div>
                        
                        <div class="tip-box">
                            <h3><?php _e( 'Expected Results', 'seo-pro' ); ?></h3>
                            <ul>
                                <li>⚡ <?php _e( 'Faster page load time', 'seo-pro' ); ?></li>
                                <li>⚡ <?php _e( 'Reduced HTTP requests', 'seo-pro' ); ?></li>
                                <li>⚡ <?php _e( 'Smaller page size', 'seo-pro' ); ?></li>
                                <li>⚡ <?php _e( 'Better GTmetrix score', 'seo-pro' ); ?></li>
                                <li>⚡ <?php _e( 'Improved PageSpeed score', 'seo-pro' ); ?></li>
                                <li>⚡ <?php _e( 'Cleaner HTML code', 'seo-pro' ); ?></li>
                                <li>⚡ <?php _e( 'Better caching', 'seo-pro' ); ?></li>
                            </ul>
                        </div>
                        
                        <div class="tip-box">
                            <h3><?php _e( 'Additional Tips', 'seo-pro' ); ?></h3>
                            <ul>
                                <li>💡 <?php _e( 'Use a caching plugin', 'seo-pro' ); ?></li>
                                <li>💡 <?php _e( 'Optimize images (WebP)', 'seo-pro' ); ?></li>
                                <li>💡 <?php _e( 'Use a CDN', 'seo-pro' ); ?></li>
                                <li>💡 <?php _e( 'Enable GZIP compression', 'seo-pro' ); ?></li>
                                <li>💡 <?php _e( 'Minify CSS/JS', 'seo-pro' ); ?></li>
                                <li>💡 <?php _e( 'Reduce plugins', 'seo-pro' ); ?></li>
                                <li>💡 <?php _e( 'Use fast hosting', 'seo-pro' ); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <p>
                    <button type="submit" name="save_performance" class="button button-primary button-large">
                        <?php _e( 'Save Performance Settings', 'seo-pro' ); ?>
                    </button>
                </p>
            </form>
        </div>
        
        <style>
            .tips-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }
            .tip-box {
                background: #f9f9f9;
                padding: 15px;
                border-radius: 6px;
                border-left: 4px solid #00a32a;
            }
            .tip-box h3 {
                margin-top: 0;
                color: #00a32a;
            }
            .tip-box ul {
                margin: 10px 0;
                padding-left: 20px;
            }
            .tip-box li {
                margin-bottom: 8px;
                line-height: 1.5;
            }
        </style>
        <?php
    }
}

// Initialize
SEO_Pro_Performance_Optimizer::instance();
