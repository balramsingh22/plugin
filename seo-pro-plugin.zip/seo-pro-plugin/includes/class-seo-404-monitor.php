<?php
/**
 * SEO 404 Monitor - Track 404 errors
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_404_Monitor {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        add_action( 'template_redirect', array( $this, 'log_404_error' ) );
    }
    
    /**
     * Log 404 error
     */
    public function log_404_error() {
        if ( ! is_404() ) {
            return;
        }
        
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'seo_pro_404_log';
        
        // Check if table exists
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) != $table_name ) {
            return;
        }
        
        $url = $_SERVER['REQUEST_URI'];
        $referer = isset( $_SERVER['HTTP_REFERER'] ) ? $_SERVER['HTTP_REFERER'] : '';
        $user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $ip_address = $this->get_ip_address();
        
        // Insert log entry
        $wpdb->insert(
            $table_name,
            array(
                'url' => $url,
                'referer' => $referer,
                'user_agent' => $user_agent,
                'ip_address' => $ip_address,
            ),
            array( '%s', '%s', '%s', '%s' )
        );
        
        // Clean old entries - UNLIMITED! (Keep all logs)
        // No automatic deletion - user can manually clear if needed
    }
    
    /**
     * Get IP address
     */
    private function get_ip_address() {
        if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            return $_SERVER['REMOTE_ADDR'];
        }
    }
    
    /**
     * Get 404 logs
     */
    public static function get_logs( $limit = 100 ) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'seo_pro_404_log';
        
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $table_name ORDER BY id DESC LIMIT %d",
            $limit
        ) );
    }
    
    /**
     * Clear logs
     */
    public static function clear_logs() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'seo_pro_404_log';
        
        return $wpdb->query( "TRUNCATE TABLE $table_name" );
    }
    
    /**
     * Get log count
     */
    public static function get_log_count() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'seo_pro_404_log';
        
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" );
    }
}
