<?php
/**
 * SEO Breadcrumbs - Frontend breadcrumb display
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Breadcrumbs {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Shortcode for breadcrumbs
        add_shortcode( 'seo_pro_breadcrumbs', array( $this, 'breadcrumbs_shortcode' ) );
    }
    
    /**
     * Breadcrumbs shortcode
     */
    public function breadcrumbs_shortcode( $atts ) {
        $atts = shortcode_atts( array(
            'separator' => '›',
            'home_text' => 'Home',
        ), $atts );
        
        ob_start();
        $this->display_breadcrumbs( $atts['separator'], $atts['home_text'] );
        return ob_get_clean();
    }
    
    /**
     * Display breadcrumbs
     */
    public function display_breadcrumbs( $separator = '›', $home_text = 'Home' ) {
        if ( is_front_page() ) {
            return;
        }
        
        $breadcrumbs = $this->get_breadcrumb_items();
        
        if ( empty( $breadcrumbs ) ) {
            return;
        }
        
        echo '<nav class="seo-pro-breadcrumbs" aria-label="Breadcrumb">';
        echo '<ol itemscope itemtype="https://schema.org/BreadcrumbList">';
        
        $position = 1;
        $total = count( $breadcrumbs );
        
        foreach ( $breadcrumbs as $index => $crumb ) {
            $is_last = ( $index === $total - 1 );
            
            echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
            
            if ( ! $is_last && $crumb['url'] ) {
                echo '<a itemprop="item" href="' . esc_url( $crumb['url'] ) . '">';
                echo '<span itemprop="name">' . esc_html( $crumb['title'] ) . '</span>';
                echo '</a>';
            } else {
                echo '<span itemprop="name">' . esc_html( $crumb['title'] ) . '</span>';
            }
            
            echo '<meta itemprop="position" content="' . esc_attr( $position++ ) . '">';
            echo '</li>';
            
            if ( ! $is_last ) {
                echo '<li class="separator">' . esc_html( $separator ) . '</li>';
            }
        }
        
        echo '</ol>';
        echo '</nav>';
        
        // Add basic CSS
        echo '<style>
            .seo-pro-breadcrumbs { margin: 20px 0; font-size: 14px; }
            .seo-pro-breadcrumbs ol { list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; gap: 5px; }
            .seo-pro-breadcrumbs li { display: inline; }
            .seo-pro-breadcrumbs a { color: #2271b1; text-decoration: none; }
            .seo-pro-breadcrumbs a:hover { text-decoration: underline; }
            .seo-pro-breadcrumbs .separator { color: #666; margin: 0 5px; }
        </style>';
    }
    
    /**
     * Get breadcrumb items
     */
    private function get_breadcrumb_items() {
        $breadcrumbs = array();
        
        // Home
        $breadcrumbs[] = array(
            'title' => __( 'Home', 'seo-pro' ),
            'url' => home_url( '/' ),
        );
        
        if ( is_singular() ) {
            global $post;
            
            // Categories/Taxonomies
            if ( $post->post_type === 'post' ) {
                $categories = get_the_category( $post->ID );
                if ( ! empty( $categories ) ) {
                    $category = $categories[0];
                    $breadcrumbs[] = array(
                        'title' => $category->name,
                        'url' => get_category_link( $category ),
                    );
                }
            } elseif ( $post->post_type === 'rtcl_listing' && function_exists( 'rtcl' ) ) {
                $categories = wp_get_post_terms( $post->ID, 'rtcl_category' );
                if ( ! empty( $categories ) ) {
                    $category = $categories[0];
                    $breadcrumbs[] = array(
                        'title' => $category->name,
                        'url' => get_term_link( $category ),
                    );
                }
            }
            
            // Current post
            $breadcrumbs[] = array(
                'title' => get_the_title(),
                'url' => '',
            );
        } elseif ( is_tax() || is_category() || is_tag() ) {
            $term = get_queried_object();
            
            // Parent terms
            if ( $term->parent ) {
                $parent = get_term( $term->parent, $term->taxonomy );
                $breadcrumbs[] = array(
                    'title' => $parent->name,
                    'url' => get_term_link( $parent ),
                );
            }
            
            $breadcrumbs[] = array(
                'title' => $term->name,
                'url' => '',
            );
        } elseif ( is_search() ) {
            $breadcrumbs[] = array(
                'title' => sprintf( __( 'Search Results for "%s"', 'seo-pro' ), get_search_query() ),
                'url' => '',
            );
        } elseif ( is_404() ) {
            $breadcrumbs[] = array(
                'title' => __( '404 Not Found', 'seo-pro' ),
                'url' => '',
            );
        }
        
        return $breadcrumbs;
    }
}

// Template function
function seo_pro_breadcrumbs( $separator = '›', $home_text = 'Home' ) {
    SEO_Pro_Breadcrumbs::instance()->display_breadcrumbs( $separator, $home_text );
}
