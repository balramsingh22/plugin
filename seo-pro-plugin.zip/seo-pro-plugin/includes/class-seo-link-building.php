<?php
/**
 * SEO Link Building - Backlink tracker and link building tools
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Link_Building {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add link building menu
        add_action( 'admin_menu', array( $this, 'add_link_building_menu' ), 40 );
        
        // Track internal links
        add_action( 'save_post', array( $this, 'track_internal_links' ), 10, 2 );
        
        // Add link suggestions metabox
        add_action( 'add_meta_boxes', array( $this, 'add_link_suggestions_metabox' ) );
    }
    
    /**
     * Add link building menu
     */
    public function add_link_building_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'Link Building', 'seo-pro' ),
            __( 'Link Building', 'seo-pro' ),
            'manage_options',
            'seo-pro-link-building',
            array( $this, 'render_link_building_page' )
        );
    }
    
    /**
     * Add link suggestions metabox
     */
    public function add_link_suggestions_metabox() {
        $post_types = array( 'post', 'page', 'rtcl_listing' );
        
        foreach ( $post_types as $post_type ) {
            add_meta_box(
                'seo_pro_link_suggestions',
                __( '🔗 Link Suggestions', 'seo-pro' ),
                array( $this, 'render_link_suggestions_metabox' ),
                $post_type,
                'side',
                'default'
            );
        }
    }
    
    /**
     * Render link suggestions metabox
     */
    public function render_link_suggestions_metabox( $post ) {
        $content = $post->post_content;
        $suggestions = $this->get_link_suggestions( $content, $post->ID );
        
        if ( empty( $suggestions ) ) {
            echo '<p>' . __( 'No link suggestions available. Add more content to get suggestions.', 'seo-pro' ) . '</p>';
            return;
        }
        
        echo '<div class="link-suggestions">';
        echo '<p><strong>' . __( 'Suggested Internal Links:', 'seo-pro' ) . '</strong></p>';
        echo '<ul style="margin: 0; padding-left: 20px;">';
        
        foreach ( $suggestions as $suggestion ) {
            echo '<li style="margin-bottom: 8px;">';
            echo '<a href="' . esc_url( get_permalink( $suggestion['post_id'] ) ) . '" target="_blank">';
            echo esc_html( $suggestion['title'] );
            echo '</a>';
            echo '<br><small style="color: #666;">' . sprintf( __( 'Keyword: %s', 'seo-pro' ), esc_html( $suggestion['keyword'] ) ) . '</small>';
            echo '</li>';
        }
        
        echo '</ul>';
        echo '</div>';
    }
    
    /**
     * Get link suggestions
     */
    private function get_link_suggestions( $content, $current_post_id ) {
        global $wpdb;
        
        $suggestions = array();
        $content_text = wp_strip_all_tags( $content );
        
        // Get related posts based on keywords
        $posts = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title FROM {$wpdb->posts} 
            WHERE post_status = 'publish' 
            AND post_type IN ('post', 'page', 'rtcl_listing')
            AND ID != %d
            ORDER BY post_date DESC
            LIMIT 20",
            $current_post_id
        ) );
        
        foreach ( $posts as $post ) {
            // Check if post title appears in content
            if ( stripos( $content_text, $post->post_title ) !== false ) {
                $suggestions[] = array(
                    'post_id' => $post->ID,
                    'title' => $post->post_title,
                    'keyword' => $post->post_title,
                );
                
                if ( count( $suggestions ) >= 5 ) {
                    break;
                }
            }
        }
        
        return $suggestions;
    }
    
    /**
     * Track internal links
     */
    public function track_internal_links( $post_id, $post ) {
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
            return;
        }
        
        $content = $post->post_content;
        $internal_links = $this->extract_internal_links( $content );
        
        update_post_meta( $post_id, '_seo_pro_internal_links', $internal_links );
        update_post_meta( $post_id, '_seo_pro_internal_link_count', count( $internal_links ) );
    }
    
    /**
     * Extract internal links from content
     */
    private function extract_internal_links( $content ) {
        $links = array();
        $home_url = home_url();
        
        preg_match_all( '/<a\s+(?:[^>]*?\s+)?href="([^"]*)"/', $content, $matches );
        
        if ( ! empty( $matches[1] ) ) {
            foreach ( $matches[1] as $url ) {
                if ( strpos( $url, $home_url ) !== false ) {
                    $links[] = $url;
                }
            }
        }
        
        return array_unique( $links );
    }
    
    /**
     * Render link building page
     */
    public function render_link_building_page() {
        global $wpdb;
        
        // Get link statistics
        $total_posts = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ('post', 'page', 'rtcl_listing')" );
        
        $posts_with_links = $wpdb->get_var( "
            SELECT COUNT(DISTINCT post_id) 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_seo_pro_internal_link_count' 
            AND CAST(meta_value AS UNSIGNED) > 0
        " );
        
        $avg_links = $wpdb->get_var( "
            SELECT AVG(CAST(meta_value AS UNSIGNED)) 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_seo_pro_internal_link_count'
        " );
        
        $avg_links = round( $avg_links, 1 );
        
        // Get posts with most internal links
        $top_linked_posts = $wpdb->get_results( "
            SELECT p.ID, p.post_title, pm.meta_value as link_count
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE pm.meta_key = '_seo_pro_internal_link_count'
            AND p.post_status = 'publish'
            ORDER BY CAST(pm.meta_value AS UNSIGNED) DESC
            LIMIT 10
        " );
        
        // Get posts with no internal links
        $posts_without_links = $wpdb->get_results( "
            SELECT p.ID, p.post_title
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_seo_pro_internal_link_count'
            WHERE p.post_status = 'publish'
            AND p.post_type IN ('post', 'page', 'rtcl_listing')
            AND (pm.meta_value IS NULL OR CAST(pm.meta_value AS UNSIGNED) = 0)
            LIMIT 10
        " );
        
        ?>
        <div class="wrap seo-pro-wrap">
            <h1><?php _e( '🔗 Link Building & Analysis', 'seo-pro' ); ?></h1>
            
            <!-- Link Statistics -->
            <div class="link-stats-overview">
                <div class="stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-content">
                        <div class="stat-value"><?php echo esc_html( $total_posts ); ?></div>
                        <div class="stat-label"><?php _e( 'Total Posts', 'seo-pro' ); ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">🔗</div>
                    <div class="stat-content">
                        <div class="stat-value"><?php echo esc_html( $posts_with_links ); ?></div>
                        <div class="stat-label"><?php _e( 'Posts with Links', 'seo-pro' ); ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">📈</div>
                    <div class="stat-content">
                        <div class="stat-value"><?php echo esc_html( $avg_links ); ?></div>
                        <div class="stat-label"><?php _e( 'Avg Links/Post', 'seo-pro' ); ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">⚠️</div>
                    <div class="stat-content">
                        <div class="stat-value"><?php echo esc_html( count( $posts_without_links ) ); ?></div>
                        <div class="stat-label"><?php _e( 'Posts Need Links', 'seo-pro' ); ?></div>
                    </div>
                </div>
            </div>
            
            <div class="seo-grid">
                <!-- Top Linked Posts -->
                <div class="seo-card">
                    <h2><?php _e( '🏆 Top Linked Posts', 'seo-pro' ); ?></h2>
                    
                    <?php if ( ! empty( $top_linked_posts ) ) : ?>
                        <table class="widefat">
                            <thead>
                                <tr>
                                    <th><?php _e( 'Post Title', 'seo-pro' ); ?></th>
                                    <th><?php _e( 'Internal Links', 'seo-pro' ); ?></th>
                                    <th><?php _e( 'Action', 'seo-pro' ); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ( $top_linked_posts as $post ) : ?>
                                    <tr>
                                        <td><?php echo esc_html( $post->post_title ); ?></td>
                                        <td><strong><?php echo esc_html( $post->link_count ); ?></strong></td>
                                        <td>
                                            <a href="<?php echo get_edit_post_link( $post->ID ); ?>" class="button button-small">
                                                <?php _e( 'Edit', 'seo-pro' ); ?>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else : ?>
                        <p><?php _e( 'No data available yet.', 'seo-pro' ); ?></p>
                    <?php endif; ?>
                </div>
                
                <!-- Posts Without Links -->
                <div class="seo-card">
                    <h2><?php _e( '⚠️ Posts Without Internal Links', 'seo-pro' ); ?></h2>
                    <p><?php _e( 'These posts need internal links for better SEO.', 'seo-pro' ); ?></p>
                    
                    <?php if ( ! empty( $posts_without_links ) ) : ?>
                        <ul class="link-list">
                            <?php foreach ( $posts_without_links as $post ) : ?>
                                <li>
                                    <?php echo esc_html( $post->post_title ); ?>
                                    <a href="<?php echo get_edit_post_link( $post->ID ); ?>" class="button button-small" style="margin-left: 10px;">
                                        <?php _e( 'Add Links', 'seo-pro' ); ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else : ?>
                        <p><?php _e( 'Great! All posts have internal links.', 'seo-pro' ); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Link Building Tips -->
            <div class="seo-card">
                <h2><?php _e( '💡 Link Building Best Practices', 'seo-pro' ); ?></h2>
                
                <div class="tips-grid">
                    <div class="tip-item">
                        <h3><?php _e( '1. Internal Linking', 'seo-pro' ); ?></h3>
                        <p><?php _e( 'Add 3-5 internal links per post to related content. This helps search engines understand your site structure.', 'seo-pro' ); ?></p>
                    </div>
                    
                    <div class="tip-item">
                        <h3><?php _e( '2. Anchor Text', 'seo-pro' ); ?></h3>
                        <p><?php _e( 'Use descriptive anchor text that includes your target keywords naturally.', 'seo-pro' ); ?></p>
                    </div>
                    
                    <div class="tip-item">
                        <h3><?php _e( '3. Link Relevance', 'seo-pro' ); ?></h3>
                        <p><?php _e( 'Link to related content only. Irrelevant links can hurt your SEO.', 'seo-pro' ); ?></p>
                    </div>
                    
                    <div class="tip-item">
                        <h3><?php _e( '4. Deep Linking', 'seo-pro' ); ?></h3>
                        <p><?php _e( 'Link to deep pages, not just your homepage. Spread link equity across your site.', 'seo-pro' ); ?></p>
                    </div>
                    
                    <div class="tip-item">
                        <h3><?php _e( '5. Update Old Posts', 'seo-pro' ); ?></h3>
                        <p><?php _e( 'Regularly update old posts with links to new content to keep them fresh.', 'seo-pro' ); ?></p>
                    </div>
                    
                    <div class="tip-item">
                        <h3><?php _e( '6. External Links', 'seo-pro' ); ?></h3>
                        <p><?php _e( 'Link to 1-2 high-authority external sources to add credibility.', 'seo-pro' ); ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
            .link-stats-overview {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .stat-card {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                padding: 20px;
                border-radius: 8px;
                display: flex;
                align-items: center;
                gap: 15px;
            }
            .stat-card:nth-child(2) {
                background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            }
            .stat-card:nth-child(3) {
                background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            }
            .stat-card:nth-child(4) {
                background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            }
            .stat-icon {
                font-size: 40px;
            }
            .stat-value {
                font-size: 32px;
                font-weight: 700;
            }
            .stat-label {
                font-size: 13px;
                opacity: 0.9;
            }
            .seo-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .link-list {
                list-style: none;
                padding: 0;
            }
            .link-list li {
                padding: 10px;
                border-bottom: 1px solid #f0f0f1;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .tips-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }
            .tip-item {
                background: #f9f9f9;
                padding: 15px;
                border-radius: 6px;
                border-left: 4px solid #2271b1;
            }
            .tip-item h3 {
                margin-top: 0;
                color: #2271b1;
                font-size: 15px;
            }
            .tip-item p {
                margin: 0;
                font-size: 13px;
                line-height: 1.6;
            }
        </style>
        <?php
    }
}
