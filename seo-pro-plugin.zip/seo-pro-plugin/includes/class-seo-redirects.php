<?php
/**
 * SEO Redirects - Redirection management
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Redirects {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        add_action( 'template_redirect', array( $this, 'handle_redirects' ), 1 );
    }
    
    /**
     * Handle redirects
     */
    public function handle_redirects() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'seo_pro_redirects';
        
        // Check if table exists
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) != $table_name ) {
            return;
        }
        
        $current_url = $_SERVER['REQUEST_URI'];
        $current_url = strtok( $current_url, '?' ); // Remove query string
        
        // Get redirect from database
        $redirect = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table_name WHERE from_url = %s",
            $current_url
        ) );
        
        if ( $redirect ) {
            // Update hit counter
            $wpdb->update(
                $table_name,
                array( 'hits' => $redirect->hits + 1 ),
                array( 'id' => $redirect->id ),
                array( '%d' ),
                array( '%d' )
            );
            
            // Perform redirect
            wp_redirect( $redirect->to_url, intval( $redirect->type ) );
            exit;
        }
    }
    
    /**
     * Add redirect
     */
    public static function add_redirect( $from_url, $to_url, $type = 301 ) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'seo_pro_redirects';
        
        $wpdb->replace(
            $table_name,
            array(
                'from_url' => $from_url,
                'to_url' => $to_url,
                'type' => intval( $type ),
            ),
            array( '%s', '%s', '%d' )
        );
        
        return $wpdb->insert_id;
    }
    
    /**
     * Delete redirect
     */
    public static function delete_redirect( $id ) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'seo_pro_redirects';
        
        return $wpdb->delete(
            $table_name,
            array( 'id' => intval( $id ) ),
            array( '%d' )
        );
    }
    
    /**
     * Get all redirects
     */
    public static function get_redirects() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'seo_pro_redirects';
        
        return $wpdb->get_results( "SELECT * FROM $table_name ORDER BY id DESC" );
    }
    
    /**
     * Get redirect count
     */
    public static function get_redirect_count() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'seo_pro_redirects';
        
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" );
    }
}
