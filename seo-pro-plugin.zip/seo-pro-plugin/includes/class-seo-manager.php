<?php
/**
 * SEO Manager - Core SEO functionality
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Manager {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Meta Tags
        add_action( 'wp_head', array( $this, 'output_meta_tags' ), 1 );
        
        // Canonical URL
        add_action( 'wp_head', array( $this, 'output_canonical' ), 1 );
        
        // Remove default WordPress meta tags
        remove_action( 'wp_head', 'rel_canonical' );
        remove_action( 'wp_head', 'wp_shortlink_wp_head' );
        remove_action( 'wp_head', 'wp_generator' );
        
        // Optimize title
        add_filter( 'pre_get_document_title', array( $this, 'get_seo_title' ), 999 );
        add_filter( 'wp_title', array( $this, 'get_seo_title' ), 999 );
    }
    
    /**
     * Output Meta Tags
     */
    public function output_meta_tags() {
        if ( is_admin() ) {
            return;
        }
        
        $description = $this->get_seo_description();
        $keywords = $this->get_seo_keywords();
        $robots = $this->get_robots_meta();
        
        echo "\n<!-- SEO Pro Meta Tags -->\n";
        
        if ( $description ) {
            echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
        }
        
        if ( $keywords ) {
            echo '<meta name="keywords" content="' . esc_attr( $keywords ) . '">' . "\n";
        }
        
        if ( $robots ) {
            echo '<meta name="robots" content="' . esc_attr( $robots ) . '">' . "\n";
        }
        
        // Author
        if ( is_singular() ) {
            $author = get_the_author();
            if ( $author ) {
                echo '<meta name="author" content="' . esc_attr( $author ) . '">' . "\n";
            }
        }
        
        // Geo Tags for Local SEO
        $this->output_geo_tags();
        
        // Google Site Verification
        $google_verification = get_option( 'seo_pro_google_verification', '' );
        if ( ! empty( $google_verification ) ) {
            echo '<meta name="google-site-verification" content="' . esc_attr( $google_verification ) . '">' . "\n";
        }
        
        echo "<!-- /SEO Pro Meta Tags -->\n\n";
    }
    
    /**
     * Output Geo Tags
     */
    private function output_geo_tags() {
        $geo_region = get_option( 'seo_geo_region' );
        $geo_placename = get_option( 'seo_geo_placename' );
        $geo_position = get_option( 'seo_geo_position' );
        
        if ( $geo_region ) {
            echo '<meta name="geo.region" content="' . esc_attr( $geo_region ) . '">' . "\n";
        }
        if ( $geo_placename ) {
            echo '<meta name="geo.placename" content="' . esc_attr( $geo_placename ) . '">' . "\n";
        }
        if ( $geo_position ) {
            echo '<meta name="geo.position" content="' . esc_attr( $geo_position ) . '">' . "\n";
            
            // Also add ICBM tag
            echo '<meta name="ICBM" content="' . esc_attr( $geo_position ) . '">' . "\n";
        }
    }
    
    /**
     * Output Canonical URL
     */
    public function output_canonical() {
        $canonical = $this->get_canonical_url();
        
        if ( $canonical ) {
            echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";
        }
    }
    
    /**
     * Get SEO Title
     */
    public function get_seo_title( $title = '' ) {
        global $post;
        
        // Let Titles & Meta class handle it if template exists
        // This gives priority to user-configured templates
        if ( $this->has_titles_meta_template() ) {
            return $title; // Don't override
        }
        
        // Custom SEO title from meta (from post editor)
        if ( is_singular() && $post && $custom_title = get_post_meta( $post->ID, '_seo_pro_title', true ) ) {
            return $custom_title;
        }
        
        $separator = get_option( 'seo_pro_title_separator', '|' );
        $site_name = get_bloginfo( 'name' );
        
        // Generate title based on page type
        if ( is_front_page() ) {
            $tagline = get_bloginfo( 'description' );
            return $tagline ? "$site_name $separator $tagline" : $site_name;
        } elseif ( is_singular() ) {
            $post_title = get_the_title();
            return "$post_title $separator $site_name";
        } elseif ( is_category() ) {
            $cat_title = single_cat_title( '', false );
            return "$cat_title $separator $site_name";
        } elseif ( is_tag() ) {
            $tag_title = single_tag_title( '', false );
            return "$tag_title $separator $site_name";
        } elseif ( is_tax() ) {
            $term_title = single_term_title( '', false );
            return "$term_title $separator $site_name";
        } elseif ( is_archive() ) {
            $archive_title = get_the_archive_title();
            $archive_title = str_replace( array( 'Category: ', 'Tag: ', 'Archives: ' ), '', $archive_title );
            return "$archive_title $separator $site_name";
        } elseif ( is_search() ) {
            $search_query = get_search_query();
            return sprintf( __( 'Search Results for "%s"', 'seo-pro' ), $search_query ) . " $separator $site_name";
        } elseif ( is_404() ) {
            return __( 'Page Not Found', 'seo-pro' ) . " $separator $site_name";
        }
        
        return $title ? $title : $site_name;
    }
    
    /**
     * Check if Titles & Meta template exists
     */
    private function has_titles_meta_template() {
        // Check if homepage template exists
        if ( is_front_page() || is_home() ) {
            return get_option( 'seo_pro_title_home' ) !== false;
        }
        
        // Check if post type template exists
        if ( is_singular() ) {
            $post_type = get_post_type();
            return get_option( "seo_pro_title_{$post_type}" ) !== false;
        }
        
        // Check if taxonomy template exists
        if ( is_tax() || is_category() || is_tag() ) {
            $term = get_queried_object();
            if ( $term && isset( $term->taxonomy ) ) {
                return get_option( "seo_pro_title_tax_{$term->taxonomy}" ) !== false;
            }
        }
        
        // Check if archive template exists
        if ( is_author() ) {
            return get_option( 'seo_pro_title_archive_author' ) !== false;
        }
        if ( is_date() ) {
            return get_option( 'seo_pro_title_archive_date' ) !== false;
        }
        if ( is_search() ) {
            return get_option( 'seo_pro_title_archive_search' ) !== false;
        }
        if ( is_404() ) {
            return get_option( 'seo_pro_title_archive_404' ) !== false;
        }
        
        return false;
    }
    
    /**
     * Get SEO Description
     */
    public function get_seo_description() {
        global $post;
        
        // Let Titles & Meta class handle it if template exists
        if ( $this->has_description_template() ) {
            return ''; // Don't output, let Titles & Meta handle it
        }
        
        // Custom SEO description from meta (from post editor)
        if ( is_singular() && $post && $custom_desc = get_post_meta( $post->ID, '_seo_pro_description', true ) ) {
            return $custom_desc;
        }
        
        // Generate description based on page type
        if ( is_front_page() ) {
            return get_bloginfo( 'description' );
        } elseif ( is_singular() ) {
            if ( has_excerpt() ) {
                return wp_trim_words( get_the_excerpt(), 30 );
            } else {
                $content = get_the_content();
                $content = wp_strip_all_tags( strip_shortcodes( $content ) );
                return wp_trim_words( $content, 30 );
            }
        } elseif ( is_category() || is_tag() || is_tax() ) {
            $term_desc = term_description();
            if ( $term_desc ) {
                return wp_trim_words( wp_strip_all_tags( $term_desc ), 30 );
            }
            $term_name = single_term_title( '', false );
            return sprintf( __( 'Browse %s archive.', 'seo-pro' ), $term_name );
        } elseif ( is_archive() ) {
            return get_the_archive_description();
        } elseif ( is_search() ) {
            return sprintf( __( 'Search results for: %s', 'seo-pro' ), get_search_query() );
        }
        
        return get_bloginfo( 'description' );
    }
    
    /**
     * Check if description template exists
     */
    private function has_description_template() {
        // Check if homepage template exists
        if ( is_front_page() || is_home() ) {
            return get_option( 'seo_pro_description_home' ) !== false;
        }
        
        // Check if post type template exists
        if ( is_singular() ) {
            $post_type = get_post_type();
            return get_option( "seo_pro_description_{$post_type}" ) !== false;
        }
        
        // Check if taxonomy template exists
        if ( is_tax() || is_category() || is_tag() ) {
            $term = get_queried_object();
            if ( $term && isset( $term->taxonomy ) ) {
                return get_option( "seo_pro_description_tax_{$term->taxonomy}" ) !== false;
            }
        }
        
        return false;
    }
    
    /**
     * Get SEO Keywords
     */
    public function get_seo_keywords() {
        global $post;
        
        if ( is_singular() && $post && $custom_keywords = get_post_meta( $post->ID, '_seo_pro_keywords', true ) ) {
            return $custom_keywords;
        }
        
        // Auto-generate from tags/categories
        if ( is_singular() && $post ) {
            $keywords = array();
            
            $tags = get_the_tags( $post->ID );
            if ( $tags ) {
                foreach ( $tags as $tag ) {
                    $keywords[] = $tag->name;
                }
            }
            
            $categories = get_the_category( $post->ID );
            if ( $categories ) {
                foreach ( $categories as $cat ) {
                    $keywords[] = $cat->name;
                }
            }
            
            // For RTCL listings
            if ( function_exists( 'rtcl' ) ) {
                $rtcl_cats = wp_get_post_terms( $post->ID, 'rtcl_category', array( 'fields' => 'names' ) );
                if ( ! empty( $rtcl_cats ) ) {
                    $keywords = array_merge( $keywords, $rtcl_cats );
                }
                
                $rtcl_locs = wp_get_post_terms( $post->ID, 'rtcl_location', array( 'fields' => 'names' ) );
                if ( ! empty( $rtcl_locs ) ) {
                    $keywords = array_merge( $keywords, $rtcl_locs );
                }
            }
            
            return ! empty( $keywords ) ? implode( ', ', array_unique( $keywords ) ) : '';
        }
        
        return '';
    }
    
    /**
     * Get Robots Meta
     */
    public function get_robots_meta() {
        global $post;
        
        $robots = array();
        
        // Custom robots from meta
        if ( is_singular() && $post ) {
            $noindex = get_post_meta( $post->ID, '_seo_pro_noindex', true );
            $nofollow = get_post_meta( $post->ID, '_seo_pro_nofollow', true );
            
            if ( $noindex ) {
                $robots[] = 'noindex';
            } else {
                $robots[] = 'index';
            }
            
            if ( $nofollow ) {
                $robots[] = 'nofollow';
            } else {
                $robots[] = 'follow';
            }
        } else {
            $robots[] = 'index';
            $robots[] = 'follow';
        }
        
        // Additional directives
        $robots[] = 'max-snippet:-1';
        $robots[] = 'max-image-preview:large';
        $robots[] = 'max-video-preview:-1';
        
        return implode( ', ', $robots );
    }
    
    /**
     * Get Canonical URL
     */
    public function get_canonical_url() {
        global $post;
        
        // Custom canonical
        if ( is_singular() && $post && $custom_canonical = get_post_meta( $post->ID, '_seo_pro_canonical', true ) ) {
            return $custom_canonical;
        }
        
        // Default canonical
        if ( is_singular() ) {
            return get_permalink();
        } elseif ( is_category() || is_tag() || is_tax() ) {
            $term = get_queried_object();
            return get_term_link( $term );
        } elseif ( is_post_type_archive() ) {
            return get_post_type_archive_link( get_post_type() );
        } elseif ( is_search() ) {
            return home_url( '/?s=' . urlencode( get_search_query() ) );
        } elseif ( is_front_page() ) {
            return home_url( '/' );
        }
        
        return '';
    }
    
    /**
     * Get Social Image
     */
    public function get_social_image() {
        global $post;
        
        // Custom social image
        if ( is_singular() && $post && $custom_image_id = get_post_meta( $post->ID, '_seo_pro_social_image', true ) ) {
            $image_url = wp_get_attachment_url( $custom_image_id );
            if ( $image_url ) {
                return $image_url;
            }
        }
        
        // Featured image
        if ( is_singular() && $post && has_post_thumbnail( $post->ID ) ) {
            return get_the_post_thumbnail_url( $post->ID, 'full' );
        }
        
        // Default site image
        $default_image = get_option( 'seo_default_image' );
        if ( $default_image ) {
            return $default_image;
        }
        
        // Fallback to site logo
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        if ( $custom_logo_id ) {
            return wp_get_attachment_url( $custom_logo_id );
        }
        
        return '';
    }
    
    /**
     * Get OG Type
     */
    public function get_og_type() {
        if ( is_singular( 'post' ) ) {
            return 'article';
        } elseif ( is_singular( 'rtcl_listing' ) ) {
            return 'product';
        } elseif ( is_front_page() ) {
            return 'website';
        }
        
        return 'website';
    }
}
