<?php
/**
 * SEO Settings - Core settings management
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Settings {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Social meta tags
        add_action( 'wp_head', array( $this, 'output_social_meta' ), 5 );
    }
    
    /**
     * Output Social Meta Tags (Open Graph & Twitter Cards)
     */
    public function output_social_meta() {
        if ( is_admin() ) {
            return;
        }
        
        $manager = SEO_Pro_Manager::instance();
        $title = $manager->get_seo_title();
        $description = $manager->get_seo_description();
        $image = $manager->get_social_image();
        $url = $manager->get_canonical_url();
        $og_type = $manager->get_og_type();
        
        echo "\n<!-- Open Graph Meta Tags -->\n";
        echo '<meta property="og:locale" content="' . esc_attr( get_locale() ) . '">' . "\n";
        echo '<meta property="og:type" content="' . esc_attr( $og_type ) . '">' . "\n";
        echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr( $description ) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
        
        if ( $image ) {
            echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
            echo '<meta property="og:image:width" content="1200">' . "\n";
            echo '<meta property="og:image:height" content="630">' . "\n";
        }
        
        if ( is_singular() ) {
            echo '<meta property="article:published_time" content="' . esc_attr( get_the_date( 'c' ) ) . '">' . "\n";
            echo '<meta property="article:modified_time" content="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . "\n";
        }
        
        echo "<!-- /Open Graph Meta Tags -->\n\n";
        
        echo "<!-- Twitter Card Meta Tags -->\n";
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr( $description ) . '">' . "\n";
        
        if ( $image ) {
            echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">' . "\n";
        }
        
        $twitter_username = get_option( 'seo_twitter_username' );
        if ( $twitter_username ) {
            echo '<meta name="twitter:site" content="@' . esc_attr( $twitter_username ) . '">' . "\n";
            echo '<meta name="twitter:creator" content="@' . esc_attr( $twitter_username ) . '">' . "\n";
        }
        
        echo "<!-- /Twitter Card Meta Tags -->\n\n";
    }
    
    /**
     * Get all SEO settings
     */
    public function get_settings() {
        return array(
            'separator' => get_option( 'seo_separator', '-' ),
            'default_image' => get_option( 'seo_default_image', '' ),
            'phone' => get_option( 'seo_phone', '' ),
            'business_type' => get_option( 'seo_business_type', 'LocalBusiness' ),
            'street_address' => get_option( 'seo_street_address', '' ),
            'locality' => get_option( 'seo_locality', '' ),
            'region' => get_option( 'seo_region', '' ),
            'postal_code' => get_option( 'seo_postal_code', '' ),
            'latitude' => get_option( 'seo_latitude', '' ),
            'longitude' => get_option( 'seo_longitude', '' ),
            'price_range' => get_option( 'seo_price_range', '₹₹' ),
            'facebook_url' => get_option( 'seo_facebook_url', '' ),
            'twitter_url' => get_option( 'seo_twitter_url', '' ),
            'twitter_username' => get_option( 'seo_twitter_username', '' ),
            'instagram_url' => get_option( 'seo_instagram_url', '' ),
            'linkedin_url' => get_option( 'seo_linkedin_url', '' ),
        );
    }
}
