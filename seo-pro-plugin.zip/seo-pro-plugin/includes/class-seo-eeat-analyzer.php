<?php
/**
 * SEO E-E-A-T Analyzer - Experience, Expertise, Authority, Trust
 * Google's #1 Ranking Factor for 2024-2025
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_EEAT_Analyzer {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add E-E-A-T metabox
        add_action( 'add_meta_boxes', array( $this, 'add_eeat_metabox' ) );
        
        // Save E-E-A-T data
        add_action( 'save_post', array( $this, 'save_eeat_data' ), 10, 2 );
        
        // Add E-E-A-T menu
        add_action( 'admin_menu', array( $this, 'add_eeat_menu' ), 45 );
    }
    
    /**
     * Add E-E-A-T metabox
     */
    public function add_eeat_metabox() {
        $post_types = array( 'post', 'page', 'rtcl_listing' );
        
        foreach ( $post_types as $post_type ) {
            add_meta_box(
                'seo_pro_eeat_analyzer',
                __( '🎯 E-E-A-T Score (Google 2024)', 'seo-pro' ),
                array( $this, 'render_eeat_metabox' ),
                $post_type,
                'side',
                'high'
            );
        }
    }
    
    /**
     * Render E-E-A-T metabox
     */
    public function render_eeat_metabox( $post ) {
        wp_nonce_field( 'seo_pro_eeat', 'seo_pro_eeat_nonce' );
        
        $content = $post->post_content;
        $eeat_score = $this->calculate_eeat_score( $post );
        
        ?>
        <div class="eeat-analyzer">
            <!-- Overall E-E-A-T Score -->
            <div class="eeat-score-circle <?php echo $this->get_score_class( $eeat_score['total'] ); ?>">
                <div class="score-value"><?php echo esc_html( $eeat_score['total'] ); ?></div>
                <div class="score-label">E-E-A-T Score</div>
            </div>
            
            <!-- Individual Scores -->
            <div class="eeat-breakdown">
                <div class="eeat-item">
                    <span class="eeat-label">Experience:</span>
                    <div class="eeat-bar">
                        <div class="eeat-fill" style="width: <?php echo $eeat_score['experience']; ?>%;"></div>
                    </div>
                    <span class="eeat-value"><?php echo $eeat_score['experience']; ?>%</span>
                </div>
                
                <div class="eeat-item">
                    <span class="eeat-label">Expertise:</span>
                    <div class="eeat-bar">
                        <div class="eeat-fill" style="width: <?php echo $eeat_score['expertise']; ?>%;"></div>
                    </div>
                    <span class="eeat-value"><?php echo $eeat_score['expertise']; ?>%</span>
                </div>
                
                <div class="eeat-item">
                    <span class="eeat-label">Authority:</span>
                    <div class="eeat-bar">
                        <div class="eeat-fill" style="width: <?php echo $eeat_score['authority']; ?>%;"></div>
                    </div>
                    <span class="eeat-value"><?php echo $eeat_score['authority']; ?>%</span>
                </div>
                
                <div class="eeat-item">
                    <span class="eeat-label">Trust:</span>
                    <div class="eeat-bar">
                        <div class="eeat-fill" style="width: <?php echo $eeat_score['trust']; ?>%;"></div>
                    </div>
                    <span class="eeat-value"><?php echo $eeat_score['trust']; ?>%</span>
                </div>
            </div>
            
            <!-- Recommendations -->
            <div class="eeat-recommendations">
                <h4><?php _e( 'Improve E-E-A-T:', 'seo-pro' ); ?></h4>
                <ul>
                    <?php foreach ( $eeat_score['recommendations'] as $recommendation ) : ?>
                        <li><?php echo esc_html( $recommendation ); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <!-- Author Info -->
            <div class="eeat-author-info">
                <h4><?php _e( 'Author Credentials:', 'seo-pro' ); ?></h4>
                <input type="text" name="seo_pro_author_credentials" 
                       value="<?php echo esc_attr( get_post_meta( $post->ID, '_seo_pro_author_credentials', true ) ); ?>"
                       placeholder="e.g., PhD, 10+ years experience"
                       style="width: 100%;">
                <p class="description"><?php _e( 'Add author credentials to boost expertise', 'seo-pro' ); ?></p>
            </div>
            
            <!-- Last Updated -->
            <div class="eeat-freshness">
                <label>
                    <input type="checkbox" name="seo_pro_show_last_updated" value="1" 
                           <?php checked( get_post_meta( $post->ID, '_seo_pro_show_last_updated', true ), 1 ); ?>>
                    <?php _e( 'Show "Last Updated" date', 'seo-pro' ); ?>
                </label>
                <p class="description"><?php _e( 'Freshness signal for Google', 'seo-pro' ); ?></p>
            </div>
        </div>
        
        <style>
            .eeat-analyzer {
                padding: 10px 0;
            }
            .eeat-score-circle {
                width: 100px;
                height: 100px;
                border-radius: 50%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                margin: 15px auto;
                border: 4px solid;
            }
            .eeat-score-circle.excellent { border-color: #00a32a; color: #00a32a; }
            .eeat-score-circle.good { border-color: #2271b1; color: #2271b1; }
            .eeat-score-circle.average { border-color: #f0b849; color: #f0b849; }
            .eeat-score-circle.poor { border-color: #d63638; color: #d63638; }
            .score-value {
                font-size: 28px;
                font-weight: 700;
            }
            .score-label {
                font-size: 11px;
            }
            .eeat-breakdown {
                margin: 15px 0;
            }
            .eeat-item {
                margin-bottom: 12px;
            }
            .eeat-label {
                display: block;
                font-size: 12px;
                font-weight: 600;
                margin-bottom: 4px;
            }
            .eeat-bar {
                height: 8px;
                background: #f0f0f1;
                border-radius: 4px;
                overflow: hidden;
                margin-bottom: 2px;
            }
            .eeat-fill {
                height: 100%;
                background: linear-gradient(90deg, #2271b1, #00a32a);
                transition: width 0.3s;
            }
            .eeat-value {
                font-size: 11px;
                color: #666;
            }
            .eeat-recommendations {
                background: #f9f9f9;
                padding: 10px;
                border-radius: 4px;
                margin: 15px 0;
            }
            .eeat-recommendations h4 {
                margin: 0 0 8px 0;
                font-size: 13px;
            }
            .eeat-recommendations ul {
                margin: 0;
                padding-left: 20px;
                font-size: 12px;
            }
            .eeat-recommendations li {
                margin-bottom: 5px;
            }
            .eeat-author-info,
            .eeat-freshness {
                margin: 15px 0;
            }
            .eeat-author-info h4,
            .eeat-freshness h4 {
                margin: 0 0 8px 0;
                font-size: 13px;
            }
        </style>
        <?php
    }
    
    /**
     * Calculate E-E-A-T Score
     */
    private function calculate_eeat_score( $post ) {
        $content = $post->post_content;
        $content_text = wp_strip_all_tags( $content );
        
        // Experience Score (0-100)
        $experience = 0;
        
        // Check for first-person experience indicators
        $experience_words = array( 'I', 'my', 'we', 'our', 'personally', 'experience', 'tested', 'tried', 'used' );
        foreach ( $experience_words as $word ) {
            if ( stripos( $content_text, $word ) !== false ) {
                $experience += 10;
            }
        }
        
        // Check for images (shows real experience)
        $image_count = substr_count( $content, '<img' );
        $experience += min( 30, $image_count * 10 );
        
        $experience = min( 100, $experience );
        
        // Expertise Score (0-100)
        $expertise = 0;
        
        // Check for author credentials
        $author_credentials = get_post_meta( $post->ID, '_seo_pro_author_credentials', true );
        if ( ! empty( $author_credentials ) ) {
            $expertise += 30;
        }
        
        // Check for technical terms (shows expertise)
        $word_count = str_word_count( $content_text );
        if ( $word_count >= 1000 ) {
            $expertise += 30;
        } elseif ( $word_count >= 500 ) {
            $expertise += 20;
        }
        
        // Check for external citations
        $external_links = substr_count( $content, 'href="http' ) - substr_count( $content, home_url() );
        $expertise += min( 40, $external_links * 10 );
        
        $expertise = min( 100, $expertise );
        
        // Authority Score (0-100)
        $authority = 0;
        
        // Check for author bio
        $author_id = $post->post_author;
        $author_bio = get_the_author_meta( 'description', $author_id );
        if ( ! empty( $author_bio ) ) {
            $authority += 25;
        }
        
        // Check for backlinks (placeholder - would need external API)
        $authority += 25; // Base authority
        
        // Check for social shares (placeholder)
        $authority += 25;
        
        // Check for comments (engagement)
        $comment_count = wp_count_comments( $post->ID );
        if ( $comment_count->approved > 0 ) {
            $authority += min( 25, $comment_count->approved * 5 );
        }
        
        $authority = min( 100, $authority );
        
        // Trust Score (0-100)
        $trust = 0;
        
        // Check for HTTPS
        if ( is_ssl() ) {
            $trust += 20;
        }
        
        // Check for privacy policy link
        if ( stripos( $content, 'privacy' ) !== false ) {
            $trust += 15;
        }
        
        // Check for contact information
        if ( stripos( $content, 'contact' ) !== false || stripos( $content, 'email' ) !== false ) {
            $trust += 15;
        }
        
        // Check for last updated date
        $show_updated = get_post_meta( $post->ID, '_seo_pro_show_last_updated', true );
        if ( $show_updated ) {
            $trust += 20;
        }
        
        // Check for author attribution
        $trust += 15;
        
        // Check for sources/citations
        if ( $external_links > 0 ) {
            $trust += 15;
        }
        
        $trust = min( 100, $trust );
        
        // Calculate total score
        $total = round( ( $experience + $expertise + $authority + $trust ) / 4 );
        
        // Generate recommendations
        $recommendations = array();
        
        if ( $experience < 70 ) {
            $recommendations[] = __( 'Add personal experience and real examples', 'seo-pro' );
        }
        if ( $expertise < 70 ) {
            $recommendations[] = __( 'Add author credentials and cite sources', 'seo-pro' );
        }
        if ( $authority < 70 ) {
            $recommendations[] = __( 'Build author bio and encourage engagement', 'seo-pro' );
        }
        if ( $trust < 70 ) {
            $recommendations[] = __( 'Add contact info and show last updated date', 'seo-pro' );
        }
        
        if ( empty( $recommendations ) ) {
            $recommendations[] = __( 'Excellent! Your E-E-A-T score is strong.', 'seo-pro' );
        }
        
        return array(
            'total' => $total,
            'experience' => $experience,
            'expertise' => $expertise,
            'authority' => $authority,
            'trust' => $trust,
            'recommendations' => $recommendations,
        );
    }
    
    /**
     * Save E-E-A-T data
     */
    public function save_eeat_data( $post_id, $post ) {
        if ( ! isset( $_POST['seo_pro_eeat_nonce'] ) || ! wp_verify_nonce( $_POST['seo_pro_eeat_nonce'], 'seo_pro_eeat' ) ) {
            return;
        }
        
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
        
        // Save author credentials
        if ( isset( $_POST['seo_pro_author_credentials'] ) ) {
            update_post_meta( $post_id, '_seo_pro_author_credentials', sanitize_text_field( $_POST['seo_pro_author_credentials'] ) );
        }
        
        // Save last updated preference
        if ( isset( $_POST['seo_pro_show_last_updated'] ) ) {
            update_post_meta( $post_id, '_seo_pro_show_last_updated', 1 );
        } else {
            delete_post_meta( $post_id, '_seo_pro_show_last_updated' );
        }
        
        // Calculate and save E-E-A-T score
        $eeat_score = $this->calculate_eeat_score( $post );
        update_post_meta( $post_id, '_seo_pro_eeat_score', $eeat_score['total'] );
    }
    
    /**
     * Add E-E-A-T menu
     */
    public function add_eeat_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'E-E-A-T Analysis', 'seo-pro' ),
            __( 'E-E-A-T Score', 'seo-pro' ),
            'manage_options',
            'seo-pro-eeat',
            array( $this, 'render_eeat_page' )
        );
    }
    
    /**
     * Render E-E-A-T page
     */
    public function render_eeat_page() {
        global $wpdb;
        
        // Get average E-E-A-T score
        $avg_score = $wpdb->get_var( "
            SELECT AVG(CAST(meta_value AS UNSIGNED))
            FROM {$wpdb->postmeta}
            WHERE meta_key = '_seo_pro_eeat_score'
        " );
        $avg_score = round( $avg_score );
        
        // Get top E-E-A-T posts
        $top_posts = $wpdb->get_results( "
            SELECT p.ID, p.post_title, pm.meta_value as eeat_score
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE pm.meta_key = '_seo_pro_eeat_score'
            AND p.post_status = 'publish'
            ORDER BY CAST(pm.meta_value AS UNSIGNED) DESC
            LIMIT 10
        " );
        
        ?>
        <div class="wrap seo-pro-wrap">
            <h1><?php _e( '🎯 E-E-A-T Analysis Dashboard', 'seo-pro' ); ?></h1>
            <p><?php _e( 'Experience, Expertise, Authority, Trust - Google\'s #1 Ranking Factor', 'seo-pro' ); ?></p>
            
            <!-- Average Score -->
            <div class="eeat-dashboard-score">
                <div class="score-card">
                    <h2><?php _e( 'Average E-E-A-T Score', 'seo-pro' ); ?></h2>
                    <div class="big-score <?php echo $this->get_score_class( $avg_score ); ?>">
                        <?php echo esc_html( $avg_score ); ?>/100
                    </div>
                </div>
            </div>
            
            <!-- Top Posts -->
            <div class="seo-card">
                <h2><?php _e( 'Top E-E-A-T Posts', 'seo-pro' ); ?></h2>
                
                <?php if ( ! empty( $top_posts ) ) : ?>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th><?php _e( 'Post Title', 'seo-pro' ); ?></th>
                                <th><?php _e( 'E-E-A-T Score', 'seo-pro' ); ?></th>
                                <th><?php _e( 'Action', 'seo-pro' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $top_posts as $post ) : ?>
                                <tr>
                                    <td><?php echo esc_html( $post->post_title ); ?></td>
                                    <td>
                                        <strong class="<?php echo $this->get_score_class( $post->eeat_score ); ?>">
                                            <?php echo esc_html( $post->eeat_score ); ?>/100
                                        </strong>
                                    </td>
                                    <td>
                                        <a href="<?php echo get_edit_post_link( $post->ID ); ?>" class="button button-small">
                                            <?php _e( 'Edit', 'seo-pro' ); ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <p><?php _e( 'No E-E-A-T data available yet.', 'seo-pro' ); ?></p>
                <?php endif; ?>
            </div>
            
            <!-- E-E-A-T Guide -->
            <div class="seo-card">
                <h2><?php _e( '📚 E-E-A-T Optimization Guide', 'seo-pro' ); ?></h2>
                
                <div class="eeat-guide">
                    <div class="guide-section">
                        <h3><?php _e( '1. Experience', 'seo-pro' ); ?></h3>
                        <ul>
                            <li><?php _e( 'Share personal experiences and real examples', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Add photos and videos of actual usage', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Use first-person perspective (I, we, my)', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Include case studies and results', 'seo-pro' ); ?></li>
                        </ul>
                    </div>
                    
                    <div class="guide-section">
                        <h3><?php _e( '2. Expertise', 'seo-pro' ); ?></h3>
                        <ul>
                            <li><?php _e( 'Add author credentials and qualifications', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Cite authoritative sources', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Write in-depth, comprehensive content', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Use industry-specific terminology correctly', 'seo-pro' ); ?></li>
                        </ul>
                    </div>
                    
                    <div class="guide-section">
                        <h3><?php _e( '3. Authority', 'seo-pro' ); ?></h3>
                        <ul>
                            <li><?php _e( 'Build comprehensive author bios', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Get backlinks from authoritative sites', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Encourage social sharing and engagement', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Publish consistently in your niche', 'seo-pro' ); ?></li>
                        </ul>
                    </div>
                    
                    <div class="guide-section">
                        <h3><?php _e( '4. Trust', 'seo-pro' ); ?></h3>
                        <ul>
                            <li><?php _e( 'Use HTTPS (SSL certificate)', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Add contact information and privacy policy', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Show "Last Updated" dates', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Display author attribution clearly', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Link to credible sources', 'seo-pro' ); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
            .eeat-dashboard-score {
                margin: 20px 0;
            }
            .score-card {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                padding: 30px;
                border-radius: 12px;
                text-align: center;
            }
            .score-card h2 {
                margin: 0 0 15px 0;
                color: #fff;
            }
            .big-score {
                font-size: 64px;
                font-weight: 700;
            }
            .eeat-guide {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }
            .guide-section {
                background: #f9f9f9;
                padding: 15px;
                border-radius: 6px;
                border-left: 4px solid #2271b1;
            }
            .guide-section h3 {
                margin-top: 0;
                color: #2271b1;
            }
            .guide-section ul {
                margin: 10px 0;
                padding-left: 20px;
            }
            .guide-section li {
                margin-bottom: 8px;
                line-height: 1.5;
            }
        </style>
        <?php
    }
    
    /**
     * Get score class
     */
    private function get_score_class( $score ) {
        if ( $score >= 80 ) {
            return 'excellent';
        } elseif ( $score >= 60 ) {
            return 'good';
        } elseif ( $score >= 40 ) {
            return 'average';
        }
        return 'poor';
    }
}

// Add "Last Updated" to content
add_filter( 'the_content', function( $content ) {
    if ( ! is_singular() ) {
        return $content;
    }
    
    global $post;
    $show_updated = get_post_meta( $post->ID, '_seo_pro_show_last_updated', true );
    
    if ( $show_updated ) {
        $updated_date = get_the_modified_date();
        $updated_html = '<div class="seo-pro-last-updated" style="background: #f0f6fc; padding: 15px; border-left: 4px solid #2271b1; margin-bottom: 20px; border-radius: 4px;">';
        $updated_html .= '<strong>📅 Last Updated:</strong> ' . esc_html( $updated_date );
        $updated_html .= '</div>';
        
        $content = $updated_html . $content;
    }
    
    return $content;
}, 1 );
