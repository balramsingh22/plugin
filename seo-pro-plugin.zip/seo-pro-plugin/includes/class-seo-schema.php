<?php
/**
 * SEO Schema - Schema.org markup
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Schema {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        add_action( 'wp_head', array( $this, 'output_schema' ), 10 );
    }
    
    /**
     * Output Schema Markup
     */
    public function output_schema() {
        if ( is_admin() ) {
            return;
        }
        
        $schema = array();
        
        // Organization Schema
        $schema[] = $this->get_organization_schema();
        
        // Website Schema
        $schema[] = $this->get_website_schema();
        
        // Breadcrumb Schema
        if ( ! is_front_page() ) {
            $breadcrumb = $this->get_breadcrumb_schema();
            if ( $breadcrumb ) {
                $schema[] = $breadcrumb;
            }
        }
        
        // Content-specific Schema
        if ( is_singular( 'post' ) ) {
            $schema[] = $this->get_article_schema();
        } elseif ( is_singular( 'page' ) ) {
            $schema[] = $this->get_webpage_schema();
        } elseif ( is_singular( 'rtcl_listing' ) ) {
            $schema[] = $this->get_product_schema();
        }
        
        // Local Business Schema
        if ( is_front_page() || is_singular() ) {
            $local_business = $this->get_local_business_schema();
            if ( $local_business ) {
                $schema[] = $local_business;
            }
        }
        
        // Filter empty schemas
        $schema = array_filter( $schema );
        
        if ( ! empty( $schema ) ) {
            echo "\n<!-- Schema.org Markup (SEO Pro) -->\n";
            echo '<script type="application/ld+json">' . "\n";
            echo wp_json_encode( 
                array( '@context' => 'https://schema.org', '@graph' => $schema ), 
                JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT 
            );
            echo "\n" . '</script>' . "\n";
            echo "<!-- /Schema.org Markup -->\n\n";
        }
    }
    
    /**
     * Get Organization Schema
     */
    private function get_organization_schema() {
        $social_urls = array_filter( array(
            get_option( 'seo_facebook_url' ),
            get_option( 'seo_twitter_url' ),
            get_option( 'seo_instagram_url' ),
            get_option( 'seo_linkedin_url' ),
        ) );
        
        $schema = array(
            '@type' => 'Organization',
            '@id' => home_url( '/#organization' ),
            'name' => get_bloginfo( 'name' ),
            'url' => home_url( '/' ),
        );
        
        // Logo
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        if ( $custom_logo_id ) {
            $schema['logo'] = array(
                '@type' => 'ImageObject',
                'url' => wp_get_attachment_url( $custom_logo_id ),
            );
        }
        
        // Contact Point
        $phone = get_option( 'seo_phone' );
        if ( $phone ) {
            $schema['contactPoint'] = array(
                '@type' => 'ContactPoint',
                'telephone' => $phone,
                'contactType' => 'Customer Service',
                'areaServed' => 'IN',
                'availableLanguage' => array( 'Hindi', 'English' ),
            );
        }
        
        // Social Media
        if ( ! empty( $social_urls ) ) {
            $schema['sameAs'] = $social_urls;
        }
        
        return $schema;
    }
    
    /**
     * Get Website Schema
     */
    private function get_website_schema() {
        return array(
            '@type' => 'WebSite',
            '@id' => home_url( '/#website' ),
            'url' => home_url( '/' ),
            'name' => get_bloginfo( 'name' ),
            'description' => get_bloginfo( 'description' ),
            'publisher' => array(
                '@id' => home_url( '/#organization' ),
            ),
            'potentialAction' => array(
                '@type' => 'SearchAction',
                'target' => array(
                    '@type' => 'EntryPoint',
                    'urlTemplate' => home_url( '/?s={search_term_string}' ),
                ),
                'query-input' => 'required name=search_term_string',
            ),
        );
    }
    
    /**
     * Get Breadcrumb Schema
     */
    private function get_breadcrumb_schema() {
        $breadcrumbs = $this->get_breadcrumb_items();
        
        if ( empty( $breadcrumbs ) ) {
            return null;
        }
        
        $items = array();
        $position = 1;
        
        foreach ( $breadcrumbs as $crumb ) {
            $items[] = array(
                '@type' => 'ListItem',
                'position' => $position++,
                'name' => $crumb['title'],
                'item' => $crumb['url'],
            );
        }
        
        return array(
            '@type' => 'BreadcrumbList',
            '@id' => get_permalink() . '#breadcrumb',
            'itemListElement' => $items,
        );
    }
    
    /**
     * Get Breadcrumb Items
     */
    private function get_breadcrumb_items() {
        $breadcrumbs = array();
        
        // Home
        $breadcrumbs[] = array(
            'title' => __( 'Home', 'seo-pro' ),
            'url' => home_url( '/' ),
        );
        
        if ( is_singular() ) {
            global $post;
            
            // Categories/Taxonomies
            if ( $post->post_type === 'post' ) {
                $categories = get_the_category( $post->ID );
                if ( ! empty( $categories ) ) {
                    $category = $categories[0];
                    $breadcrumbs[] = array(
                        'title' => $category->name,
                        'url' => get_category_link( $category ),
                    );
                }
            } elseif ( $post->post_type === 'rtcl_listing' ) {
                $categories = wp_get_post_terms( $post->ID, 'rtcl_category' );
                if ( ! empty( $categories ) ) {
                    $category = $categories[0];
                    $breadcrumbs[] = array(
                        'title' => $category->name,
                        'url' => get_term_link( $category ),
                    );
                }
            }
            
            // Current post
            $breadcrumbs[] = array(
                'title' => get_the_title(),
                'url' => get_permalink(),
            );
        } elseif ( is_tax() || is_category() || is_tag() ) {
            $term = get_queried_object();
            $breadcrumbs[] = array(
                'title' => $term->name,
                'url' => get_term_link( $term ),
            );
        }
        
        return $breadcrumbs;
    }
    
    /**
     * Get Article Schema
     */
    private function get_article_schema() {
        global $post;
        
        $schema = array(
            '@type' => 'Article',
            '@id' => get_permalink() . '#article',
            'headline' => get_the_title(),
            'description' => wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 30 ),
            'datePublished' => get_the_date( 'c' ),
            'dateModified' => get_the_modified_date( 'c' ),
            'author' => array(
                '@type' => 'Person',
                'name' => get_the_author(),
            ),
            'publisher' => array(
                '@id' => home_url( '/#organization' ),
            ),
            'mainEntityOfPage' => array(
                '@type' => 'WebPage',
                '@id' => get_permalink(),
            ),
        );
        
        if ( has_post_thumbnail() ) {
            $schema['image'] = get_the_post_thumbnail_url( $post->ID, 'full' );
        }
        
        return $schema;
    }
    
    /**
     * Get WebPage Schema
     */
    private function get_webpage_schema() {
        return array(
            '@type' => 'WebPage',
            '@id' => get_permalink() . '#webpage',
            'url' => get_permalink(),
            'name' => get_the_title(),
            'description' => wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 30 ),
            'datePublished' => get_the_date( 'c' ),
            'dateModified' => get_the_modified_date( 'c' ),
            'isPartOf' => array(
                '@id' => home_url( '/#website' ),
            ),
        );
    }
    
    /**
     * Get Product Schema (for RTCL listings)
     */
    private function get_product_schema() {
        global $post;
        
        $schema = array(
            '@type' => 'Product',
            '@id' => get_permalink() . '#product',
            'name' => get_the_title(),
            'description' => wp_trim_words( wp_strip_all_tags( get_the_excerpt() ), 30 ),
            'url' => get_permalink(),
        );
        
        if ( has_post_thumbnail() ) {
            $schema['image'] = get_the_post_thumbnail_url( $post->ID, 'full' );
        }
        
        // Price (if available)
        $price = get_post_meta( $post->ID, 'price', true );
        if ( $price ) {
            $schema['offers'] = array(
                '@type' => 'Offer',
                'price' => $price,
                'priceCurrency' => 'INR',
                'availability' => 'https://schema.org/InStock',
                'url' => get_permalink(),
            );
        }
        
        return $schema;
    }
    
    /**
     * Get Local Business Schema
     */
    private function get_local_business_schema() {
        $locality = get_option( 'seo_locality' );
        $phone = get_option( 'seo_phone' );
        
        if ( ! $locality && ! $phone ) {
            return null;
        }
        
        $schema = array(
            '@type' => get_option( 'seo_business_type', 'LocalBusiness' ),
            '@id' => home_url( '/#localbusiness' ),
            'name' => get_bloginfo( 'name' ),
            'description' => get_bloginfo( 'description' ),
            'url' => home_url( '/' ),
        );
        
        if ( $phone ) {
            $schema['telephone'] = $phone;
        }
        
        // Address
        $street = get_option( 'seo_street_address' );
        $region = get_option( 'seo_region' );
        $postal_code = get_option( 'seo_postal_code' );
        
        if ( $locality || $region || $postal_code ) {
            $schema['address'] = array(
                '@type' => 'PostalAddress',
                'addressLocality' => $locality,
                'addressRegion' => $region,
                'postalCode' => $postal_code,
                'addressCountry' => 'IN',
            );
            
            if ( $street ) {
                $schema['address']['streetAddress'] = $street;
            }
        }
        
        // Geo Coordinates
        $latitude = get_option( 'seo_latitude' );
        $longitude = get_option( 'seo_longitude' );
        
        if ( $latitude && $longitude ) {
            $schema['geo'] = array(
                '@type' => 'GeoCoordinates',
                'latitude' => $latitude,
                'longitude' => $longitude,
            );
        }
        
        // Opening Hours
        $schema['openingHoursSpecification'] = array(
            '@type' => 'OpeningHoursSpecification',
            'dayOfWeek' => array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' ),
            'opens' => '00:00',
            'closes' => '23:59',
        );
        
        // Price Range
        $price_range = get_option( 'seo_price_range' );
        if ( $price_range ) {
            $schema['priceRange'] = $price_range;
        }
        
        return $schema;
    }
}
