<?php
/**
 * SEO Image Optimizer - Auto Image Alt Text & Optimization
 *
 * @package SEO_Pro
 * @since 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Image_Optimizer {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add Image Optimization menu
        add_action( 'admin_menu', array( $this, 'add_image_menu' ), 26 );
        
        // Auto add alt text to images
        if ( get_option( 'seo_pro_auto_image_alt', 1 ) ) {
            add_filter( 'wp_get_attachment_image_attributes', array( $this, 'auto_add_alt_text' ), 10, 3 );
            add_filter( 'the_content', array( $this, 'add_alt_to_content_images' ), 999 );
        }
        
        // Optimize images on upload
        if ( get_option( 'seo_pro_optimize_on_upload', 1 ) ) {
            add_filter( 'wp_handle_upload', array( $this, 'optimize_image_on_upload' ) );
        }
        
        // Add image title and caption
        if ( get_option( 'seo_pro_auto_image_title', 1 ) ) {
            add_action( 'add_attachment', array( $this, 'auto_add_image_metadata' ) );
        }
        
        // Lazy load images
        if ( get_option( 'seo_pro_lazy_load_images', 1 ) ) {
            add_filter( 'wp_get_attachment_image_attributes', array( $this, 'add_lazy_loading' ), 10, 3 );
        }
    }
    
    /**
     * Add Image menu
     */
    public function add_image_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'Image Optimization', 'seo-pro' ),
            __( '🖼️ Images', 'seo-pro' ),
            'manage_options',
            'seo-pro-images',
            array( $this, 'render_image_page' )
        );
    }
    
    /**
     * Auto add alt text to images
     */
    public function auto_add_alt_text( $attr, $attachment, $size ) {
        // If alt is already set, don't override
        if ( ! empty( $attr['alt'] ) ) {
            return $attr;
        }
        
        $post_id = $attachment->ID;
        
        // Try to get alt from post meta
        $alt = get_post_meta( $post_id, '_wp_attachment_image_alt', true );
        
        if ( empty( $alt ) ) {
            // Generate alt from image title
            $alt = get_the_title( $post_id );
            
            // If title is empty, use filename
            if ( empty( $alt ) ) {
                $filename = basename( get_attached_file( $post_id ) );
                $alt = pathinfo( $filename, PATHINFO_FILENAME );
                $alt = str_replace( array( '-', '_' ), ' ', $alt );
            }
            
            // Add post title context if image is attached to a post
            $parent_id = wp_get_post_parent_id( $post_id );
            if ( $parent_id ) {
                $parent_title = get_the_title( $parent_id );
                if ( ! empty( $parent_title ) ) {
                    $alt = $alt . ' - ' . $parent_title;
                }
            }
            
            // Clean up alt text
            $alt = ucwords( trim( $alt ) );
            
            // Save for future use
            update_post_meta( $post_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
        }
        
        $attr['alt'] = $alt;
        
        return $attr;
    }
    
    /**
     * Add alt text to images in content
     */
    public function add_alt_to_content_images( $content ) {
        // Find all img tags without alt attribute
        $pattern = '/<img(?![^>]*alt=)[^>]*>/i';
        
        preg_match_all( $pattern, $content, $matches );
        
        if ( ! empty( $matches[0] ) ) {
            foreach ( $matches[0] as $img_tag ) {
                // Extract src
                preg_match( '/src=["\']([^"\']+)["\']/', $img_tag, $src_match );
                
                if ( ! empty( $src_match[1] ) ) {
                    $src = $src_match[1];
                    
                    // Get attachment ID from URL
                    $attachment_id = attachment_url_to_postid( $src );
                    
                    if ( $attachment_id ) {
                        $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
                        
                        if ( empty( $alt ) ) {
                            $alt = get_the_title( $attachment_id );
                        }
                        
                        if ( empty( $alt ) ) {
                            // Use current post title
                            $alt = get_the_title();
                        }
                        
                        // Add alt attribute
                        $new_img_tag = str_replace( '<img', '<img alt="' . esc_attr( $alt ) . '"', $img_tag );
                        $content = str_replace( $img_tag, $new_img_tag, $content );
                    } else {
                        // Use filename as fallback
                        $filename = basename( $src );
                        $alt = pathinfo( $filename, PATHINFO_FILENAME );
                        $alt = str_replace( array( '-', '_' ), ' ', $alt );
                        $alt = ucwords( trim( $alt ) );
                        
                        $new_img_tag = str_replace( '<img', '<img alt="' . esc_attr( $alt ) . '"', $img_tag );
                        $content = str_replace( $img_tag, $new_img_tag, $content );
                    }
                }
            }
        }
        
        return $content;
    }
    
    /**
     * Auto add image metadata (title, caption)
     */
    public function auto_add_image_metadata( $attachment_id ) {
        $attachment = get_post( $attachment_id );
        
        if ( ! $attachment || strpos( $attachment->post_mime_type, 'image' ) === false ) {
            return;
        }
        
        // Generate title from filename if empty
        if ( empty( $attachment->post_title ) ) {
            $filename = basename( get_attached_file( $attachment_id ) );
            $title = pathinfo( $filename, PATHINFO_FILENAME );
            $title = str_replace( array( '-', '_' ), ' ', $title );
            $title = ucwords( trim( $title ) );
            
            wp_update_post( array(
                'ID' => $attachment_id,
                'post_title' => $title
            ) );
        }
        
        // Auto-generate alt text
        $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
        if ( empty( $alt ) ) {
            $alt = get_the_title( $attachment_id );
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
        }
    }
    
    /**
     * Add lazy loading
     */
    public function add_lazy_loading( $attr, $attachment, $size ) {
        $attr['loading'] = 'lazy';
        return $attr;
    }
    
    /**
     * Optimize image on upload (placeholder for future compression)
     */
    public function optimize_image_on_upload( $upload ) {
        // Future: Add image compression logic here
        // For now, just ensure metadata is set
        return $upload;
    }
    
    /**
     * Render Image Optimization page
     */
    public function render_image_page() {
        // Save settings
        if ( isset( $_POST['seo_pro_image_nonce'] ) && wp_verify_nonce( $_POST['seo_pro_image_nonce'], 'seo_pro_image_save' ) ) {
            update_option( 'seo_pro_auto_image_alt', isset( $_POST['seo_pro_auto_image_alt'] ) ? 1 : 0 );
            update_option( 'seo_pro_auto_image_title', isset( $_POST['seo_pro_auto_image_title'] ) ? 1 : 0 );
            update_option( 'seo_pro_lazy_load_images', isset( $_POST['seo_pro_lazy_load_images'] ) ? 1 : 0 );
            update_option( 'seo_pro_optimize_on_upload', isset( $_POST['seo_pro_optimize_on_upload'] ) ? 1 : 0 );
            
            echo '<div class="notice notice-success"><p><strong>✅ Image optimization settings saved!</strong></p></div>';
        }
        
        // Bulk optimize existing images
        if ( isset( $_POST['seo_pro_bulk_optimize_nonce'] ) && wp_verify_nonce( $_POST['seo_pro_bulk_optimize_nonce'], 'seo_pro_bulk_optimize' ) ) {
            $optimized = $this->bulk_optimize_images();
            echo '<div class="notice notice-success"><p><strong>✅ Optimized ' . $optimized . ' images!</strong></p></div>';
        }
        
        $auto_alt = get_option( 'seo_pro_auto_image_alt', 1 );
        $auto_title = get_option( 'seo_pro_auto_image_title', 1 );
        $lazy_load = get_option( 'seo_pro_lazy_load_images', 1 );
        $optimize_upload = get_option( 'seo_pro_optimize_on_upload', 1 );
        
        // Get image stats
        $total_images = wp_count_posts( 'attachment' )->inherit;
        $images_without_alt = $this->count_images_without_alt();
        
        ?>
        <div class="wrap">
            <h1>🖼️ Image Optimization - SEO Pro</h1>
            <p class="description">Automatically optimize images for better SEO and accessibility</p>
            
            <div class="seo-pro-stats" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0;">
                <div style="background: #fff; border-left: 4px solid #0073aa; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin: 0; color: #0073aa;">📊 Total Images</h3>
                    <p style="font-size: 32px; margin: 10px 0; font-weight: bold;"><?php echo number_format( $total_images ); ?></p>
                </div>
                <div style="background: #fff; border-left: 4px solid #dc3232; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin: 0; color: #dc3232;">⚠️ Missing Alt Text</h3>
                    <p style="font-size: 32px; margin: 10px 0; font-weight: bold;"><?php echo number_format( $images_without_alt ); ?></p>
                </div>
                <div style="background: #fff; border-left: 4px solid #46b450; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin: 0; color: #46b450;">✅ Optimized</h3>
                    <p style="font-size: 32px; margin: 10px 0; font-weight: bold;"><?php echo number_format( $total_images - $images_without_alt ); ?></p>
                </div>
            </div>
            
            <form method="post" action="">
                <?php wp_nonce_field( 'seo_pro_image_save', 'seo_pro_image_nonce' ); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_auto_image_alt">🏷️ Auto Image Alt Text</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_auto_image_alt" id="seo_pro_auto_image_alt" value="1" <?php checked( $auto_alt, 1 ); ?>>
                                Automatically generates alt text from image filename and post title
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Improves SEO and accessibility. Alt text is generated from:</p>
                            <ul style="margin-left: 20px;">
                                <li>1. Existing alt text (if available)</li>
                                <li>2. Image title</li>
                                <li>3. Image filename (cleaned up)</li>
                                <li>4. Parent post title (for context)</li>
                            </ul>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_auto_image_title">📝 Auto Image Title</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_auto_image_title" id="seo_pro_auto_image_title" value="1" <?php checked( $auto_title, 1 ); ?>>
                                Automatically generates image title from filename
                            </label>
                            <p class="description">Converts "my-awesome-image.jpg" to "My Awesome Image"</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_lazy_load_images">⚡ Lazy Load Images</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_lazy_load_images" id="seo_pro_lazy_load_images" value="1" <?php checked( $lazy_load, 1 ); ?>>
                                Add loading="lazy" attribute to images
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Improves page load speed by deferring off-screen images</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_optimize_on_upload">🔄 Optimize on Upload</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_optimize_on_upload" id="seo_pro_optimize_on_upload" value="1" <?php checked( $optimize_upload, 1 ); ?>>
                                Automatically optimize images when uploaded
                            </label>
                            <p class="description">Ensures all new images have proper metadata</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="💾 Save Image Settings">
                </p>
            </form>
            
            <hr>
            
            <h2>🔧 Bulk Optimize Existing Images</h2>
            <p>Add alt text to all existing images that are missing it.</p>
            
            <form method="post" action="">
                <?php wp_nonce_field( 'seo_pro_bulk_optimize', 'seo_pro_bulk_optimize_nonce' ); ?>
                <p class="submit">
                    <input type="submit" name="bulk_optimize" class="button button-secondary" value="🚀 Optimize All Images (<?php echo number_format( $images_without_alt ); ?> images)" <?php echo $images_without_alt == 0 ? 'disabled' : ''; ?>>
                </p>
            </form>
            
            <div class="seo-pro-info-box" style="background: #f0f6fc; border-left: 4px solid #0073aa; padding: 15px; margin-top: 20px;">
                <h3>💡 Image SEO Best Practices</h3>
                <ul style="margin-left: 20px;">
                    <li><strong>Alt Text:</strong> Describe the image clearly and include relevant keywords naturally</li>
                    <li><strong>File Names:</strong> Use descriptive filenames (e.g., "red-sports-car.jpg" not "IMG_1234.jpg")</li>
                    <li><strong>File Size:</strong> Compress images before upload (aim for under 200KB)</li>
                    <li><strong>Dimensions:</strong> Upload images at the exact size needed (don't rely on CSS resizing)</li>
                    <li><strong>Format:</strong> Use WebP for modern browsers, JPEG for photos, PNG for graphics</li>
                    <li><strong>Lazy Loading:</strong> Always enable for better performance</li>
                </ul>
            </div>
        </div>
        <?php
    }
    
    /**
     * Count images without alt text
     */
    private function count_images_without_alt() {
        global $wpdb;
        
        $count = $wpdb->get_var( "
            SELECT COUNT(*)
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_wp_attachment_image_alt'
            WHERE p.post_type = 'attachment'
            AND p.post_mime_type LIKE 'image/%'
            AND (pm.meta_value IS NULL OR pm.meta_value = '')
        " );
        
        return (int) $count;
    }
    
    /**
     * Bulk optimize images
     */
    private function bulk_optimize_images() {
        global $wpdb;
        
        // Get all images without alt text
        $images = $wpdb->get_results( "
            SELECT p.ID
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_wp_attachment_image_alt'
            WHERE p.post_type = 'attachment'
            AND p.post_mime_type LIKE 'image/%'
            AND (pm.meta_value IS NULL OR pm.meta_value = '')
            LIMIT 500
        " );
        
        $count = 0;
        
        foreach ( $images as $image ) {
            $attachment_id = $image->ID;
            
            // Generate alt text
            $alt = get_the_title( $attachment_id );
            
            if ( empty( $alt ) ) {
                $filename = basename( get_attached_file( $attachment_id ) );
                $alt = pathinfo( $filename, PATHINFO_FILENAME );
                $alt = str_replace( array( '-', '_' ), ' ', $alt );
            }
            
            // Add parent post context
            $parent_id = wp_get_post_parent_id( $attachment_id );
            if ( $parent_id ) {
                $parent_title = get_the_title( $parent_id );
                if ( ! empty( $parent_title ) ) {
                    $alt = $alt . ' - ' . $parent_title;
                }
            }
            
            $alt = ucwords( trim( $alt ) );
            
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
            $count++;
        }
        
        return $count;
    }
}

// Initialize
SEO_Pro_Image_Optimizer::instance();
