<?php
/**
 * SEO Auto Linking - Advanced Automatic Internal Linking
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Auto_Linking {
    
    private static $instance = null;
    private $link_count = array();
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        add_filter( 'the_content', array( $this, 'auto_link_content' ), 999 );
        add_action( 'wp_footer', array( $this, 'track_link_analytics' ) );
    }
    
    /**
     * Auto link content with advanced SEO features
     */
    public function auto_link_content( $content ) {
        if ( ! is_singular() || is_admin() ) {
            return $content;
        }
        
        $keywords = get_option( 'seo_auto_link_keywords', array() );
        
        if ( empty( $keywords ) || ! is_array( $keywords ) ) {
            return $content;
        }
        
        // Sort keywords by priority (higher priority first)
        usort( $keywords, function( $a, $b ) {
            $priority_a = isset( $a['priority'] ) ? intval( $a['priority'] ) : 5;
            $priority_b = isset( $b['priority'] ) ? intval( $b['priority'] ) : 5;
            return $priority_b - $priority_a;
        });
        
        $current_url = get_permalink();
        $current_post_type = get_post_type();
        
        // Get global settings
        $exclude_headings = get_option( 'seo_auto_link_exclude_headings', true );
        
        // Split content to exclude headings if needed
        if ( $exclude_headings ) {
            $content = $this->process_content_exclude_headings( $content, $keywords, $current_url, $current_post_type );
        } else {
            $content = $this->process_content( $content, $keywords, $current_url, $current_post_type );
        }
        
        return $content;
    }
    
    /**
     * Process content excluding headings
     */
    private function process_content_exclude_headings( $content, $keywords, $current_url, $current_post_type ) {
        // Split content by headings
        $parts = preg_split( '/(<h[1-6][^>]*>.*?<\/h[1-6]>)/is', $content, -1, PREG_SPLIT_DELIM_CAPTURE );
        
        $processed_parts = array();
        foreach ( $parts as $part ) {
            // Check if this is a heading
            if ( preg_match( '/^<h[1-6][^>]*>.*?<\/h[1-6]>$/is', $part ) ) {
                // Don't process headings
                $processed_parts[] = $part;
            } else {
                // Process non-heading content
                $processed_parts[] = $this->process_content( $part, $keywords, $current_url, $current_post_type );
            }
        }
        
        return implode( '', $processed_parts );
    }
    
    /**
     * Process content with keywords
     */
    private function process_content( $content, $keywords, $current_url, $current_post_type ) {
        foreach ( $keywords as $keyword_data ) {
            if ( empty( $keyword_data['keyword'] ) || empty( $keyword_data['url'] ) ) {
                continue;
            }
            
            // Check post type filter
            if ( ! empty( $keyword_data['post_types'] ) && is_array( $keyword_data['post_types'] ) ) {
                if ( ! in_array( $current_post_type, $keyword_data['post_types'] ) ) {
                    continue;
                }
            }
            
            $keyword = $keyword_data['keyword'];
            $url = $keyword_data['url'];
            $limit = isset( $keyword_data['limit'] ) ? intval( $keyword_data['limit'] ) : 3;
            $case_sensitive = isset( $keyword_data['case_sensitive'] ) ? $keyword_data['case_sensitive'] : false;
            $nofollow = isset( $keyword_data['nofollow'] ) ? $keyword_data['nofollow'] : false;
            $target_blank = isset( $keyword_data['target_blank'] ) ? $keyword_data['target_blank'] : false;
            $title = isset( $keyword_data['title'] ) ? $keyword_data['title'] : '';
            $first_only = isset( $keyword_data['first_only'] ) ? $keyword_data['first_only'] : false;
            
            // Don't link to the current page
            if ( $current_url === $url ) {
                continue;
            }
            
            // Don't link if already linked
            if ( strpos( $content, 'href="' . $url . '"' ) !== false ) {
                continue;
            }
            
            // Build link attributes
            $attributes = array();
            
            if ( $nofollow ) {
                $attributes[] = 'rel="nofollow"';
            }
            
            if ( $target_blank ) {
                $attributes[] = 'target="_blank"';
                $attributes[] = 'rel="noopener noreferrer"';
            }
            
            if ( ! empty( $title ) ) {
                $attributes[] = 'title="' . esc_attr( $title ) . '"';
            }
            
            $attrs_string = ! empty( $attributes ) ? ' ' . implode( ' ', $attributes ) : '';
            
            // Build pattern based on case sensitivity
            $pattern_modifier = $case_sensitive ? '' : 'i';
            $pattern = '/\b(' . preg_quote( $keyword, '/' ) . ')\b(?![^<]*<\/a>)/' . $pattern_modifier;
            
            // Build replacement
            $replacement = '<a href="' . esc_url( $url ) . '"' . $attrs_string . '>$1</a>';
            
            // Apply limit (first only or multiple)
            $actual_limit = $first_only ? 1 : $limit;
            
            // Count replacements for analytics
            $count = 0;
            $content = preg_replace( $pattern, $replacement, $content, $actual_limit, $count );
            
            // Track analytics
            if ( $count > 0 ) {
                $this->track_link_usage( $keyword, $url, $count );
            }
        }
        
        return $content;
    }
    
    /**
     * Track link usage for analytics
     */
    private function track_link_usage( $keyword, $url, $count ) {
        $analytics = get_option( 'seo_auto_link_analytics', array() );
        
        $key = md5( $keyword . $url );
        
        if ( ! isset( $analytics[ $key ] ) ) {
            $analytics[ $key ] = array(
                'keyword' => $keyword,
                'url' => $url,
                'total_links' => 0,
                'last_used' => current_time( 'mysql' ),
            );
        }
        
        $analytics[ $key ]['total_links'] += $count;
        $analytics[ $key ]['last_used'] = current_time( 'mysql' );
        
        update_option( 'seo_auto_link_analytics', $analytics );
    }
    
    /**
     * Track link analytics on page view
     */
    public function track_link_analytics() {
        // This can be extended for frontend tracking if needed
    }
    
    /**
     * Get analytics data
     */
    public static function get_analytics() {
        return get_option( 'seo_auto_link_analytics', array() );
    }
    
    /**
     * Reset analytics
     */
    public static function reset_analytics() {
        delete_option( 'seo_auto_link_analytics' );
    }
}
