<?php
/**
 * SEO Integrations - Google Search Console & Analytics Integration
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Integrations {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add integrations menu
        add_action( 'admin_menu', array( $this, 'add_integrations_menu' ), 30 );
        
        // Admin notices
        add_action( 'admin_notices', array( $this, 'integration_notices' ) );
    }
    
    /**
     * Add integrations menu
     */
    public function add_integrations_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'Integrations', 'seo-pro' ),
            __( 'Integrations', 'seo-pro' ),
            'manage_options',
            'seo-pro-integrations',
            array( $this, 'render_integrations_page' )
        );
    }
    
    /**
     * Integration notices
     */
    public function integration_notices() {
        $gsc_connected = get_option( 'seo_pro_gsc_connected', false );
        $ga_connected = get_option( 'seo_pro_ga_connected', false );
        
        if ( ! $gsc_connected && isset( $_GET['page'] ) && strpos( $_GET['page'], 'seo-pro' ) !== false ) {
            ?>
            <div class="notice notice-info is-dismissible">
                <p>
                    <strong><?php _e( 'SEO Pro:', 'seo-pro' ); ?></strong>
                    <?php _e( 'Connect Google Search Console to track your search performance!', 'seo-pro' ); ?>
                    <a href="<?php echo admin_url( 'admin.php?page=seo-pro-integrations' ); ?>" style="margin-left: 10px;">
                        <?php _e( 'Connect Now →', 'seo-pro' ); ?>
                    </a>
                </p>
            </div>
            <?php
        }
    }
    
    /**
     * Render integrations page
     */
    public function render_integrations_page() {
        // Handle form submission
        if ( isset( $_POST['save_integrations'] ) && check_admin_referer( 'seo_pro_integrations' ) ) {
            // Save Google Search Console settings
            update_option( 'seo_pro_gsc_site_url', esc_url_raw( $_POST['gsc_site_url'] ) );
            update_option( 'seo_pro_gsc_auth_code', sanitize_text_field( $_POST['gsc_auth_code'] ) );
            
            // Save Google Analytics settings
            update_option( 'seo_pro_ga_tracking_id', sanitize_text_field( $_POST['ga_tracking_id'] ) );
            update_option( 'seo_pro_ga_measurement_id', sanitize_text_field( $_POST['ga_measurement_id'] ) );
            
            // Save Google Trends settings
            update_option( 'seo_pro_trends_enabled', isset( $_POST['trends_enabled'] ) ? 1 : 0 );
            
            // Save Instant Indexing settings
            update_option( 'seo_pro_instant_indexing', isset( $_POST['instant_indexing'] ) ? 1 : 0 );
            update_option( 'seo_pro_indexing_api_key', sanitize_text_field( $_POST['indexing_api_key'] ) );
            
            echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Integration settings saved!', 'seo-pro' ) . '</p></div>';
        }
        
        $gsc_site_url = get_option( 'seo_pro_gsc_site_url', '' );
        $gsc_auth_code = get_option( 'seo_pro_gsc_auth_code', '' );
        $ga_tracking_id = get_option( 'seo_pro_ga_tracking_id', '' );
        $ga_measurement_id = get_option( 'seo_pro_ga_measurement_id', '' );
        $trends_enabled = get_option( 'seo_pro_trends_enabled', 0 );
        $instant_indexing = get_option( 'seo_pro_instant_indexing', 0 );
        $indexing_api_key = get_option( 'seo_pro_indexing_api_key', '' );
        
        ?>
        <div class="wrap seo-pro-wrap">
            <h1><?php _e( '🔌 SEO Integrations', 'seo-pro' ); ?></h1>
            
            <form method="post">
                <?php wp_nonce_field( 'seo_pro_integrations' ); ?>
                
                <!-- Google Search Console -->
                <div class="seo-card">
                    <h2><?php _e( 'Google Search Console', 'seo-pro' ); ?></h2>
                    <p><?php _e( 'Connect your site to Google Search Console to track search performance, impressions, clicks, and keyword rankings.', 'seo-pro' ); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="gsc_site_url"><?php _e( 'Site URL', 'seo-pro' ); ?></label></th>
                            <td>
                                <input type="url" id="gsc_site_url" name="gsc_site_url" value="<?php echo esc_attr( $gsc_site_url ); ?>" class="regular-text" placeholder="https://yoursite.com">
                                <p class="description"><?php _e( 'Your verified site URL in Google Search Console', 'seo-pro' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="gsc_auth_code"><?php _e( 'Authorization Code', 'seo-pro' ); ?></label></th>
                            <td>
                                <textarea id="gsc_auth_code" name="gsc_auth_code" rows="3" class="large-text"><?php echo esc_textarea( $gsc_auth_code ); ?></textarea>
                                <p class="description">
                                    <?php _e( 'Get your authorization code from', 'seo-pro' ); ?>
                                    <a href="https://search.google.com/search-console" target="_blank"><?php _e( 'Google Search Console', 'seo-pro' ); ?></a>
                                </p>
                            </td>
                        </tr>
                    </table>
                    
                    <div class="integration-status">
                        <?php if ( ! empty( $gsc_auth_code ) ) : ?>
                            <span class="status-badge connected">✓ <?php _e( 'Connected', 'seo-pro' ); ?></span>
                        <?php else : ?>
                            <span class="status-badge disconnected">✗ <?php _e( 'Not Connected', 'seo-pro' ); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Google Analytics 4 -->
                <div class="seo-card">
                    <h2><?php _e( 'Google Analytics 4', 'seo-pro' ); ?></h2>
                    <p><?php _e( 'Connect Google Analytics 4 to track user behavior, traffic sources, and conversions.', 'seo-pro' ); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th><label for="ga_tracking_id"><?php _e( 'Tracking ID (UA)', 'seo-pro' ); ?></label></th>
                            <td>
                                <input type="text" id="ga_tracking_id" name="ga_tracking_id" value="<?php echo esc_attr( $ga_tracking_id ); ?>" class="regular-text" placeholder="UA-XXXXXXXXX-X">
                                <p class="description"><?php _e( 'Universal Analytics Tracking ID (optional, for legacy support)', 'seo-pro' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="ga_measurement_id"><?php _e( 'Measurement ID (GA4)', 'seo-pro' ); ?></label></th>
                            <td>
                                <input type="text" id="ga_measurement_id" name="ga_measurement_id" value="<?php echo esc_attr( $ga_measurement_id ); ?>" class="regular-text" placeholder="G-XXXXXXXXXX">
                                <p class="description"><?php _e( 'Google Analytics 4 Measurement ID', 'seo-pro' ); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <div class="integration-status">
                        <?php if ( ! empty( $ga_measurement_id ) ) : ?>
                            <span class="status-badge connected">✓ <?php _e( 'Connected', 'seo-pro' ); ?></span>
                        <?php else : ?>
                            <span class="status-badge disconnected">✗ <?php _e( 'Not Connected', 'seo-pro' ); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Google Trends -->
                <div class="seo-card">
                    <h2><?php _e( 'Google Trends Integration', 'seo-pro' ); ?></h2>
                    <p><?php _e( 'Enable Google Trends to analyze keyword trends and seasonal patterns.', 'seo-pro' ); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th><?php _e( 'Enable Google Trends', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="trends_enabled" value="1" <?php checked( $trends_enabled, 1 ); ?>>
                                    <?php _e( 'Show Google Trends data in keyword analysis', 'seo-pro' ); ?>
                                </label>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Instant Indexing API -->
                <div class="seo-card">
                    <h2><?php _e( 'Instant Indexing API', 'seo-pro' ); ?></h2>
                    <p><?php _e( 'Automatically notify Google when you publish or update content for faster indexing.', 'seo-pro' ); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th><?php _e( 'Enable Instant Indexing', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="instant_indexing" value="1" <?php checked( $instant_indexing, 1 ); ?>>
                                    <?php _e( 'Automatically submit URLs to Google for indexing', 'seo-pro' ); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="indexing_api_key"><?php _e( 'API Key', 'seo-pro' ); ?></label></th>
                            <td>
                                <textarea id="indexing_api_key" name="indexing_api_key" rows="5" class="large-text"><?php echo esc_textarea( $indexing_api_key ); ?></textarea>
                                <p class="description">
                                    <?php _e( 'Get your API key from', 'seo-pro' ); ?>
                                    <a href="https://console.cloud.google.com/" target="_blank"><?php _e( 'Google Cloud Console', 'seo-pro' ); ?></a>
                                    (Enable Indexing API)
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Integration Guides -->
                <div class="seo-card">
                    <h2><?php _e( '📚 Setup Guides', 'seo-pro' ); ?></h2>
                    
                    <div class="guides-grid">
                        <div class="guide-item">
                            <h3><?php _e( 'Google Search Console', 'seo-pro' ); ?></h3>
                            <ol>
                                <li><?php _e( 'Go to Google Search Console', 'seo-pro' ); ?></li>
                                <li><?php _e( 'Add and verify your website', 'seo-pro' ); ?></li>
                                <li><?php _e( 'Generate API credentials', 'seo-pro' ); ?></li>
                                <li><?php _e( 'Paste authorization code above', 'seo-pro' ); ?></li>
                            </ol>
                        </div>
                        
                        <div class="guide-item">
                            <h3><?php _e( 'Google Analytics 4', 'seo-pro' ); ?></h3>
                            <ol>
                                <li><?php _e( 'Create GA4 property', 'seo-pro' ); ?></li>
                                <li><?php _e( 'Get Measurement ID (G-XXXXXXXXXX)', 'seo-pro' ); ?></li>
                                <li><?php _e( 'Paste Measurement ID above', 'seo-pro' ); ?></li>
                                <li><?php _e( 'Save settings', 'seo-pro' ); ?></li>
                            </ol>
                        </div>
                        
                        <div class="guide-item">
                            <h3><?php _e( 'Instant Indexing API', 'seo-pro' ); ?></h3>
                            <ol>
                                <li><?php _e( 'Enable Indexing API in Google Cloud', 'seo-pro' ); ?></li>
                                <li><?php _e( 'Create service account', 'seo-pro' ); ?></li>
                                <li><?php _e( 'Download JSON key file', 'seo-pro' ); ?></li>
                                <li><?php _e( 'Paste JSON content above', 'seo-pro' ); ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
                
                <p>
                    <button type="submit" name="save_integrations" class="button button-primary button-large">
                        <?php _e( 'Save Integration Settings', 'seo-pro' ); ?>
                    </button>
                </p>
            </form>
        </div>
        
        <style>
            .integration-status {
                margin-top: 15px;
                padding: 10px;
                background: #f0f0f1;
                border-radius: 4px;
            }
            .status-badge {
                display: inline-block;
                padding: 6px 12px;
                border-radius: 12px;
                font-weight: 600;
                font-size: 13px;
            }
            .status-badge.connected {
                background: #d4edda;
                color: #155724;
            }
            .status-badge.disconnected {
                background: #f8d7da;
                color: #721c24;
            }
            .guides-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-top: 15px;
            }
            .guide-item {
                background: #f9f9f9;
                padding: 15px;
                border-radius: 6px;
                border-left: 4px solid #2271b1;
            }
            .guide-item h3 {
                margin-top: 0;
                color: #2271b1;
            }
            .guide-item ol {
                margin: 10px 0;
                padding-left: 20px;
            }
            .guide-item li {
                margin-bottom: 8px;
                line-height: 1.5;
            }
        </style>
        <?php
    }
    
    /**
     * Get Search Console data (placeholder for API integration)
     */
    public static function get_search_console_data( $days = 30 ) {
        // This would integrate with Google Search Console API
        // For now, return placeholder data
        return array(
            'impressions' => 0,
            'clicks' => 0,
            'ctr' => 0,
            'position' => 0,
        );
    }
    
    /**
     * Get Analytics data (placeholder for API integration)
     */
    public static function get_analytics_data( $days = 30 ) {
        // This would integrate with Google Analytics API
        // For now, return placeholder data
        return array(
            'users' => 0,
            'sessions' => 0,
            'pageviews' => 0,
            'bounce_rate' => 0,
        );
    }
    
    /**
     * Submit URL to Google for instant indexing
     */
    public static function submit_url_for_indexing( $url ) {
        $api_key = get_option( 'seo_pro_indexing_api_key', '' );
        $instant_indexing = get_option( 'seo_pro_instant_indexing', 0 );
        
        if ( ! $instant_indexing || empty( $api_key ) ) {
            return false;
        }
        
        // This would use Google Indexing API
        // Placeholder for actual API call
        return true;
    }
}

// Auto-submit URLs when published
add_action( 'publish_post', function( $post_id ) {
    $url = get_permalink( $post_id );
    SEO_Pro_Integrations::submit_url_for_indexing( $url );
}, 10, 1 );
