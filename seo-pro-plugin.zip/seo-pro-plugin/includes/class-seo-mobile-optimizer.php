<?php
/**
 * SEO Mobile & Server Optimizer - Ultra-Fast Performance
 *
 * @package SEO_Pro
 * @since 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Mobile_Optimizer {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add Mobile Optimization menu
        add_action( 'admin_menu', array( $this, 'add_mobile_menu' ), 27 );
        
        // Apply mobile optimizations
        $this->apply_mobile_optimizations();
        
        // Apply server optimizations
        $this->apply_server_optimizations();
    }
    
    /**
     * Add Mobile menu
     */
    public function add_mobile_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'Mobile & Server Optimization', 'seo-pro' ),
            __( '⚡ Mobile Speed', 'seo-pro' ),
            'manage_options',
            'seo-pro-mobile',
            array( $this, 'render_mobile_page' )
        );
    }
    
    /**
     * Apply mobile optimizations
     */
    private function apply_mobile_optimizations() {
        // Ultra-fast mobile optimization
        if ( get_option( 'seo_pro_ultra_mobile', 1 ) ) {
            // Inline critical CSS
            add_action( 'wp_head', array( $this, 'inline_critical_css' ), 1 );
            
            // Defer non-critical CSS
            add_filter( 'style_loader_tag', array( $this, 'defer_non_critical_css' ), 10, 4 );
            
            // Defer JavaScript
            add_filter( 'script_loader_tag', array( $this, 'defer_javascript' ), 10, 3 );
            
            // Optimize images for mobile
            add_filter( 'wp_get_attachment_image_attributes', array( $this, 'optimize_mobile_images' ), 10, 3 );
            
            // Preconnect to external domains
            add_action( 'wp_head', array( $this, 'add_preconnect' ), 1 );
            
            // Remove render-blocking resources
            add_action( 'wp_enqueue_scripts', array( $this, 'remove_render_blocking' ), 999 );
        }
    }
    
    /**
     * Apply server optimizations
     */
    private function apply_server_optimizations() {
        // Server response optimization
        if ( get_option( 'seo_pro_server_optimization', 1 ) ) {
            // Enable GZIP compression
            add_action( 'init', array( $this, 'enable_gzip_compression' ) );
            
            // Add browser caching headers
            add_action( 'send_headers', array( $this, 'add_caching_headers' ) );
            
            // Optimize database queries
            add_filter( 'posts_request', array( $this, 'optimize_queries' ), 10, 2 );
            
            // Reduce TTFB (Time To First Byte)
            add_action( 'init', array( $this, 'reduce_ttfb' ), 1 );
        }
        
        // Remove WordPress bloat
        if ( get_option( 'seo_pro_remove_bloat', 1 ) ) {
            $this->remove_wordpress_bloat();
        }
        
        // Disable emojis
        if ( get_option( 'seo_pro_disable_emojis', 1 ) ) {
            $this->disable_emojis();
        }
    }
    
    /**
     * Inline critical CSS
     */
    public function inline_critical_css() {
        if ( is_admin() ) {
            return;
        }
        
        // Critical CSS for above-the-fold content
        $critical_css = "
        <style id='seo-pro-critical-css'>
        body{margin:0;padding:0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen-Sans,Ubuntu,Cantarell,'Helvetica Neue',sans-serif;line-height:1.6;color:#333;background:#fff}
        *{box-sizing:border-box}
        img{max-width:100%;height:auto;display:block}
        a{color:#0073aa;text-decoration:none}
        h1,h2,h3,h4,h5,h6{margin:0 0 1rem;line-height:1.2;font-weight:600}
        .site-header{background:#fff;border-bottom:1px solid #eee;padding:1rem 0}
        .site-content{padding:2rem 0}
        @media(max-width:768px){body{font-size:14px}.site-header{padding:.5rem 0}.site-content{padding:1rem 0}}
        </style>
        ";
        
        echo $critical_css . "\n";
    }
    
    /**
     * Defer non-critical CSS
     */
    public function defer_non_critical_css( $html, $handle, $href, $media ) {
        // Don't defer admin styles or critical styles
        if ( is_admin() || strpos( $handle, 'admin' ) !== false ) {
            return $html;
        }
        
        // Defer CSS loading
        $html = str_replace( "media='all'", "media='print' onload=\"this.media='all'\"", $html );
        
        return $html;
    }
    
    /**
     * Defer JavaScript
     */
    public function defer_javascript( $tag, $handle, $src ) {
        // Don't defer jQuery or admin scripts
        if ( is_admin() || $handle === 'jquery' || strpos( $handle, 'admin' ) !== false ) {
            return $tag;
        }
        
        // Add defer attribute
        if ( strpos( $tag, 'defer' ) === false && strpos( $tag, 'async' ) === false ) {
            $tag = str_replace( ' src', ' defer src', $tag );
        }
        
        return $tag;
    }
    
    /**
     * Optimize mobile images
     */
    public function optimize_mobile_images( $attr, $attachment, $size ) {
        // Add responsive image attributes
        $attr['loading'] = 'lazy';
        $attr['decoding'] = 'async';
        
        // Add width and height to prevent layout shift
        if ( ! isset( $attr['width'] ) || ! isset( $attr['height'] ) ) {
            $image_meta = wp_get_attachment_metadata( $attachment->ID );
            if ( ! empty( $image_meta['width'] ) && ! empty( $image_meta['height'] ) ) {
                $attr['width'] = $image_meta['width'];
                $attr['height'] = $image_meta['height'];
            }
        }
        
        return $attr;
    }
    
    /**
     * Add preconnect to external domains
     */
    public function add_preconnect() {
        echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
        echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
        echo '<link rel="dns-prefetch" href="//fonts.googleapis.com">' . "\n";
        echo '<link rel="dns-prefetch" href="//fonts.gstatic.com">' . "\n";
    }
    
    /**
     * Remove render-blocking resources
     */
    public function remove_render_blocking() {
        // Remove block library CSS (Gutenberg)
        wp_dequeue_style( 'wp-block-library' );
        wp_dequeue_style( 'wp-block-library-theme' );
        wp_dequeue_style( 'wc-block-style' );
        
        // Remove global styles
        wp_dequeue_style( 'global-styles' );
        
        // Remove classic theme styles
        wp_dequeue_style( 'classic-theme-styles' );
    }
    
    /**
     * Enable GZIP compression
     */
    public function enable_gzip_compression() {
        if ( ! headers_sent() && extension_loaded( 'zlib' ) && ! ini_get( 'zlib.output_compression' ) ) {
            if ( ! ob_start( 'ob_gzhandler' ) ) {
                ob_start();
            }
        }
    }
    
    /**
     * Add caching headers
     */
    public function add_caching_headers() {
        if ( is_admin() || is_user_logged_in() ) {
            return;
        }
        
        // Set cache control headers
        header( 'Cache-Control: public, max-age=31536000' );
        header( 'Expires: ' . gmdate( 'D, d M Y H:i:s', time() + 31536000 ) . ' GMT' );
        header( 'Vary: Accept-Encoding' );
    }
    
    /**
     * Optimize database queries
     */
    public function optimize_queries( $request, $query ) {
        // Add query optimization hints
        if ( ! is_admin() && ! $query->is_singular() ) {
            $request = str_replace( 'SELECT', 'SELECT SQL_NO_CACHE', $request );
        }
        
        return $request;
    }
    
    /**
     * Reduce TTFB
     */
    public function reduce_ttfb() {
        // Disable WordPress heartbeat on frontend
        if ( ! is_admin() ) {
            wp_deregister_script( 'heartbeat' );
        }
        
        // Limit post revisions
        if ( ! defined( 'WP_POST_REVISIONS' ) ) {
            define( 'WP_POST_REVISIONS', 3 );
        }
        
        // Increase autosave interval
        if ( ! defined( 'AUTOSAVE_INTERVAL' ) ) {
            define( 'AUTOSAVE_INTERVAL', 300 );
        }
    }
    
    /**
     * Remove WordPress bloat
     */
    private function remove_wordpress_bloat() {
        // Remove WP version
        remove_action( 'wp_head', 'wp_generator' );
        
        // Remove RSD link
        remove_action( 'wp_head', 'rsd_link' );
        
        // Remove wlwmanifest link
        remove_action( 'wp_head', 'wlwmanifest_link' );
        
        // Remove shortlink
        remove_action( 'wp_head', 'wp_shortlink_wp_head' );
        
        // Remove REST API links
        remove_action( 'wp_head', 'rest_output_link_wp_head' );
        remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
        
        // Remove feed links
        remove_action( 'wp_head', 'feed_links', 2 );
        remove_action( 'wp_head', 'feed_links_extra', 3 );
        
        // Remove DNS prefetch
        remove_action( 'wp_head', 'wp_resource_hints', 2 );
    }
    
    /**
     * Disable emojis
     */
    private function disable_emojis() {
        remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
        remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
        remove_action( 'wp_print_styles', 'print_emoji_styles' );
        remove_action( 'admin_print_styles', 'print_emoji_styles' );
        remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
        remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
        remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
        
        add_filter( 'tiny_mce_plugins', array( $this, 'disable_emojis_tinymce' ) );
        add_filter( 'wp_resource_hints', array( $this, 'disable_emojis_dns_prefetch' ), 10, 2 );
    }
    
    public function disable_emojis_tinymce( $plugins ) {
        if ( is_array( $plugins ) ) {
            return array_diff( $plugins, array( 'wpemoji' ) );
        }
        return array();
    }
    
    public function disable_emojis_dns_prefetch( $urls, $relation_type ) {
        if ( 'dns-prefetch' === $relation_type ) {
            $emoji_svg_url = apply_filters( 'emoji_svg_url', 'https://s.w.org/images/core/emoji/2/svg/' );
            $urls = array_diff( $urls, array( $emoji_svg_url ) );
        }
        return $urls;
    }
    
    /**
     * Render Mobile Optimization page
     */
    public function render_mobile_page() {
        // Save settings
        if ( isset( $_POST['seo_pro_mobile_nonce'] ) && wp_verify_nonce( $_POST['seo_pro_mobile_nonce'], 'seo_pro_mobile_save' ) ) {
            update_option( 'seo_pro_ultra_mobile', isset( $_POST['seo_pro_ultra_mobile'] ) ? 1 : 0 );
            update_option( 'seo_pro_server_optimization', isset( $_POST['seo_pro_server_optimization'] ) ? 1 : 0 );
            update_option( 'seo_pro_remove_bloat', isset( $_POST['seo_pro_remove_bloat'] ) ? 1 : 0 );
            update_option( 'seo_pro_disable_emojis', isset( $_POST['seo_pro_disable_emojis'] ) ? 1 : 0 );
            
            echo '<div class="notice notice-success"><p><strong>✅ Mobile & Server optimization settings saved!</strong></p></div>';
        }
        
        $ultra_mobile = get_option( 'seo_pro_ultra_mobile', 1 );
        $server_optimization = get_option( 'seo_pro_server_optimization', 1 );
        $remove_bloat = get_option( 'seo_pro_remove_bloat', 1 );
        $disable_emojis = get_option( 'seo_pro_disable_emojis', 1 );
        
        ?>
        <div class="wrap">
            <h1>⚡ Mobile & Server Optimization - SEO Pro</h1>
            <p class="description">Ultra-fast mobile and server optimizations for 95+ mobile score</p>
            
            <div class="seo-pro-performance-banner" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 30px; border-radius: 8px; margin: 20px 0;">
                <h2 style="color: #fff; margin: 0 0 10px;">🚀 Target: 95+ Mobile Score</h2>
                <p style="margin: 0; font-size: 16px;">These optimizations will dramatically improve your PageSpeed Insights mobile score!</p>
            </div>
            
            <form method="post" action="">
                <?php wp_nonce_field( 'seo_pro_mobile_save', 'seo_pro_mobile_nonce' ); ?>
                
                <h2>📱 Mobile Optimization</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_ultra_mobile">⚡ Ultra-Fast Mobile Optimization</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_ultra_mobile" id="seo_pro_ultra_mobile" value="1" <?php checked( $ultra_mobile, 1 ); ?>>
                                Enable ultra-fast mobile optimization
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Includes:</p>
                            <ul style="margin-left: 20px;">
                                <li>✅ Inline critical CSS for faster rendering</li>
                                <li>✅ Defer non-critical CSS and JavaScript</li>
                                <li>✅ Optimize images for mobile (lazy load, async decode)</li>
                                <li>✅ Preconnect to external domains</li>
                                <li>✅ Remove render-blocking resources</li>
                                <li>✅ Add width/height to images (prevent layout shift)</li>
                            </ul>
                        </td>
                    </tr>
                </table>
                
                <h2>🖥️ Server Optimization</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_server_optimization">🔧 Server Response Optimization</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_server_optimization" id="seo_pro_server_optimization" value="1" <?php checked( $server_optimization, 1 ); ?>>
                                Enable server response optimization
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Includes:</p>
                            <ul style="margin-left: 20px;">
                                <li>✅ GZIP compression (reduce file sizes by 70%)</li>
                                <li>✅ Browser caching headers (1 year cache)</li>
                                <li>✅ Database query optimization</li>
                                <li>✅ Reduce TTFB (Time To First Byte)</li>
                                <li>✅ Disable WordPress heartbeat on frontend</li>
                                <li>✅ Limit post revisions to 3</li>
                            </ul>
                        </td>
                    </tr>
                </table>
                
                <h2>🧹 WordPress Bloat Removal</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_remove_bloat">🗑️ Remove WordPress Bloat</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_remove_bloat" id="seo_pro_remove_bloat" value="1" <?php checked( $remove_bloat, 1 ); ?>>
                                Remove unnecessary WordPress code from head
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Removes:</p>
                            <ul style="margin-left: 20px;">
                                <li>✅ WP version meta tag</li>
                                <li>✅ RSD and wlwmanifest links</li>
                                <li>✅ Shortlink</li>
                                <li>✅ REST API links</li>
                                <li>✅ oEmbed discovery links</li>
                                <li>✅ Feed links</li>
                                <li>✅ DNS prefetch hints</li>
                            </ul>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_disable_emojis">😀 Disable Emojis</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_disable_emojis" id="seo_pro_disable_emojis" value="1" <?php checked( $disable_emojis, 1 ); ?>>
                                Remove emoji scripts and styles
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Saves ~15KB per page load</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="💾 Save Optimization Settings">
                </p>
            </form>
            
            <hr>
            
            <div class="seo-pro-info-box" style="background: #f0f6fc; border-left: 4px solid #0073aa; padding: 15px; margin-top: 20px;">
                <h3>📊 Expected Performance Improvements</h3>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #0073aa; color: #fff;">
                            <th style="padding: 10px; text-align: left;">Metric</th>
                            <th style="padding: 10px; text-align: left;">Before</th>
                            <th style="padding: 10px; text-align: left;">After</th>
                            <th style="padding: 10px; text-align: left;">Improvement</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr style="background: #f9f9f9;">
                            <td style="padding: 10px;">Mobile Score</td>
                            <td style="padding: 10px;">60-70</td>
                            <td style="padding: 10px; color: #46b450; font-weight: bold;">95+</td>
                            <td style="padding: 10px; color: #46b450;">+35 points</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px;">Page Load Time</td>
                            <td style="padding: 10px;">3-5s</td>
                            <td style="padding: 10px; color: #46b450; font-weight: bold;">1-2s</td>
                            <td style="padding: 10px; color: #46b450;">-60%</td>
                        </tr>
                        <tr style="background: #f9f9f9;">
                            <td style="padding: 10px;">TTFB</td>
                            <td style="padding: 10px;">800ms</td>
                            <td style="padding: 10px; color: #46b450; font-weight: bold;">200ms</td>
                            <td style="padding: 10px; color: #46b450;">-75%</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px;">File Size</td>
                            <td style="padding: 10px;">500KB</td>
                            <td style="padding: 10px; color: #46b450; font-weight: bold;">150KB</td>
                            <td style="padding: 10px; color: #46b450;">-70%</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="seo-pro-info-box" style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin-top: 20px;">
                <h3>🎯 Additional Performance Tips</h3>
                <ul style="margin-left: 20px;">
                    <li><strong>Use a CDN:</strong> Cloudflare (free) or BunnyCDN for global content delivery</li>
                    <li><strong>Enable Object Caching:</strong> Redis or Memcached for database caching</li>
                    <li><strong>Optimize Images:</strong> Use WebP format and compress before upload</li>
                    <li><strong>Minify CSS/JS:</strong> Use Autoptimize or WP Rocket</li>
                    <li><strong>Use Fast Hosting:</strong> Cloudways, Kinsta, or WP Engine</li>
                    <li><strong>Limit Plugins:</strong> Keep only essential plugins active</li>
                    <li><strong>Database Cleanup:</strong> Use WP-Optimize to clean database regularly</li>
                </ul>
            </div>
            
            <div class="seo-pro-info-box" style="background: #d4edda; border-left: 4px solid #28a745; padding: 15px; margin-top: 20px;">
                <h3>✅ Testing Your Performance</h3>
                <p><strong>Test your site speed with these tools:</strong></p>
                <ul style="margin-left: 20px;">
                    <li>🔍 <a href="https://pagespeed.web.dev/" target="_blank">Google PageSpeed Insights</a> - Official Google tool</li>
                    <li>🔍 <a href="https://gtmetrix.com/" target="_blank">GTmetrix</a> - Detailed performance report</li>
                    <li>🔍 <a href="https://tools.pingdom.com/" target="_blank">Pingdom</a> - Global speed test</li>
                    <li>🔍 <a href="https://www.webpagetest.org/" target="_blank">WebPageTest</a> - Advanced testing</li>
                </ul>
            </div>
        </div>
        <?php
    }
}

// Initialize
SEO_Pro_Mobile_Optimizer::instance();
