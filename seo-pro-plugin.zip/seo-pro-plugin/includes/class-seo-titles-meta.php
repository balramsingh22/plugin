<?php
/**
 * SEO Titles & Meta - Advanced title and meta description templates
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Titles_Meta {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add Titles & Meta menu
        add_action( 'admin_menu', array( $this, 'add_titles_meta_menu' ), 15 );
        
        // Apply title templates
        add_filter( 'wp_title', array( $this, 'apply_title_template' ), 10, 2 );
        add_filter( 'document_title_parts', array( $this, 'apply_document_title' ), 999 );
        
        // Apply meta description templates
        add_action( 'wp_head', array( $this, 'apply_meta_description' ), 1 );
    }
    
    /**
     * Add Titles & Meta menu
     */
    public function add_titles_meta_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'Titles & Meta', 'seo-pro' ),
            __( 'Titles & Meta', 'seo-pro' ),
            'manage_options',
            'seo-pro-titles-meta',
            array( $this, 'render_titles_meta_page' )
        );
    }
    
    /**
     * Render Titles & Meta page
     */
    public function render_titles_meta_page() {
        // Handle form submission
        if ( isset( $_POST['save_titles_meta'] ) && check_admin_referer( 'seo_pro_titles_meta' ) ) {
            $this->save_titles_meta_settings();
            echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Titles & Meta settings saved!', 'seo-pro' ) . '</p></div>';
        }
        
        ?>
        <div class="wrap seo-pro-wrap">
            <h1><?php _e( '📝 Titles & Meta Templates', 'seo-pro' ); ?></h1>
            <p><?php _e( 'Configure title and meta description templates for all post types, taxonomies, and archives.', 'seo-pro' ); ?></p>
            
            <form method="post">
                <?php wp_nonce_field( 'seo_pro_titles_meta' ); ?>
                
                <!-- Post Types -->
                <div class="seo-card">
                    <h2><?php _e( '📄 Post Types', 'seo-pro' ); ?></h2>
                    
                    <?php
                    $post_types = get_post_types( array( 'public' => true ), 'objects' );
                    
                    foreach ( $post_types as $post_type ) :
                        $title_template = get_option( "seo_pro_title_{$post_type->name}", '%title% %sep% %sitename%' );
                        $desc_template = get_option( "seo_pro_description_{$post_type->name}", '%excerpt%' );
                    ?>
                        <div class="template-section">
                            <h3><?php echo esc_html( $post_type->labels->name ); ?> (<?php echo esc_html( $post_type->name ); ?>)</h3>
                            
                            <table class="form-table">
                                <tr>
                                    <th><label><?php _e( 'Title Template', 'seo-pro' ); ?></label></th>
                                    <td>
                                        <input type="text" 
                                               name="title_<?php echo esc_attr( $post_type->name ); ?>" 
                                               value="<?php echo esc_attr( $title_template ); ?>" 
                                               class="large-text"
                                               placeholder="%title% %sep% %sitename%">
                                        <p class="description">
                                            <?php _e( 'Available variables:', 'seo-pro' ); ?>
                                            <code>%title%</code>
                                            <code>%sep%</code>
                                            <code>%sitename%</code>
                                            <code>%sitedesc%</code>
                                            <code>%author%</code>
                                            <code>%date%</code>
                                            <code>%year%</code>
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label><?php _e( 'Meta Description Template', 'seo-pro' ); ?></label></th>
                                    <td>
                                        <textarea name="description_<?php echo esc_attr( $post_type->name ); ?>" 
                                                  rows="3" 
                                                  class="large-text"
                                                  placeholder="%excerpt%"><?php echo esc_textarea( $desc_template ); ?></textarea>
                                        <p class="description">
                                            <?php _e( 'Available variables:', 'seo-pro' ); ?>
                                            <code>%excerpt%</code>
                                            <code>%title%</code>
                                            <code>%sitename%</code>
                                            <code>%author%</code>
                                            <code>%date%</code>
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Taxonomies -->
                <div class="seo-card">
                    <h2><?php _e( '🏷️ Taxonomies (Categories, Tags, Locations)', 'seo-pro' ); ?></h2>
                    
                    <?php
                    $taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );
                    
                    foreach ( $taxonomies as $taxonomy ) :
                        $title_template = get_option( "seo_pro_title_tax_{$taxonomy->name}", '%term% %sep% %sitename%' );
                        $desc_template = get_option( "seo_pro_description_tax_{$taxonomy->name}", '%term_description%' );
                    ?>
                        <div class="template-section">
                            <h3><?php echo esc_html( $taxonomy->labels->name ); ?> (<?php echo esc_html( $taxonomy->name ); ?>)</h3>
                            
                            <table class="form-table">
                                <tr>
                                    <th><label><?php _e( 'Title Template', 'seo-pro' ); ?></label></th>
                                    <td>
                                        <input type="text" 
                                               name="title_tax_<?php echo esc_attr( $taxonomy->name ); ?>" 
                                               value="<?php echo esc_attr( $title_template ); ?>" 
                                               class="large-text"
                                               placeholder="%term% %sep% %sitename%">
                                        <p class="description">
                                            <?php _e( 'Available variables:', 'seo-pro' ); ?>
                                            <code>%term%</code>
                                            <code>%sep%</code>
                                            <code>%sitename%</code>
                                            <code>%term_description%</code>
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label><?php _e( 'Meta Description Template', 'seo-pro' ); ?></label></th>
                                    <td>
                                        <textarea name="description_tax_<?php echo esc_attr( $taxonomy->name ); ?>" 
                                                  rows="3" 
                                                  class="large-text"
                                                  placeholder="%term_description%"><?php echo esc_textarea( $desc_template ); ?></textarea>
                                        <p class="description">
                                            <?php _e( 'Available variables:', 'seo-pro' ); ?>
                                            <code>%term_description%</code>
                                            <code>%term%</code>
                                            <code>%sitename%</code>
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Archives -->
                <div class="seo-card">
                    <h2><?php _e( '📚 Archives', 'seo-pro' ); ?></h2>
                    
                    <?php
                    $archives = array(
                        'author' => __( 'Author Archives', 'seo-pro' ),
                        'date' => __( 'Date Archives', 'seo-pro' ),
                        'search' => __( 'Search Results', 'seo-pro' ),
                        '404' => __( '404 Error Page', 'seo-pro' ),
                    );
                    
                    foreach ( $archives as $archive_type => $archive_label ) :
                        $title_template = get_option( "seo_pro_title_archive_{$archive_type}", $this->get_default_archive_title( $archive_type ) );
                        $desc_template = get_option( "seo_pro_description_archive_{$archive_type}", $this->get_default_archive_desc( $archive_type ) );
                    ?>
                        <div class="template-section">
                            <h3><?php echo esc_html( $archive_label ); ?></h3>
                            
                            <table class="form-table">
                                <tr>
                                    <th><label><?php _e( 'Title Template', 'seo-pro' ); ?></label></th>
                                    <td>
                                        <input type="text" 
                                               name="title_archive_<?php echo esc_attr( $archive_type ); ?>" 
                                               value="<?php echo esc_attr( $title_template ); ?>" 
                                               class="large-text">
                                        <p class="description">
                                            <?php
                                            if ( $archive_type === 'author' ) {
                                                _e( 'Available: ', 'seo-pro' );
                                                echo '<code>%author%</code> <code>%sep%</code> <code>%sitename%</code>';
                                            } elseif ( $archive_type === 'date' ) {
                                                _e( 'Available: ', 'seo-pro' );
                                                echo '<code>%date%</code> <code>%sep%</code> <code>%sitename%</code>';
                                            } elseif ( $archive_type === 'search' ) {
                                                _e( 'Available: ', 'seo-pro' );
                                                echo '<code>%search%</code> <code>%sep%</code> <code>%sitename%</code>';
                                            }
                                            ?>
                                        </p>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label><?php _e( 'Meta Description Template', 'seo-pro' ); ?></label></th>
                                    <td>
                                        <textarea name="description_archive_<?php echo esc_attr( $archive_type ); ?>" 
                                                  rows="3" 
                                                  class="large-text"><?php echo esc_textarea( $desc_template ); ?></textarea>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Homepage -->
                <div class="seo-card">
                    <h2><?php _e( '🏠 Homepage', 'seo-pro' ); ?></h2>
                    
                    <?php
                    $home_title = get_option( 'seo_pro_title_home', '%sitename% %sep% %sitedesc%' );
                    $home_desc = get_option( 'seo_pro_description_home', '%sitedesc%' );
                    ?>
                    
                    <table class="form-table">
                        <tr>
                            <th><label><?php _e( 'Homepage Title', 'seo-pro' ); ?></label></th>
                            <td>
                                <input type="text" 
                                       name="title_home" 
                                       value="<?php echo esc_attr( $home_title ); ?>" 
                                       class="large-text">
                                <p class="description">
                                    <?php _e( 'Available variables:', 'seo-pro' ); ?>
                                    <code>%sitename%</code>
                                    <code>%sitedesc%</code>
                                    <code>%sep%</code>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th><label><?php _e( 'Homepage Meta Description', 'seo-pro' ); ?></label></th>
                            <td>
                                <textarea name="description_home" 
                                          rows="3" 
                                          class="large-text"><?php echo esc_textarea( $home_desc ); ?></textarea>
                                <p class="description">
                                    <?php _e( 'Available variables:', 'seo-pro' ); ?>
                                    <code>%sitename%</code>
                                    <code>%sitedesc%</code>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Variable Reference -->
                <div class="seo-card">
                    <h2><?php _e( '📖 Variable Reference', 'seo-pro' ); ?></h2>
                    
                    <div class="variables-grid">
                        <div class="variable-item">
                            <code>%title%</code>
                            <p><?php _e( 'Post/Page title', 'seo-pro' ); ?></p>
                        </div>
                        <div class="variable-item">
                            <code>%sep%</code>
                            <p><?php _e( 'Separator (from General Settings)', 'seo-pro' ); ?></p>
                        </div>
                        <div class="variable-item">
                            <code>%sitename%</code>
                            <p><?php _e( 'Site name', 'seo-pro' ); ?></p>
                        </div>
                        <div class="variable-item">
                            <code>%sitedesc%</code>
                            <p><?php _e( 'Site tagline/description', 'seo-pro' ); ?></p>
                        </div>
                        <div class="variable-item">
                            <code>%excerpt%</code>
                            <p><?php _e( 'Post excerpt', 'seo-pro' ); ?></p>
                        </div>
                        <div class="variable-item">
                            <code>%author%</code>
                            <p><?php _e( 'Author name', 'seo-pro' ); ?></p>
                        </div>
                        <div class="variable-item">
                            <code>%date%</code>
                            <p><?php _e( 'Publication date', 'seo-pro' ); ?></p>
                        </div>
                        <div class="variable-item">
                            <code>%year%</code>
                            <p><?php _e( 'Current year', 'seo-pro' ); ?></p>
                        </div>
                        <div class="variable-item">
                            <code>%term%</code>
                            <p><?php _e( 'Term name (category/tag/location)', 'seo-pro' ); ?></p>
                        </div>
                        <div class="variable-item">
                            <code>%term_description%</code>
                            <p><?php _e( 'Term description', 'seo-pro' ); ?></p>
                        </div>
                        <div class="variable-item">
                            <code>%search%</code>
                            <p><?php _e( 'Search query', 'seo-pro' ); ?></p>
                        </div>
                    </div>
                </div>
                
                <p>
                    <button type="submit" name="save_titles_meta" class="button button-primary button-large">
                        <?php _e( 'Save Titles & Meta Settings', 'seo-pro' ); ?>
                    </button>
                </p>
            </form>
        </div>
        
        <style>
            .template-section {
                background: #f9f9f9;
                padding: 20px;
                margin-bottom: 20px;
                border-radius: 6px;
                border-left: 4px solid #2271b1;
            }
            .template-section h3 {
                margin-top: 0;
                color: #2271b1;
            }
            .template-section .form-table {
                margin-top: 15px;
            }
            .template-section code {
                background: #fff;
                padding: 2px 6px;
                border-radius: 3px;
                font-size: 12px;
                color: #d63638;
                margin: 0 3px;
            }
            .variables-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 15px;
                margin-top: 20px;
            }
            .variable-item {
                background: #f9f9f9;
                padding: 12px;
                border-radius: 4px;
                border-left: 3px solid #00a32a;
            }
            .variable-item code {
                display: block;
                background: #fff;
                padding: 6px 10px;
                border-radius: 3px;
                font-size: 13px;
                font-weight: 600;
                color: #d63638;
                margin-bottom: 5px;
            }
            .variable-item p {
                margin: 0;
                font-size: 12px;
                color: #666;
            }
        </style>
        <?php
    }
    
    /**
     * Save Titles & Meta settings
     */
    private function save_titles_meta_settings() {
        // Save post type templates
        $post_types = get_post_types( array( 'public' => true ), 'names' );
        foreach ( $post_types as $post_type ) {
            if ( isset( $_POST["title_{$post_type}"] ) ) {
                update_option( "seo_pro_title_{$post_type}", sanitize_text_field( $_POST["title_{$post_type}"] ) );
            }
            if ( isset( $_POST["description_{$post_type}"] ) ) {
                update_option( "seo_pro_description_{$post_type}", sanitize_textarea_field( $_POST["description_{$post_type}"] ) );
            }
        }
        
        // Save taxonomy templates
        $taxonomies = get_taxonomies( array( 'public' => true ), 'names' );
        foreach ( $taxonomies as $taxonomy ) {
            if ( isset( $_POST["title_tax_{$taxonomy}"] ) ) {
                update_option( "seo_pro_title_tax_{$taxonomy}", sanitize_text_field( $_POST["title_tax_{$taxonomy}"] ) );
            }
            if ( isset( $_POST["description_tax_{$taxonomy}"] ) ) {
                update_option( "seo_pro_description_tax_{$taxonomy}", sanitize_textarea_field( $_POST["description_tax_{$taxonomy}"] ) );
            }
        }
        
        // Save archive templates
        $archives = array( 'author', 'date', 'search', '404' );
        foreach ( $archives as $archive ) {
            if ( isset( $_POST["title_archive_{$archive}"] ) ) {
                update_option( "seo_pro_title_archive_{$archive}", sanitize_text_field( $_POST["title_archive_{$archive}"] ) );
            }
            if ( isset( $_POST["description_archive_{$archive}"] ) ) {
                update_option( "seo_pro_description_archive_{$archive}", sanitize_textarea_field( $_POST["description_archive_{$archive}"] ) );
            }
        }
        
        // Save homepage
        if ( isset( $_POST['title_home'] ) ) {
            update_option( 'seo_pro_title_home', sanitize_text_field( $_POST['title_home'] ) );
        }
        if ( isset( $_POST['description_home'] ) ) {
            update_option( 'seo_pro_description_home', sanitize_textarea_field( $_POST['description_home'] ) );
        }
    }
    
    /**
     * Apply title template
     */
    public function apply_document_title( $title_parts ) {
        $new_title = $this->get_title_for_current_page();
        
        if ( $new_title ) {
            return array( 'title' => $new_title );
        }
        
        return $title_parts;
    }
    
    /**
     * Get title for current page
     */
    private function get_title_for_current_page() {
        global $post;
        
        // Check for custom title first
        if ( is_singular() && $post ) {
            $custom_title = get_post_meta( $post->ID, '_seo_pro_title', true );
            if ( $custom_title ) {
                return $custom_title;
            }
        }
        
        // Homepage
        if ( is_front_page() || is_home() ) {
            $template = get_option( 'seo_pro_title_home', '%sitename% %sep% %sitedesc%' );
            return $this->replace_variables( $template );
        }
        
        // Singular
        if ( is_singular() ) {
            $post_type = get_post_type();
            $template = get_option( "seo_pro_title_{$post_type}", '%title% %sep% %sitename%' );
            return $this->replace_variables( $template, $post );
        }
        
        // Taxonomy
        if ( is_tax() || is_category() || is_tag() ) {
            $term = get_queried_object();
            $taxonomy = $term->taxonomy;
            $template = get_option( "seo_pro_title_tax_{$taxonomy}", '%term% %sep% %sitename%' );
            return $this->replace_variables( $template, null, $term );
        }
        
        // Author
        if ( is_author() ) {
            $template = get_option( 'seo_pro_title_archive_author', '%author% %sep% %sitename%' );
            return $this->replace_variables( $template );
        }
        
        // Date
        if ( is_date() ) {
            $template = get_option( 'seo_pro_title_archive_date', '%date% %sep% %sitename%' );
            return $this->replace_variables( $template );
        }
        
        // Search
        if ( is_search() ) {
            $template = get_option( 'seo_pro_title_archive_search', 'Search Results for %search% %sep% %sitename%' );
            return $this->replace_variables( $template );
        }
        
        // 404
        if ( is_404() ) {
            $template = get_option( 'seo_pro_title_archive_404', '404 Not Found %sep% %sitename%' );
            return $this->replace_variables( $template );
        }
        
        return null;
    }
    
    /**
     * Apply meta description
     */
    public function apply_meta_description() {
        // Don't output if SEO Manager already handled it
        if ( did_action( 'seo_pro_meta_description_output' ) ) {
            return;
        }
        
        $description = $this->get_description_for_current_page();
        
        if ( $description ) {
            // Strip HTML tags and trim
            $description = wp_strip_all_tags( $description );
            $description = trim( $description );
            
            // Limit to 160 characters
            if ( strlen( $description ) > 160 ) {
                $description = substr( $description, 0, 157 ) . '...';
            }
            
            echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
            
            // Mark that we've output the description
            do_action( 'seo_pro_meta_description_output' );
        }
    }
    
    /**
     * Get description for current page
     */
    private function get_description_for_current_page() {
        global $post;
        
        // Check for custom description first
        if ( is_singular() && $post ) {
            $custom_desc = get_post_meta( $post->ID, '_seo_pro_description', true );
            if ( $custom_desc ) {
                return $custom_desc;
            }
        }
        
        // Homepage
        if ( is_front_page() || is_home() ) {
            $template = get_option( 'seo_pro_description_home', '%sitedesc%' );
            return $this->replace_variables( $template );
        }
        
        // Singular
        if ( is_singular() ) {
            $post_type = get_post_type();
            $template = get_option( "seo_pro_description_{$post_type}", '%excerpt%' );
            return $this->replace_variables( $template, $post );
        }
        
        // Taxonomy
        if ( is_tax() || is_category() || is_tag() ) {
            $term = get_queried_object();
            $taxonomy = $term->taxonomy;
            $template = get_option( "seo_pro_description_tax_{$taxonomy}", '%term_description%' );
            return $this->replace_variables( $template, null, $term );
        }
        
        return null;
    }
    
    /**
     * Replace variables in template
     */
    private function replace_variables( $template, $post = null, $term = null ) {
        global $wp_query;
        
        $separator = get_option( 'seo_pro_title_separator', '|' );
        
        $replacements = array(
            '%sep%' => ' ' . $separator . ' ',
            '%sitename%' => get_bloginfo( 'name' ),
            '%sitedesc%' => get_bloginfo( 'description' ),
            '%year%' => date( 'Y' ),
        );
        
        // Post-specific variables
        if ( $post ) {
            $replacements['%title%'] = get_the_title( $post );
            
            // Get excerpt
            $excerpt = get_the_excerpt( $post );
            if ( empty( $excerpt ) ) {
                $excerpt = wp_trim_words( wp_strip_all_tags( $post->post_content ), 30 );
            }
            $replacements['%excerpt%'] = $excerpt;
            
            $replacements['%author%'] = get_the_author_meta( 'display_name', $post->post_author );
            $replacements['%date%'] = get_the_date( '', $post );
        }
        
        // Term-specific variables
        if ( $term ) {
            $replacements['%term%'] = $term->name;
            
            // Get term description and strip HTML
            $term_desc = term_description( $term->term_id, $term->taxonomy );
            $term_desc = wp_strip_all_tags( $term_desc );
            $term_desc = trim( $term_desc );
            
            $replacements['%term_description%'] = $term_desc;
        }
        
        // Author archive
        if ( is_author() ) {
            $author = get_queried_object();
            $replacements['%author%'] = $author->display_name;
        }
        
        // Date archive
        if ( is_date() ) {
            $date_title = get_the_archive_title();
            $date_title = str_replace( 'Archives: ', '', $date_title );
            $replacements['%date%'] = $date_title;
        }
        
        // Search
        if ( is_search() ) {
            $replacements['%search%'] = get_search_query();
        }
        
        // Replace variables
        $output = str_replace( array_keys( $replacements ), array_values( $replacements ), $template );
        
        // Clean up multiple separators
        $output = preg_replace( '/\s*' . preg_quote( $separator, '/' ) . '\s*' . preg_quote( $separator, '/' ) . '\s*/', ' ' . $separator . ' ', $output );
        
        // Trim
        $output = trim( $output );
        
        return $output;
    }
    
    /**
     * Get default archive title
     */
    private function get_default_archive_title( $type ) {
        $defaults = array(
            'author' => '%author% %sep% %sitename%',
            'date' => '%date% %sep% %sitename%',
            'search' => 'Search Results for %search% %sep% %sitename%',
            '404' => '404 Not Found %sep% %sitename%',
        );
        
        return isset( $defaults[ $type ] ) ? $defaults[ $type ] : '';
    }
    
    /**
     * Get default archive description
     */
    private function get_default_archive_desc( $type ) {
        $defaults = array(
            'author' => 'All posts by %author%',
            'date' => 'Posts from %date%',
            'search' => 'Search results for: %search%',
            '404' => 'The page you are looking for does not exist.',
        );
        
        return isset( $defaults[ $type ] ) ? $defaults[ $type ] : '';
    }
}
