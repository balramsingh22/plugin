<?php
/**
 * SEO Noindex Manager - Advanced Noindex Controls
 *
 * @package SEO_Pro
 * @since 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Noindex_Manager {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add Noindex settings menu
        add_action( 'admin_menu', array( $this, 'add_noindex_menu' ), 25 );
        
        // Apply noindex rules
        add_filter( 'wp_robots', array( $this, 'apply_noindex_rules' ), 999 );
        
        // Add meta robots tag
        add_action( 'wp_head', array( $this, 'output_robots_meta' ), 1 );
    }
    
    /**
     * Add Noindex menu
     */
    public function add_noindex_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'Noindex Settings', 'seo-pro' ),
            __( '🚫 Noindex', 'seo-pro' ),
            'manage_options',
            'seo-pro-noindex',
            array( $this, 'render_noindex_page' )
        );
    }
    
    /**
     * Apply noindex rules
     */
    public function apply_noindex_rules( $robots ) {
        // Noindex Search Results
        if ( get_option( 'seo_pro_noindex_search', 1 ) && is_search() ) {
            $robots['noindex'] = true;
            $robots['nofollow'] = true;
        }
        
        // Noindex Subpages (page/2, page/3, etc.)
        if ( get_option( 'seo_pro_noindex_subpages', 1 ) && is_paged() ) {
            $robots['noindex'] = true;
        }
        
        // Noindex Paginated Single Pages
        if ( get_option( 'seo_pro_noindex_paginated_single', 1 ) && is_singular() ) {
            global $page;
            if ( $page > 1 ) {
                $robots['noindex'] = true;
            }
        }
        
        // Noindex Password Protected Pages
        if ( get_option( 'seo_pro_noindex_password_protected', 1 ) && is_singular() && post_password_required() ) {
            $robots['noindex'] = true;
            $robots['nofollow'] = true;
        }
        
        // Noindex Author Archives
        if ( get_option( 'seo_pro_noindex_author_archives', 0 ) && is_author() ) {
            $robots['noindex'] = true;
        }
        
        // Noindex Date Archives
        if ( get_option( 'seo_pro_noindex_date_archives', 0 ) && is_date() ) {
            $robots['noindex'] = true;
        }
        
        // Noindex Tag Archives
        if ( get_option( 'seo_pro_noindex_tag_archives', 0 ) && is_tag() ) {
            $robots['noindex'] = true;
        }
        
        // Noindex Category Archives (optional)
        if ( get_option( 'seo_pro_noindex_category_archives', 0 ) && is_category() ) {
            $robots['noindex'] = true;
        }
        
        // Noindex Attachment Pages
        if ( get_option( 'seo_pro_noindex_attachments', 1 ) && is_attachment() ) {
            $robots['noindex'] = true;
            $robots['nofollow'] = true;
        }
        
        // Noindex 404 Pages
        if ( get_option( 'seo_pro_noindex_404', 1 ) && is_404() ) {
            $robots['noindex'] = true;
            $robots['nofollow'] = true;
        }
        
        return $robots;
    }
    
    /**
     * Output robots meta tag
     */
    public function output_robots_meta() {
        if ( is_admin() ) {
            return;
        }
        
        $robots = array();
        
        // Check per-post noindex setting
        if ( is_singular() ) {
            $post_id = get_the_ID();
            $noindex = get_post_meta( $post_id, '_seo_pro_noindex', true );
            $nofollow = get_post_meta( $post_id, '_seo_pro_nofollow', true );
            
            if ( $noindex ) {
                $robots[] = 'noindex';
            }
            if ( $nofollow ) {
                $robots[] = 'nofollow';
            }
        }
        
        // Apply global rules
        $wp_robots = apply_filters( 'wp_robots', array() );
        
        if ( ! empty( $wp_robots['noindex'] ) ) {
            $robots[] = 'noindex';
        }
        if ( ! empty( $wp_robots['nofollow'] ) ) {
            $robots[] = 'nofollow';
        }
        
        // Output meta tag
        if ( ! empty( $robots ) ) {
            $robots = array_unique( $robots );
            echo '<meta name="robots" content="' . esc_attr( implode( ', ', $robots ) ) . '">' . "\n";
        } else {
            // Default: index, follow
            echo '<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">' . "\n";
        }
    }
    
    /**
     * Render Noindex settings page
     */
    public function render_noindex_page() {
        // Save settings
        if ( isset( $_POST['seo_pro_noindex_nonce'] ) && wp_verify_nonce( $_POST['seo_pro_noindex_nonce'], 'seo_pro_noindex_save' ) ) {
            // Search Results
            update_option( 'seo_pro_noindex_search', isset( $_POST['seo_pro_noindex_search'] ) ? 1 : 0 );
            
            // Subpages
            update_option( 'seo_pro_noindex_subpages', isset( $_POST['seo_pro_noindex_subpages'] ) ? 1 : 0 );
            
            // Paginated Single Pages
            update_option( 'seo_pro_noindex_paginated_single', isset( $_POST['seo_pro_noindex_paginated_single'] ) ? 1 : 0 );
            
            // Password Protected
            update_option( 'seo_pro_noindex_password_protected', isset( $_POST['seo_pro_noindex_password_protected'] ) ? 1 : 0 );
            
            // Author Archives
            update_option( 'seo_pro_noindex_author_archives', isset( $_POST['seo_pro_noindex_author_archives'] ) ? 1 : 0 );
            
            // Date Archives
            update_option( 'seo_pro_noindex_date_archives', isset( $_POST['seo_pro_noindex_date_archives'] ) ? 1 : 0 );
            
            // Tag Archives
            update_option( 'seo_pro_noindex_tag_archives', isset( $_POST['seo_pro_noindex_tag_archives'] ) ? 1 : 0 );
            
            // Category Archives
            update_option( 'seo_pro_noindex_category_archives', isset( $_POST['seo_pro_noindex_category_archives'] ) ? 1 : 0 );
            
            // Attachments
            update_option( 'seo_pro_noindex_attachments', isset( $_POST['seo_pro_noindex_attachments'] ) ? 1 : 0 );
            
            // 404 Pages
            update_option( 'seo_pro_noindex_404', isset( $_POST['seo_pro_noindex_404'] ) ? 1 : 0 );
            
            echo '<div class="notice notice-success"><p><strong>✅ Noindex settings saved successfully!</strong></p></div>';
        }
        
        // Get current settings
        $noindex_search = get_option( 'seo_pro_noindex_search', 1 );
        $noindex_subpages = get_option( 'seo_pro_noindex_subpages', 1 );
        $noindex_paginated_single = get_option( 'seo_pro_noindex_paginated_single', 1 );
        $noindex_password_protected = get_option( 'seo_pro_noindex_password_protected', 1 );
        $noindex_author_archives = get_option( 'seo_pro_noindex_author_archives', 0 );
        $noindex_date_archives = get_option( 'seo_pro_noindex_date_archives', 0 );
        $noindex_tag_archives = get_option( 'seo_pro_noindex_tag_archives', 0 );
        $noindex_category_archives = get_option( 'seo_pro_noindex_category_archives', 0 );
        $noindex_attachments = get_option( 'seo_pro_noindex_attachments', 1 );
        $noindex_404 = get_option( 'seo_pro_noindex_404', 1 );
        ?>
        
        <div class="wrap">
            <h1>🚫 Noindex Settings - SEO Pro</h1>
            <p class="description">Control which pages should be excluded from search engines. Recommended settings are enabled by default.</p>
            
            <form method="post" action="">
                <?php wp_nonce_field( 'seo_pro_noindex_save', 'seo_pro_noindex_nonce' ); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_noindex_search">🔍 Noindex Search Results</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_noindex_search" id="seo_pro_noindex_search" value="1" <?php checked( $noindex_search, 1 ); ?>>
                                Prevents search result pages from being indexed
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Search result pages create duplicate content issues.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_noindex_subpages">📄 Noindex Subpages</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_noindex_subpages" id="seo_pro_noindex_subpages" value="1" <?php checked( $noindex_subpages, 1 ); ?>>
                                Prevents subpages (page/2, page/3, etc.) from being indexed
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Pagination pages can dilute your SEO value.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_noindex_paginated_single">📖 Noindex Paginated Single Pages</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_noindex_paginated_single" id="seo_pro_noindex_paginated_single" value="1" <?php checked( $noindex_paginated_single, 1 ); ?>>
                                Prevents paginated single post pages from being indexed
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Multi-page posts should only index the first page.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_noindex_password_protected">🔒 Noindex Password Protected Pages</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_noindex_password_protected" id="seo_pro_noindex_password_protected" value="1" <?php checked( $noindex_password_protected, 1 ); ?>>
                                Prevents password protected pages from being indexed
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Private content shouldn't appear in search results.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_noindex_attachments">📎 Noindex Attachment Pages</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_noindex_attachments" id="seo_pro_noindex_attachments" value="1" <?php checked( $noindex_attachments, 1 ); ?>>
                                Prevents attachment pages from being indexed
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> Image/media attachment pages are thin content.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_noindex_404">❌ Noindex 404 Pages</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_noindex_404" id="seo_pro_noindex_404" value="1" <?php checked( $noindex_404, 1 ); ?>>
                                Prevents 404 error pages from being indexed
                            </label>
                            <p class="description">✅ <strong>Recommended:</strong> 404 pages should never be indexed.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_noindex_author_archives">👤 Noindex Author Archives</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_noindex_author_archives" id="seo_pro_noindex_author_archives" value="1" <?php checked( $noindex_author_archives, 1 ); ?>>
                                Prevents author archive pages from being indexed
                            </label>
                            <p class="description">⚠️ <strong>Optional:</strong> Enable if you have single author or duplicate content issues.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_noindex_date_archives">📅 Noindex Date Archives</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_noindex_date_archives" id="seo_pro_noindex_date_archives" value="1" <?php checked( $noindex_date_archives, 1 ); ?>>
                                Prevents date archive pages from being indexed
                            </label>
                            <p class="description">⚠️ <strong>Optional:</strong> Enable if date archives aren't important for your site.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_noindex_tag_archives">🏷️ Noindex Tag Archives</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_noindex_tag_archives" id="seo_pro_noindex_tag_archives" value="1" <?php checked( $noindex_tag_archives, 1 ); ?>>
                                Prevents tag archive pages from being indexed
                            </label>
                            <p class="description">⚠️ <strong>Optional:</strong> Enable if tags create thin content issues.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="seo_pro_noindex_category_archives">📁 Noindex Category Archives</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="seo_pro_noindex_category_archives" id="seo_pro_noindex_category_archives" value="1" <?php checked( $noindex_category_archives, 1 ); ?>>
                                Prevents category archive pages from being indexed
                            </label>
                            <p class="description">⚠️ <strong>Not Recommended:</strong> Categories usually provide SEO value. Only enable if necessary.</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="💾 Save Noindex Settings">
                </p>
            </form>
            
            <hr>
            
            <div class="seo-pro-info-box" style="background: #f0f6fc; border-left: 4px solid #0073aa; padding: 15px; margin-top: 20px;">
                <h3>💡 Pro Tips for Noindex Settings</h3>
                <ul style="margin-left: 20px;">
                    <li><strong>✅ Always Enable:</strong> Search results, subpages, password protected, attachments, 404 pages</li>
                    <li><strong>⚠️ Consider Your Site:</strong> Author archives (single author sites), date archives (evergreen content)</li>
                    <li><strong>❌ Usually Keep Indexed:</strong> Categories (unless thin content), important tag pages</li>
                    <li><strong>🔍 Test Changes:</strong> Use Google Search Console to monitor indexing after changes</li>
                    <li><strong>📊 Monitor Traffic:</strong> Check analytics to ensure important pages aren't accidentally noindexed</li>
                </ul>
            </div>
            
            <div class="seo-pro-info-box" style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin-top: 20px;">
                <h3>🎯 Per-Post Noindex Control</h3>
                <p>You can also control noindex/nofollow for individual posts/pages using the <strong>SEO Pro Settings</strong> metabox when editing content.</p>
                <p>This gives you granular control over which specific pages should be excluded from search engines.</p>
            </div>
        </div>
        
        <?php
    }
}

// Initialize
SEO_Pro_Noindex_Manager::instance();
