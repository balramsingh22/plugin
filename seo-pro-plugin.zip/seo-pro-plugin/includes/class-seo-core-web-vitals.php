<?php
/**
 * SEO Core Web Vitals - Performance optimizer for Google's Page Experience
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Core_Web_Vitals {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        // Add Core Web Vitals menu
        add_action( 'admin_menu', array( $this, 'add_cwv_menu' ), 50 );
        
        // Performance optimizations
        add_action( 'wp_enqueue_scripts', array( $this, 'optimize_performance' ), 999 );
        
        // Lazy load images
        add_filter( 'the_content', array( $this, 'lazy_load_images' ), 999 );
        
        // Preload critical resources
        add_action( 'wp_head', array( $this, 'preload_critical_resources' ), 1 );
        
        // Remove render-blocking resources
        add_filter( 'style_loader_tag', array( $this, 'defer_css' ), 10, 2 );
        add_filter( 'script_loader_tag', array( $this, 'defer_js' ), 10, 2 );
    }
    
    /**
     * Add Core Web Vitals menu
     */
    public function add_cwv_menu() {
        add_submenu_page(
            'seo-pro',
            __( 'Core Web Vitals', 'seo-pro' ),
            __( 'Web Vitals', 'seo-pro' ),
            'manage_options',
            'seo-pro-web-vitals',
            array( $this, 'render_cwv_page' )
        );
    }
    
    /**
     * Render Core Web Vitals page
     */
    public function render_cwv_page() {
        // Handle settings save
        if ( isset( $_POST['save_cwv_settings'] ) && check_admin_referer( 'seo_pro_cwv' ) ) {
            update_option( 'seo_pro_lazy_load', isset( $_POST['lazy_load'] ) ? 1 : 0 );
            update_option( 'seo_pro_defer_css', isset( $_POST['defer_css'] ) ? 1 : 0 );
            update_option( 'seo_pro_defer_js', isset( $_POST['defer_js'] ) ? 1 : 0 );
            update_option( 'seo_pro_preload_fonts', isset( $_POST['preload_fonts'] ) ? 1 : 0 );
            update_option( 'seo_pro_remove_query_strings', isset( $_POST['remove_query_strings'] ) ? 1 : 0 );
            update_option( 'seo_pro_disable_emojis', isset( $_POST['disable_emojis'] ) ? 1 : 0 );
            
            echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Core Web Vitals settings saved!', 'seo-pro' ) . '</p></div>';
        }
        
        $lazy_load = get_option( 'seo_pro_lazy_load', 1 );
        $defer_css = get_option( 'seo_pro_defer_css', 0 );
        $defer_js = get_option( 'seo_pro_defer_js', 0 );
        $preload_fonts = get_option( 'seo_pro_preload_fonts', 0 );
        $remove_query_strings = get_option( 'seo_pro_remove_query_strings', 0 );
        $disable_emojis = get_option( 'seo_pro_disable_emojis', 1 );
        
        ?>
        <div class="wrap seo-pro-wrap">
            <h1><?php _e( '⚡ Core Web Vitals Optimizer', 'seo-pro' ); ?></h1>
            <p><?php _e( 'Optimize your site for Google\'s Page Experience ranking factor', 'seo-pro' ); ?></p>
            
            <!-- Core Web Vitals Metrics -->
            <div class="cwv-metrics">
                <div class="metric-card lcp">
                    <div class="metric-icon">🎯</div>
                    <div class="metric-content">
                        <h3><?php _e( 'LCP', 'seo-pro' ); ?></h3>
                        <p class="metric-name"><?php _e( 'Largest Contentful Paint', 'seo-pro' ); ?></p>
                        <p class="metric-target"><?php _e( 'Target: < 2.5s', 'seo-pro' ); ?></p>
                    </div>
                </div>
                
                <div class="metric-card fid">
                    <div class="metric-icon">⚡</div>
                    <div class="metric-content">
                        <h3><?php _e( 'FID', 'seo-pro' ); ?></h3>
                        <p class="metric-name"><?php _e( 'First Input Delay', 'seo-pro' ); ?></p>
                        <p class="metric-target"><?php _e( 'Target: < 100ms', 'seo-pro' ); ?></p>
                    </div>
                </div>
                
                <div class="metric-card cls">
                    <div class="metric-icon">📐</div>
                    <div class="metric-content">
                        <h3><?php _e( 'CLS', 'seo-pro' ); ?></h3>
                        <p class="metric-name"><?php _e( 'Cumulative Layout Shift', 'seo-pro' ); ?></p>
                        <p class="metric-target"><?php _e( 'Target: < 0.1', 'seo-pro' ); ?></p>
                    </div>
                </div>
                
                <div class="metric-card inp">
                    <div class="metric-icon">🖱️</div>
                    <div class="metric-content">
                        <h3><?php _e( 'INP', 'seo-pro' ); ?></h3>
                        <p class="metric-name"><?php _e( 'Interaction to Next Paint', 'seo-pro' ); ?></p>
                        <p class="metric-target"><?php _e( 'Target: < 200ms', 'seo-pro' ); ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Optimization Settings -->
            <form method="post">
                <?php wp_nonce_field( 'seo_pro_cwv' ); ?>
                
                <div class="seo-card">
                    <h2><?php _e( 'Performance Optimizations', 'seo-pro' ); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th><?php _e( 'Lazy Load Images', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="lazy_load" value="1" <?php checked( $lazy_load, 1 ); ?>>
                                    <?php _e( 'Enable lazy loading for images (Improves LCP)', 'seo-pro' ); ?>
                                </label>
                                <p class="description"><?php _e( 'Images load only when they enter viewport', 'seo-pro' ); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Defer CSS', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="defer_css" value="1" <?php checked( $defer_css, 1 ); ?>>
                                    <?php _e( 'Defer non-critical CSS (Improves FID)', 'seo-pro' ); ?>
                                </label>
                                <p class="description"><?php _e( 'Load CSS asynchronously', 'seo-pro' ); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Defer JavaScript', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="defer_js" value="1" <?php checked( $defer_js, 1 ); ?>>
                                    <?php _e( 'Defer JavaScript execution (Improves FID)', 'seo-pro' ); ?>
                                </label>
                                <p class="description"><?php _e( 'Load JS after page content', 'seo-pro' ); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Preload Fonts', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="preload_fonts" value="1" <?php checked( $preload_fonts, 1 ); ?>>
                                    <?php _e( 'Preload critical fonts (Reduces CLS)', 'seo-pro' ); ?>
                                </label>
                                <p class="description"><?php _e( 'Prevents font loading shifts', 'seo-pro' ); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Remove Query Strings', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="remove_query_strings" value="1" <?php checked( $remove_query_strings, 1 ); ?>>
                                    <?php _e( 'Remove query strings from static resources', 'seo-pro' ); ?>
                                </label>
                                <p class="description"><?php _e( 'Improves caching', 'seo-pro' ); ?></p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th><?php _e( 'Disable Emojis', 'seo-pro' ); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="disable_emojis" value="1" <?php checked( $disable_emojis, 1 ); ?>>
                                    <?php _e( 'Disable WordPress emoji scripts', 'seo-pro' ); ?>
                                </label>
                                <p class="description"><?php _e( 'Reduces HTTP requests', 'seo-pro' ); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <p>
                        <button type="submit" name="save_cwv_settings" class="button button-primary button-large">
                            <?php _e( 'Save Performance Settings', 'seo-pro' ); ?>
                        </button>
                    </p>
                </div>
            </form>
            
            <!-- Optimization Tips -->
            <div class="seo-card">
                <h2><?php _e( '💡 Core Web Vitals Optimization Tips', 'seo-pro' ); ?></h2>
                
                <div class="tips-grid">
                    <div class="tip-box">
                        <h3><?php _e( 'Improve LCP', 'seo-pro' ); ?></h3>
                        <ul>
                            <li><?php _e( 'Optimize images (compress, WebP format)', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Use a CDN for faster delivery', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Minimize server response time', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Remove render-blocking resources', 'seo-pro' ); ?></li>
                        </ul>
                    </div>
                    
                    <div class="tip-box">
                        <h3><?php _e( 'Improve FID/INP', 'seo-pro' ); ?></h3>
                        <ul>
                            <li><?php _e( 'Minimize JavaScript execution', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Break up long tasks', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Use web workers for heavy tasks', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Optimize event handlers', 'seo-pro' ); ?></li>
                        </ul>
                    </div>
                    
                    <div class="tip-box">
                        <h3><?php _e( 'Improve CLS', 'seo-pro' ); ?></h3>
                        <ul>
                            <li><?php _e( 'Set image dimensions (width/height)', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Reserve space for ads/embeds', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Preload fonts to avoid FOIT', 'seo-pro' ); ?></li>
                            <li><?php _e( 'Avoid inserting content above existing', 'seo-pro' ); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Test Your Site -->
            <div class="seo-card">
                <h2><?php _e( '🧪 Test Your Site', 'seo-pro' ); ?></h2>
                <p><?php _e( 'Use these tools to measure your Core Web Vitals:', 'seo-pro' ); ?></p>
                
                <div class="test-tools">
                    <a href="https://pagespeed.web.dev/analysis?url=<?php echo urlencode( home_url() ); ?>" target="_blank" class="test-button">
                        <?php _e( '📊 PageSpeed Insights', 'seo-pro' ); ?>
                    </a>
                    <a href="https://search.google.com/search-console" target="_blank" class="test-button">
                        <?php _e( '🔍 Search Console', 'seo-pro' ); ?>
                    </a>
                    <a href="https://web.dev/measure/" target="_blank" class="test-button">
                        <?php _e( '⚡ Web.dev Measure', 'seo-pro' ); ?>
                    </a>
                </div>
            </div>
        </div>
        
        <style>
            .cwv-metrics {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            .metric-card {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                padding: 20px;
                border-radius: 8px;
                display: flex;
                align-items: center;
                gap: 15px;
            }
            .metric-card.lcp {
                background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            }
            .metric-card.fid {
                background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            }
            .metric-card.cls {
                background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            }
            .metric-card.inp {
                background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            }
            .metric-icon {
                font-size: 40px;
            }
            .metric-content h3 {
                margin: 0;
                font-size: 24px;
            }
            .metric-name {
                margin: 5px 0;
                font-size: 13px;
                opacity: 0.9;
            }
            .metric-target {
                margin: 0;
                font-size: 12px;
                font-weight: 600;
            }
            .tips-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }
            .tip-box {
                background: #f9f9f9;
                padding: 15px;
                border-radius: 6px;
                border-left: 4px solid #2271b1;
            }
            .tip-box h3 {
                margin-top: 0;
                color: #2271b1;
            }
            .tip-box ul {
                margin: 10px 0;
                padding-left: 20px;
            }
            .tip-box li {
                margin-bottom: 8px;
                line-height: 1.5;
            }
            .test-tools {
                display: flex;
                gap: 15px;
                margin-top: 15px;
                flex-wrap: wrap;
            }
            .test-button {
                display: inline-block;
                padding: 12px 24px;
                background: #2271b1;
                color: #fff;
                text-decoration: none;
                border-radius: 6px;
                font-weight: 600;
                transition: all 0.3s;
            }
            .test-button:hover {
                background: #135e96;
                transform: translateY(-2px);
            }
        </style>
        <?php
    }
    
    /**
     * Optimize performance
     */
    public function optimize_performance() {
        // Disable emojis
        if ( get_option( 'seo_pro_disable_emojis', 1 ) ) {
            remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
            remove_action( 'wp_print_styles', 'print_emoji_styles' );
        }
    }
    
    /**
     * Lazy load images
     */
    public function lazy_load_images( $content ) {
        if ( ! get_option( 'seo_pro_lazy_load', 1 ) || is_admin() || is_feed() ) {
            return $content;
        }
        
        // Add loading="lazy" to images
        $content = preg_replace( '/<img((?![^>]*loading=)[^>]*)>/i', '<img$1 loading="lazy">', $content );
        
        return $content;
    }
    
    /**
     * Preload critical resources
     */
    public function preload_critical_resources() {
        if ( get_option( 'seo_pro_preload_fonts', 0 ) ) {
            // Preload common Google Fonts
            echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
            echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
        }
    }
    
    /**
     * Defer CSS
     */
    public function defer_css( $html, $handle ) {
        if ( ! get_option( 'seo_pro_defer_css', 0 ) || is_admin() ) {
            return $html;
        }
        
        // Don't defer critical CSS
        $critical_handles = array( 'admin-bar', 'dashicons' );
        if ( in_array( $handle, $critical_handles ) ) {
            return $html;
        }
        
        $html = str_replace( "media='all'", "media='print' onload=\"this.media='all'\"", $html );
        
        return $html;
    }
    
    /**
     * Defer JavaScript
     */
    public function defer_js( $tag, $handle ) {
        if ( ! get_option( 'seo_pro_defer_js', 0 ) || is_admin() ) {
            return $tag;
        }
        
        // Don't defer jQuery and critical scripts
        $critical_handles = array( 'jquery', 'jquery-core', 'jquery-migrate' );
        if ( in_array( $handle, $critical_handles ) ) {
            return $tag;
        }
        
        return str_replace( ' src', ' defer src', $tag );
    }
}
