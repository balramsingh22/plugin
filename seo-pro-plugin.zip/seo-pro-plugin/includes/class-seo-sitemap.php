<?php
/**
 * SEO Sitemap - XML Sitemap generation
 *
 * @package SEO_Pro
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SEO_Pro_Sitemap {
    
    private static $instance = null;
    
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        add_action( 'init', array( $this, 'register_sitemap' ) );
        add_action( 'template_redirect', array( $this, 'generate_sitemap' ) );
    }
    
    /**
     * Register sitemap rewrite rules
     */
    public function register_sitemap() {
        add_rewrite_rule( '^sitemap\.xml$', 'index.php?seo_pro_sitemap=main', 'top' );
        add_rewrite_rule( '^sitemap-([^/]+)\.xml$', 'index.php?seo_pro_sitemap=$matches[1]', 'top' );
        
        add_filter( 'query_vars', function( $vars ) {
            $vars[] = 'seo_pro_sitemap';
            return $vars;
        });
    }
    
    /**
     * Generate sitemap
     */
    public function generate_sitemap() {
        $sitemap = get_query_var( 'seo_pro_sitemap' );
        
        if ( ! $sitemap ) {
            return;
        }
        
        header( 'Content-Type: application/xml; charset=utf-8' );
        header( 'X-Robots-Tag: noindex, follow', true );
        
        if ( $sitemap === 'main' ) {
            $this->generate_sitemap_index();
        } else {
            $this->generate_sitemap_content( $sitemap );
        }
        
        exit;
    }
    
    /**
     * Generate sitemap index
     */
    private function generate_sitemap_index() {
        echo '<?xml version="1.0" encoding="UTF-8"?>';
        echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
        
        $sitemaps = array( 'posts', 'pages' );
        
        // Add RTCL sitemaps if plugin is active
        if ( function_exists( 'rtcl' ) ) {
            $sitemaps[] = 'listings';
            $sitemaps[] = 'categories';
            $sitemaps[] = 'locations';
        }
        
        // Add News sitemap
        $sitemaps[] = 'news';
        
        // Add Video sitemap
        $sitemaps[] = 'video';
        
        foreach ( $sitemaps as $sitemap ) {
            echo '<sitemap>';
            echo '<loc>' . home_url( "/sitemap-{$sitemap}.xml" ) . '</loc>';
            echo '<lastmod>' . date( 'c' ) . '</lastmod>';
            echo '</sitemap>';
        }
        
        echo '</sitemapindex>';
    }
    
    /**
     * Generate sitemap content
     */
    private function generate_sitemap_content( $type ) {
        echo '<?xml version="1.0" encoding="UTF-8"?>';
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
        
        switch ( $type ) {
            case 'posts':
                $this->generate_posts_sitemap();
                break;
            case 'pages':
                $this->generate_pages_sitemap();
                break;
            case 'listings':
                $this->generate_listings_sitemap();
                break;
            case 'categories':
                $this->generate_categories_sitemap();
                break;
            case 'locations':
                $this->generate_locations_sitemap();
                break;
            case 'news':
                $this->generate_news_sitemap();
                break;
            case 'video':
                $this->generate_video_sitemap();
                break;
        }
        
        echo '</urlset>';
    }
    
    /**
     * Generate posts sitemap
     */
    private function generate_posts_sitemap() {
        $posts = get_posts( array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => -1, // UNLIMITED!
            'orderby' => 'modified',
            'order' => 'DESC',
            'no_found_rows' => true, // Performance optimization
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ) );
        
        foreach ( $posts as $post ) {
            $this->output_sitemap_url( 
                get_permalink( $post ), 
                get_the_modified_date( 'c', $post ), 
                'weekly', 
                '0.8' 
            );
        }
    }
    
    /**
     * Generate pages sitemap
     */
    private function generate_pages_sitemap() {
        $pages = get_posts( array(
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => -1, // UNLIMITED!
            'orderby' => 'modified',
            'order' => 'DESC',
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ) );
        
        foreach ( $pages as $page ) {
            $this->output_sitemap_url( 
                get_permalink( $page ), 
                get_the_modified_date( 'c', $page ), 
                'monthly', 
                '0.6' 
            );
        }
    }
    
    /**
     * Generate listings sitemap
     */
    private function generate_listings_sitemap() {
        if ( ! function_exists( 'rtcl' ) ) {
            return;
        }
        
        $listings = get_posts( array(
            'post_type' => 'rtcl_listing',
            'post_status' => 'publish',
            'posts_per_page' => -1, // UNLIMITED!
            'orderby' => 'modified',
            'order' => 'DESC',
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ) );
        
        foreach ( $listings as $listing ) {
            $this->output_sitemap_url( 
                get_permalink( $listing ), 
                get_the_modified_date( 'c', $listing ), 
                'daily', 
                '1.0' 
            );
        }
    }
    
    /**
     * Generate categories sitemap
     */
    private function generate_categories_sitemap() {
        if ( ! function_exists( 'rtcl' ) ) {
            return;
        }
        
        $categories = get_terms( array(
            'taxonomy' => 'rtcl_category',
            'hide_empty' => true,
        ) );
        
        foreach ( $categories as $category ) {
            $this->output_sitemap_url( 
                get_term_link( $category ), 
                date( 'c' ), 
                'weekly', 
                '0.7' 
            );
        }
    }
    
    /**
     * Generate locations sitemap
     */
    private function generate_locations_sitemap() {
        if ( ! function_exists( 'rtcl' ) ) {
            return;
        }
        
        $locations = get_terms( array(
            'taxonomy' => 'rtcl_location',
            'hide_empty' => true,
        ) );
        
        foreach ( $locations as $location ) {
            $this->output_sitemap_url( 
                get_term_link( $location ), 
                date( 'c' ), 
                'weekly', 
                '0.7' 
            );
        }
    }
    
    /**
     * Output sitemap URL
     */
    private function output_sitemap_url( $loc, $lastmod, $changefreq, $priority ) {
        echo '<url>';
        echo '<loc>' . esc_url( $loc ) . '</loc>';
        echo '<lastmod>' . esc_html( $lastmod ) . '</lastmod>';
        echo '<changefreq>' . esc_html( $changefreq ) . '</changefreq>';
        echo '<priority>' . esc_html( $priority ) . '</priority>';
        echo '</url>';
    }
    
    /**
     * Generate news sitemap (Google News)
     */
    private function generate_news_sitemap() {
        // Get posts from last 2 days (Google News requirement)
        $posts = get_posts( array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => -1, // UNLIMITED!
            'date_query' => array(
                array(
                    'after' => '2 days ago',
                ),
            ),
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
        ) );
        
        foreach ( $posts as $post ) {
            echo '<url>';
            echo '<loc>' . esc_url( get_permalink( $post ) ) . '</loc>';
            echo '<news:news>';
            echo '<news:publication>';
            echo '<news:name>' . esc_html( get_bloginfo( 'name' ) ) . '</news:name>';
            echo '<news:language>en</news:language>';
            echo '</news:publication>';
            echo '<news:publication_date>' . get_the_date( 'c', $post ) . '</news:publication_date>';
            echo '<news:title>' . esc_html( get_the_title( $post ) ) . '</news:title>';
            echo '</news:news>';
            echo '</url>';
        }
    }
    
    /**
     * Generate video sitemap
     */
    private function generate_video_sitemap() {
        // Get posts with video schema - UNLIMITED!
        global $wpdb;
        
        $posts_with_video = $wpdb->get_results( "
            SELECT p.ID, p.post_title, p.post_date, p.post_content
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE pm.meta_key = '_seo_pro_schema_type'
            AND pm.meta_value = 'video'
            AND p.post_status = 'publish'
            ORDER BY p.post_date DESC
        " );
        
        foreach ( $posts_with_video as $post ) {
            $video_url = get_post_meta( $post->ID, '_seo_pro_video_url', true );
            $thumbnail = get_the_post_thumbnail_url( $post->ID, 'full' );
            $description = wp_trim_words( wp_strip_all_tags( $post->post_content ), 30 );
            
            if ( ! $video_url ) {
                continue;
            }
            
            echo '<url>';
            echo '<loc>' . esc_url( get_permalink( $post->ID ) ) . '</loc>';
            echo '<video:video>';
            echo '<video:thumbnail_loc>' . esc_url( $thumbnail ) . '</video:thumbnail_loc>';
            echo '<video:title>' . esc_html( $post->post_title ) . '</video:title>';
            echo '<video:description>' . esc_html( $description ) . '</video:description>';
            echo '<video:content_loc>' . esc_url( $video_url ) . '</video:content_loc>';
            echo '<video:publication_date>' . date( 'c', strtotime( $post->post_date ) ) . '</video:publication_date>';
            echo '</video:video>';
            echo '</url>';
        }
    }
}
