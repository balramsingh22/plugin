<?php

namespace Rtcl\Abstracts;

abstract class Migration {

	public abstract static function migrate();
}