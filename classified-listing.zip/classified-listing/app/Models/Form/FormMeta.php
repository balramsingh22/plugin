<?php

namespace Rtcl\Models\Form;

use Rtcl\Database\Eloquent\Model;

class FormMeta extends Model {

	protected string $table = 'rtcl_form_meta';

	public function setAttributes() {
		// TODO: Implement setAttributes() method.
	}
}