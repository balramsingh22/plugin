<?php

namespace Rtcl\Traits\Hooks;

use Rtcl\Helpers\Functions;

trait TemplateHookTrait {

	
}