<?php

use Rtcl\Helpers\Functions;

?>
<div class="rtcl rtcl-widget-categories">
	<?php Functions::print_html( $categories ); ?>
</div>