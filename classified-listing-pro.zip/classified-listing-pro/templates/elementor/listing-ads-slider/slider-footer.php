
		
		</div>
		</div>  <!-- End wiper-wrapper -->
		<?php if ( $instance['slider_nav'] ) { ?>
			<!-- If we need navigation buttons -->
			<span class="rtcl-slider-btn button-left rtcl-icon-angle-left"></span>
			<span class="rtcl-slider-btn button-right rtcl-icon-angle-right"></span>
		
		<?php } ?>
		<?php if ( $instance['slider_dots'] ) { ?>
			<!-- If we need pagination -->
			<div class="rtcl-slider-pagination"></div>
		<?php } ?>
	</div>
</div>
