<?php
/**
 * Template Name: Listing Map
 *
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Classima;

get_header();
$map_listing_limit = apply_filters( 'classima_map_listing_limit', 8 );
?>
    <div id="primary" class="listing-map-content-area">
        <div class="container-fluid full-width">
            <div class="classima-listing-map-wrapper">
				<?php
				if ( get_the_content() ) {
					the_content();
				} else {
					echo do_shortcode( '[rtcl_listings map="1" paginate="true" limit="' . $map_listing_limit . '"]' );
				}
				?>
            </div>
        </div>
    </div>

	<?php get_footer();