<?php
/**
 * RTCL Load More - Simplified Logic (Like Author Page)
 * 
 * @package Classima
 * @version 2.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enqueue Scripts
 */
function rtcl_enqueue_load_more_scripts() {
    if (!is_post_type_archive('rtcl_listing') && !is_tax(get_object_taxonomies('rtcl_listing'))) {
        return;
    }

    wp_enqueue_script(
        'rtcl-load-more',
        get_template_directory_uri() . '/assets/js/rtcl-load-more.js',
        array('jquery'),
        '2.0.0',  // Changed version to bust cache
        true
    );

    global $wp_query;
    
    // Pass data to JS
    wp_localize_script('rtcl-load-more', 'rtcl_load_more_params', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('rtcl_load_more_nonce'),
        'page_text' => sprintf(__('Showing page %d of %d', 'classima'), '%d', '%d'),
        'all_loaded_text' => __('All listings loaded', 'classima'),
    ));
}
add_action('wp_enqueue_scripts', 'rtcl_enqueue_load_more_scripts');

/**
 * AJAX Handler - Simplified (Author Page Style)
 */
function rtcl_ajax_load_more_listings() {
    // Verify Nonce
    if (!check_ajax_referer('rtcl_load_more_nonce', 'nonce', false)) {
        wp_send_json_error(array('message' => 'Security check failed'));
    }

    $current_page   = isset($_POST['current_page']) ? absint($_POST['current_page']) : 0;
    $max_num_pages  = isset($_POST['max_num_pages']) ? absint($_POST['max_num_pages']) : 0;
    $posts_per_page = 5; // Fixed 5 ads per load
    
    // Get Filters from JS
    $location_slug = isset($_POST['location_slug']) ? sanitize_text_field($_POST['location_slug']) : '';
    $category_slug = isset($_POST['category_slug']) ? sanitize_text_field($_POST['category_slug']) : '';

    error_log("Load More: Received current_page=$current_page, max_num_pages=$max_num_pages, location=$location_slug, category=$category_slug");

    $complete = false;
    $html = '';

    if ($current_page && $max_num_pages && $max_num_pages > $current_page) {
        $current_page++; // Next Page
        
        error_log("Load More: Loading page $current_page");
        
        if ($current_page == $max_num_pages) {
            $complete = true;
        }

        $args = array(
            'post_type'      => 'rtcl_listing',
            'post_status'    => 'publish',
            'posts_per_page' => $posts_per_page,
            'paged'          => $current_page,
            'orderby'        => 'date',
            'order'          => 'DESC',
        );

        // Add Taxonomy Query
        $tax_query = array('relation' => 'AND');

        if (!empty($location_slug)) {
            $tax_query[] = array(
                'taxonomy' => 'rtcl_location',
                'field'    => 'slug',
                'terms'    => $location_slug,
            );
            error_log("Load More: Added location filter: $location_slug");
        }

        if (!empty($category_slug)) {
            $tax_query[] = array(
                'taxonomy' => 'rtcl_category',
                'field'    => 'slug',
                'terms'    => $category_slug,
            );
            error_log("Load More: Added category filter: $category_slug");
        }

        if (count($tax_query) > 1) {
            $args['tax_query'] = $tax_query;
        }

        // Run Query
        $listings_query = new WP_Query($args);
        
        error_log("Load More: Found " . $listings_query->post_count . " posts");

        if ($listings_query->have_posts()) {
            ob_start();
            while ($listings_query->have_posts()) {
                $listings_query->the_post();
                
                // Set up all required variables (matching list.php)
                $listing = rtcl()->factory->get_listing(get_the_ID());
                $listing_post = $listing->get_listing();
                $category = $listing->get_categories();
                $type = \radiustheme\Classima\Listing_Functions::get_listing_type($listing);
                
                $class  = ' rtcl-listing-item';
                $class .= $listing->is_featured() ? ' featured-listing' : '';
                
                $layout = isset(\radiustheme\Classima\RDTheme::$options['listing_list_style']) ? \radiustheme\Classima\RDTheme::$options['listing_list_style'] : 2;
                
                if (2 == $layout) {
                    $excerpt_limit = 25;
                } elseif (3 == $layout) {
                    $excerpt_limit = 20;
                } else {
                    $excerpt_limit = 12;
                }
                
                $display = array(
                    'cat'           => $listing->can_show_category(),
                    'excerpt'       => $listing->can_show_excerpt(),
                    'excerpt_limit' => $excerpt_limit,
                    'date'          => $listing->can_show_date(),
                    'user'          => $listing->can_show_user(),
                    'location'      => $listing->can_show_location(),
                    'views'         => $listing->can_show_views(),
                    'price'         => $listing->can_show_price(),
                    'fields'        => isset(\radiustheme\Classima\RDTheme::$options['listing_custom_fields']) ? \radiustheme\Classima\RDTheme::$options['listing_custom_fields'] : false,
                    'label'         => true,
                    'type'          => true,
                );
                
                if (!$category) {
                    $display['cat'] = false;
                }
                
                $map = false;
                $id = get_the_ID(); // For archive-list-2.php
                
                // Load Template
                $template_path = locate_template('classified-listing/custom/list-items/archive-list-' . $layout . '.php');
                if ($template_path) {
                    include($template_path);
                } else {
                    error_log("Load More: Template not found for layout $layout!");
                }
            }
            $html = ob_get_clean();
            error_log("Load More: Generated HTML length: " . strlen($html));
        } else {
            error_log("Load More: No posts found in query");
        }
        
        wp_reset_postdata();
    } else {
        $complete = true;
        error_log("Load More: Reached end of pagination");
    }

    wp_send_json_success(array(
        'complete'     => $complete,
        'current_page' => $current_page,
        'html'         => $html,
    ));
}

add_action('wp_ajax_rtcl_load_more_listings', 'rtcl_ajax_load_more_listings');
add_action('wp_ajax_nopriv_rtcl_load_more_listings', 'rtcl_ajax_load_more_listings');

/**
 * Add SEO Pagination Meta Tags (rel="prev" and rel="next")
 */
function rtcl_add_pagination_seo_tags() {
    if (!is_post_type_archive('rtcl_listing') && !is_tax(get_object_taxonomies('rtcl_listing'))) {
        return;
    }

    global $wp_query;
    $paged = get_query_var('paged') ? get_query_var('paged') : 1;
    $max_pages = $wp_query->max_num_pages;

    // Canonical URL (always point to page 1 for Load More pages)
    if ($paged == 1) {
        $canonical_url = get_pagenum_link(1);
        echo '<link rel="canonical" href="' . esc_url($canonical_url) . '" />' . "\n";
        
        // Add rel="next" if there are more pages
        if ($max_pages > 1) {
            echo '<link rel="next" href="' . esc_url(get_pagenum_link(2)) . '" />' . "\n";
        }
    }
}
add_action('wp_head', 'rtcl_add_pagination_seo_tags', 1);

