/**
 * RTCL Load More - Simplified (Author Page Style)
 */
(function ($) {
  'use strict';

  const LoadMore = {
    init: function () {
      this.button = $('#rtcl-load-more-btn');
      this.container = $('.rtcl-list-view, .rtcl-grid-view').first();

      if (!this.button.length) return;

      // Get Initial Data
      this.currentPage = parseInt(this.button.data('page')) || 1;
      this.maxPages = parseInt(this.button.data('max-pages')) || 1;

      // Detect Filters from URL (Robust Fallback)
      this.locationSlug = '';
      this.categorySlug = '';

      const pathSegments = window.location.pathname.split('/').filter(Boolean);
      if (pathSegments.length > 0) {
        // Heuristic: Last segment is usually location or category
        // Example: /call-girls/maharashtra/andheri/ -> andheri
        this.locationSlug = pathSegments[pathSegments.length - 1];

        // If URL has 'call-girls', that's the category
        if (window.location.pathname.includes('call-girls')) {
          this.categorySlug = 'call-girls';
        }
      }

      // Bind Click
      this.button.on('click', (e) => {
        e.preventDefault();
        this.loadListings();
      });
    },

    loadListings: function () {
      if (this.isLoading || this.currentPage >= this.maxPages) return;

      this.isLoading = true;
      this.button.addClass('loading').text('Loading...');

      $.ajax({
        url: rtcl_load_more_params.ajax_url,
        type: 'POST',
        dataType: 'json',
        data: {
          action: 'rtcl_load_more_listings',
          nonce: rtcl_load_more_params.nonce,
          current_page: this.currentPage,
          max_num_pages: this.maxPages,
          location_slug: this.locationSlug,
          category_slug: this.categorySlug
        },
        success: (response) => {
          console.log('AJAX Response:', response);

          // Check if we have data (response might have data wrapper)
          const data = response.data || response;

          if (data.html) {
            // Append Content
            const $content = $(data.html);
            $content.hide();
            this.container.append($content);
            $content.fadeIn();

            // Update State
            this.currentPage = data.current_page;
            this.button.data('page', this.currentPage);

            // Update Counter
            $('.rtcl-page-counter').text(
              rtcl_load_more_params.page_text
                .replace('%d', this.currentPage)
                .replace('%d', this.maxPages)
            );
          }

          // Hide Button if Complete
          if (data.complete || this.currentPage >= this.maxPages) {
            this.button.hide();
            $('.rtcl-load-more-wrapper').append(
              '<div class="alert alert-success">' + rtcl_load_more_params.all_loaded_text + '</div>'
            );
          }
        },
        error: (xhr, status, error) => {
          console.error('AJAX Error:', error);
          alert('Failed to load more listings. Please try again.');
        },
        complete: () => {
          this.isLoading = false;
          this.button.removeClass('loading').text('Load More Listings');
        }
      });
    }
  };

  $(document).ready(function () {
    LoadMore.init();
  });

})(jQuery);
