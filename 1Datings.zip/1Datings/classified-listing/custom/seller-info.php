<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.4
 */

namespace radiustheme\Classima;

use Rtcl\Models\Listing;
use Rtcl\Helpers\Link;
use Rtcl\Helpers\Functions;
use RtclPro\Helpers\Fns;
use RtclStore\Helpers\Functions as StoreFunctions;

$id           = get_the_id();
$listing      = new Listing( $id );
$listing_post = $listing->get_listing();
$email        = get_post_meta( $id, 'email', true );
$website      = get_post_meta( $id, 'website', true );
$phone        = get_post_meta( $id, 'phone', true );
$whatsapp     = get_post_meta( $id, '_rtcl_whatsapp_number', true );

$has_contact_form       = Functions::get_option_item( 'rtcl_moderation_settings', 'has_contact_form', false, 'checkbox' );
$alternate_contact_form = Functions::get_option_item( 'rtcl_moderation_settings', 'alternate_contact_form_shortcode' );

$store = false;
if ( class_exists( 'RtclStore' ) ) {
	$store = StoreFunctions::get_user_store( $listing_post->post_author );
}
?>
<div class="classified-seller-info widget">
    <h3 class="widgettitle"><?php esc_html_e( 'Seller Information', 'classima' ); ?></h3>
    <div class="rtin-box">

		<?php if ( $listing->can_show_user() ): ?>
            <div class="rtin-author">
				<?php if ( $store ): ?>
					<?php $store->the_logo(); ?>
                    <div class="rtin-author-info rtin-as-store">
                        <h4 class="rtin-name">
                            <a href="<?php $store->the_permalink(); ?>"><?php $store->the_title(); ?></a>
							<?php do_action( 'rtcl_after_author_meta', $listing->get_owner_id() ); ?>
                        </h4>
                        <div class="rtcl-author-badge">
							<?php do_action( 'rtcl_listing_author_badges', $listing ); ?>
                        </div>
                    </div>
				<?php else: ?>
                    <div class="rtin-author-info rtin-as-author">
                        <h4 class="rtin-name">
                            <a href="<?php echo esc_url( $listing->get_the_author_url() ); ?>"><?php $listing->the_author(); ?></a>
							<?php do_action( 'rtcl_after_author_meta', $listing->get_owner_id() ); ?>
                        </h4>
                    </div>
				<?php endif; ?>
            </div>
		<?php endif; ?>

		<?php if ( Fns::registered_user_only( 'listing_seller_information' ) && ! is_user_logged_in() ) {
			$redirect_to = add_query_arg( 'redirect_to', get_the_permalink(), Link::get_my_account_page_link() );
			?>
            <p class="login-message"><?php echo wp_kses( sprintf( __( "Please <a href='%s'>login</a> to view the seller information.", "classima" ),
					esc_url( $redirect_to ) ), [ 'a' => [ 'href' => [] ] ] ); ?></p>
		<?php } else { ?>

			<?php if ( $address = Listing_Functions::get_single_contact_address( $listing ) ): ?>
                <div class="rtin-location rtin-box-item clearfix">
                    <i class="fa fa-fw fa-map-marker" aria-hidden="true"></i>
                    <div class="rtin-box-item-text"><?php echo wp_kses_post( $address ); ?></div>
                </div>
			<?php endif; ?>

			<?php if ( $website ): ?>
                <div class="rtin-web rtin-box-item clearfix">
                    <i class="fa fa-fw fa-globe" aria-hidden="true"></i>
                    <a class="rtin-box-item-text" href="<?php echo esc_url( $website ); ?>" rel="nofollow" rel="noopener"
                       target="_blank">
						<?php esc_html_e( 'Visit Website', 'classima' ); ?>
                    </a>
                </div>
			<?php endif; ?>

			<?php if ( $store ): ?>
                <div class="rtin-store rtin-box-item clearfix">
                    <i class="fa fa-fw fa-shopping-basket" aria-hidden="true"></i>
                    <a class="rtin-box-item-text" href="<?php $store->the_permalink(); ?>" rel="dofollow">
						<?php esc_html_e( 'View Store', 'classima' ); ?>
                    </a>
                </div>
			<?php endif; ?>

			<?php
			if ( apply_filters( 'rt_classima_show_online_status', true ) ) {
				$status_text  = apply_filters( 'rtcl_user_offline_text', esc_html__( 'Offline Now', 'classima' ) );
				$status       = Fns::is_online( $listing->get_owner_id() );
				$status_class = $status ? 'online' : 'offline';
				if ( $status ) {
					$status_text = apply_filters( 'rtcl_user_online_text', esc_html__( 'Online Now', 'classima' ) );
				}
				?>
			<?php } ?>
			
 			
            <!--me phone design-->
              <?php if ( $phone): ?>
                            <div  class="rtin-phone"  > <img src="https://1datings.com/wp-content/uploads/2022/03/phone-1.png"alt="phone" style="width:30px; height:30px;"> 
                                <a href="tel:<?php echo( $phone);?>">
                                    <strong > <?php echo( $phone);?> </strong>
                                    </a>
                            </div>
            <?php endif; ?>
 
            <!--me whatsapp design-->
            <?php if ($whatsapp): ?>
                <div class="rtin-phone"  >
                     
                  <img src="https://1datings.com/wp-content/uploads/2022/03/wt.png" alt="whatsapp" style="width:30px; height:30px;">   
                    <strong>
                        <a href="https://api.whatsapp.com/send?phone=<?php echo($whatsapp );?>&text=1datings.com Hi, I Saw Your Ads in ! <?php the_permalink(); ?> "><?php echo($whatsapp );?></a>
                    </strong>
                    </div>
            <?php endif; ?>


            <div class="col-md-12" style="position: fixed; left: 0; bottom: 0px; width: 100%;  color: white;  text-align: center; z-index:1000;">
                <div class="col-md-6 col-sm-12 float-left  m-auto" style="padding:1px 1px 1px 1px;">
                  <?php if ($whatsapp): ?>
                        <div class="rtin-phone" style="background-color:#25d366;"  >
                             <img src="https://1datings.com/wp-content/uploads/2022/03/wt.png" alt="whatsapp" style="width:30px; height:30px;">   
                                <strong> <a href="https://api.whatsapp.com/send?phone=<?php echo($whatsapp );?>&text=1datings.com Hi, I Saw <?php the_permalink(); ?> ">Whatsapp </a></strong>
                        </div>
                 <?php endif; ?>
            
          
                 </div>
 
            <div class="col-md-6 col-sm-12 float-left m-auto" style="padding:1px 1px 1px 1px;">
             <!--me phone design-->
              <?php if ( $phone): ?>
                            <div  class="rtin-phone"  style="background-color:#ffc107;"> <img src="https://1datings.com/wp-content/uploads/2022/03/phone-1.png" alt="phone" style="width:30px; height:30px;"> 
                                <a href="tel:<?php echo( $phone);?>">
                                    <strong > Call Now </strong>
                                    </a>
                            </div>
            <?php endif; ?>
 
        </div>
 </div>

			<?php
			if ( Fns::is_enable_chat() && ( ( is_user_logged_in() && $listing->get_author_id() !== get_current_user_id() ) || ! is_user_logged_in() ) ):
				$chat_btn_class = [ 'rtcl-chat-link' ];
				$chat_url = Link::get_my_account_page_link();
				if ( is_user_logged_in() ) {
					$chat_url = '#';
					array_push( $chat_btn_class, 'rtcl-contact-seller' );
				} else {
					array_push( $chat_btn_class, 'rtcl-no-contact-seller' );
				}
				?>
                <div class="media rtin-chat">
                    <a class="<?php echo esc_attr( implode( ' ', $chat_btn_class ) ); ?>"
                       data-listing_id="<?php the_ID(); ?>" href="<?php echo esc_url( $chat_url ) ?>">
                        <i class="fa fa-comments" aria-hidden="true"></i>
						<?php esc_html_e( 'Chat', 'classima' ); ?>
                    </a>
                </div>
			<?php endif; ?>

			<?php if ( $has_contact_form && ( $email || $alternate_contact_form ) ) : ?>
                <div class="media rtin-email">
                    <a data-toggle="modal" data-target="#classima-mail-to-seller" href="#">
                        <i class="fas fa-envelope" aria-hidden="true"></i>
						<?php esc_html_e( 'Email to Seller', 'classima' ); ?>
                    </a>
                </div>

			<?php endif; ?>
		<?php } ?>

    </div>
</div>