<?php

global $store;

?>
<div class="rtin-logo">
    <?php $store->the_logo(); ?>
</div>
