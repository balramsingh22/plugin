<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Classima;
?>
<div class="main-header">
	<div class="container">
		<?php get_template_part( 'template-parts/header/part-5' ); ?>
	</div>
</div>