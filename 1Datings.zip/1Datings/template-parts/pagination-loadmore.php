<?php
/**
 * Load More Pagination Template
 * SEO-Friendly implementation with fallback pagination
 * 
 * @author  RadiusTheme
 * @version 2.0 (Load More)
 */

namespace radiustheme\Classima;

// Marker to verify template is loaded
echo '<!-- PAGINATION_LOADMORE_TEMPLATE_LOADED_SUCCESS_v2.0 -->';

global $wp_query;

$max_num_pages = isset( $max_num_pages ) ? $max_num_pages : false;

$max = $max_num_pages ? $max_num_pages : $wp_query->max_num_pages;
$max = intval( $max );

/** Stop execution if there's only 1 page */
if( $max <= 1 ) {
	return;
}

if ( get_query_var( 'paged' ) ) {
	$paged = get_query_var( 'paged' );
}
elseif ( get_query_var( 'page' ) ) {
	$paged = get_query_var( 'page' );
}
else {
	$paged = 1;
}

/**	Add current page to the array */
if ( $paged >= 1 )
	$links[] = $paged;

/**	Add the pages around the current page to the array */
if ( $paged >= 3 ) {
	$links[] = $paged - 1;
	$links[] = $paged - 2;
}

if ( ( $paged + 2 ) <= $max ) {
	$links[] = $paged + 2;
	$links[] = $paged + 1;
}

$previous_text = '<i class="fa fa-angle-double-left" aria-hidden="true"></i>' . esc_html__( 'Previous', 'classima' );
$next_text     = esc_html__( 'Next', 'classima' ) . '<i class="fa fa-angle-double-right" aria-hidden="true"></i>';

?>

<!-- Load More Button (Visible) -->
<div class="rtcl-load-more-wrapper" style="text-align: center; margin: 30px 0;">
	<?php if ( $paged < $max ): ?>
		<button 
			id="rtcl-load-more-btn" 
			class="btn btn-primary rtcl-load-more-btn"
			data-page="<?php echo esc_attr( $paged ); ?>"
			data-max-pages="<?php echo esc_attr( $max ); ?>"
			style="padding: 15px 40px; font-size: 16px; font-weight: 600; border-radius: 5px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none; color: white; cursor: pointer; transition: all 0.3s ease; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);"
			onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(102, 126, 234, 0.6)';"
			onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(102, 126, 234, 0.4)';"
		>
			<span class="load-more-text"><?php echo esc_html__( 'Load More Listings', 'classima' ); ?></span>
		</button>
		
		<!-- Page Counter -->
		<div class="rtcl-page-counter" style="margin-top: 15px; color: #666; font-size: 14px;">
			<?php printf( esc_html__( 'Showing page %d of %d', 'classima' ), $paged, $max ); ?>
		</div>
	<?php else: ?>
		<div class="rtcl-all-loaded" style="padding: 20px; background: #f0f0f0; border-radius: 5px; color: #666;">
			<i class="fa fa-check-circle" style="color: #28a745;"></i> 
			<?php echo esc_html__( 'All listings loaded', 'classima' ); ?>
		</div>
	<?php endif; ?>
</div>

<!-- SEO Fallback: Hidden Pagination for Search Engines -->
<noscript>
	<div class="rtcl-pagination pagination-area elementwidth elwidth-680 elwidth-480">
		<ul class="clearfix">
			<?php
			/**	Previous Post Link */
			$previous_posts_link = get_previous_posts_link( $previous_text );
			if ( $previous_posts_link ){
				printf( '<li class="pagi-previous">%s</li>' . "\n", $previous_posts_link );
			}
			else {
				printf( '<li class="pagi-previous disabled"><span>%s</span></li>' . "\n", $previous_text );
			}

			/**	Link to first page, plus ellipses if necessary */
			if ( ! in_array( 1, $links ) ) {
				$class = 1 == $paged ? ' class="active"' : '';

				printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );

				if ( ! in_array( 2, $links ) )
					echo '<li><span>...</span></li>';
			}

			/**	Link to current page, plus 2 pages in either direction if necessary */
			sort( $links );
			foreach ( (array) $links as $link ) {
				$class = $paged == $link ? ' class="active"' : '';
				printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
			}

			/**	Link to last page, plus ellipses if necessary */
			if ( ! in_array( $max, $links ) ) {
				if ( ! in_array( $max - 1, $links ) )
					echo '<li><span>...</span></li>' . "\n";

				$class = $paged == $max ? ' class="active"' : '';
				printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
			}

			/**	Next Post Link */
			$next_posts_link = get_next_posts_link( $next_text, $max );
			if ( $next_posts_link ){
				printf( '<li class="pagi-next">%s</li>' . "\n", $next_posts_link );
			}
			else {
				printf( '<li class="pagi-next disabled"><span>%s</span></li>' . "\n", $next_text );
			}
			?>
		</ul>
	</div>
</noscript>

<!-- SEO: Structured Data for Pagination -->
<script type="application/ld+json">
{
	"@context": "https://schema.org",
	"@type": "CollectionPage",
	"name": "<?php echo esc_js( get_the_title() ); ?>",
	"url": "<?php echo esc_url( get_pagenum_link( $paged ) ); ?>"
	<?php if ( $paged > 1 ): ?>,
	"previousPage": "<?php echo esc_url( get_pagenum_link( $paged - 1 ) ); ?>"
	<?php endif; ?>
	<?php if ( $paged < $max ): ?>,
	"nextPage": "<?php echo esc_url( get_pagenum_link( $paged + 1 ) ); ?>"
	<?php endif; ?>
}
</script>
