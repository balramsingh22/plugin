<?php
/*
Plugin Name: Number Update (States UX+Preview)
Description: Bulk updates WhatsApp/Phone for Classima listings by multiple states (searchable, preview) or city (autocomplete).
Version: 1.4
Author: Your Name
*/

if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_menu_page(
        'Number Update',
        'Number Update',
        'manage_options',
        'number-update',
        'nu_render_admin_page',
        'dashicons-update',
        58
    );
});

/* ================= Common Helpers ================= */

function nu_update_numbers_for_terms(array $term_ids, string $new_number): int {
    $term_ids = array_values(array_unique(array_map('intval', $term_ids)));
    if (!$term_ids) return 0;

    $q = new WP_Query([
        'post_type'      => 'rtcl_listing',
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'tax_query'      => [[
            'taxonomy' => 'rtcl_location',
            'field'    => 'term_id',
            'terms'    => $term_ids,
        ]],
    ]);

    $updated = 0;
    foreach ($q->posts as $post_id) {
        update_post_meta($post_id, '_rtcl_whatsapp_number', $new_number);
        update_post_meta($post_id, '_rtcl_phone', $new_number);
        update_post_meta($post_id, 'phone', $new_number);
        $updated++;
    }
    wp_reset_postdata();
    return $updated;
}

function nu_get_with_children(array $parent_ids): array {
    $all = [];
    foreach ($parent_ids as $pid) {
        $pid = (int) $pid;
        if (!$pid) continue;
        $kids = get_term_children($pid, 'rtcl_location');
        if (is_wp_error($kids)) $kids = [];
        $all = array_merge($all, $kids, [$pid]);
    }
    return array_values(array_unique(array_map('intval', $all)));
}

/* ================= Admin Assets ================= */

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'toplevel_page_number-update') return;

    wp_enqueue_script('jquery');
    wp_enqueue_script('jquery-ui-autocomplete'); // for city (from previous step)

    // Styles (tiny)
    $css = '
    .nu-wrap{max-width:980px}
    .nu-card{margin-top:20px;padding:20px;background:#fff;border:1px solid #ccd0d4;border-radius:8px}
    .nu-flex{display:flex;gap:8px;align-items:center}
    .nu-muted{color:#666}
    .nu-badge{display:inline-block;padding:0 8px;border-radius:12px;border:1px solid #ccd0d4;background:#f6f7f7;font-size:11px;margin-left:6px}
    .nu-statebox{display:flex;gap:16px}
    .nu-state-left{flex:1 1 380px}
    .nu-state-right{flex:1 1 380px}
    .nu-search{width:100%;max-width:420px}
    .nu-list{max-height:280px;overflow:auto;border:1px solid #e2e4e7;border-radius:6px;padding:8px;background:#fff}
    .nu-list label{display:flex;align-items:center;gap:8px;padding:6px;border-radius:6px}
    .nu-list label:hover{background:#f6f7f7}
    .nu-actions{display:flex;gap:8px;margin:8px 0 0}
    .ui-autocomplete{max-height:260px;overflow:auto}
    ';
    wp_add_inline_style('wp-admin', $css);

    wp_enqueue_script(
        'nu-admin-js',
        false,
        ['jquery','jquery-ui-autocomplete'],
        '1.0',
        true
    );

    // Inline JS (no external deps)
    $js = <<<JS
(function($){
  // ---------- STATES UX ----------
  var \$filter = $('#nu_state_search');
  var \$list = $('#nu_states_list');
  var \$includeChildren = $('#nu_states_include_children');
  function filterList(){
    var q = (\$filter.val() || '').toLowerCase().trim();
    \$list.find('label').each(function(){
      var name = ($(this).data('name')||'').toLowerCase();
      $(this).toggle(name.indexOf(q) !== -1);
    });
  }
  \$filter.on('input', filterList);

  $('#nu_states_select_all').on('click', function(){ \$list.find('input[type=checkbox]:visible').prop('checked', true); });
  $('#nu_states_select_none').on('click', function(){ \$list.find('input[type=checkbox]').prop('checked', false); });
  $('#nu_states_invert').on('click', function(){
    \$list.find('input[type=checkbox]:visible').each(function(){ $(this).prop('checked', !$(this).prop('checked')); });
  });

  // Preview impacted listings
  $('#nu_states_preview').on('click', function(e){
    e.preventDefault();
    var ids = [];
    \$list.find('input[type=checkbox]:checked').each(function(){ ids.push($(this).val()); });
    if(!ids.length){ alert('Please select at least one state.'); return; }
    var btn = $(this);
    btn.prop('disabled', true).text('Checking…');
    $.post(ajaxurl, {
      action: 'nu_preview_states',
      nonce: $('#nu_states_nonce').val(),
      states: ids,
      include_children: \$includeChildren.is(':checked') ? 1 : 0
    }).done(function(res){
      if(res && res.success){
        alert('Estimated impacted listings: ' + (res.data.count || 0));
      } else {
        alert('Preview failed');
      }
    }).fail(function(){ alert('Preview failed'); })
      .always(function(){ btn.prop('disabled', false).text('Preview impact'); });
  });

  // If include children toggled OFF, we still send selected parents only (no auto children)
  // Server will handle accordingly.

  // ---------- CITY AUTOCOMPLETE (from previous version) ----------
  var \$cityInput = $('#nu_city_search');
  var \$cityHidden = $('#nu_city');
  var \$cityHint = $('#nu_city_selected_hint');
  var \$cityClear = $('#nu_city_clear');
  var \$cityStateFilter = $('#nu_city_state_filter');

  function setCitySelected(item){
    if(item && item.id){
      \$cityHidden.val(item.id);
      \$cityInput.val(item.text);
      \$cityHint.text('Selected: ' + item.text);
    } else {
      \$cityHidden.val('');
      \$cityHint.text('');
    }
  }

  \$cityClear.on('click', function(){
    setCitySelected(null);
    \$cityInput.val('').focus();
  });

  function citySource(req, resp){
    $.ajax({
      url: ajaxurl,
      data: {
        action: 'nu_search_locations',
        nonce: $('#nu_city_nonce').val(),
        q: req.term || '',
        limit: 20,
        state: \$cityStateFilter.val() || ''
      },
      dataType: 'json'
    }).done(function(data){
      if(!data || !data.success){ resp([]); return; }
      var items = (data.data && data.data.items) ? data.data.items : [];
      if(!items.length){
        resp([{label: 'No matches', value: '', id: ''}]);
        return;
      }
      resp(items.map(function(it){ return { label: it.text, value: it.text, id: it.id, text: it.text }; }));
    }).fail(function(){ resp([]); });
  }

  \$cityInput.autocomplete({
    minLength: 2,
    delay: 150,
    source: citySource,
    select: function(e, ui){ if(ui.item && ui.item.id){ setCitySelected(ui.item); } e.preventDefault(); },
    focus: function(e){ e.preventDefault(); }
  });

  \$cityStateFilter.on('change', function(){ setCitySelected(null); \$cityInput.val('').focus(); });

})(jQuery);
JS;
    wp_add_inline_script('nu-admin-js', $js);

    // Nonces for AJAX
    wp_localize_script('nu-admin-js', 'NU_NONCES', [
        'states' => wp_create_nonce('nu_states_preview'),
        'city'   => wp_create_nonce('nu_city_search'),
    ]);
});

/* ================= AJAX: States Preview ================= */

add_action('wp_ajax_nu_preview_states', function () {
    if (!current_user_can('manage_options')) wp_send_json_error('forbidden', 403);
    check_ajax_referer('nu_states_preview', 'nonce');

    $states = array_map('intval', (array)($_POST['states'] ?? []));
    $include_children = !empty($_POST['include_children']);

    if (!$states) wp_send_json_success(['count' => 0]);

    $term_ids = $include_children ? nu_get_with_children($states) : array_values(array_unique($states));

    $q = new WP_Query([
        'post_type'      => 'rtcl_listing',
        'posts_per_page' => 1,
        'fields'         => 'ids',
        'no_found_rows'  => false, // we need found_posts for count estimate
        'tax_query'      => [[
            'taxonomy' => 'rtcl_location',
            'field'    => 'term_id',
            'terms'    => $term_ids,
        ]],
    ]);

    $count = (int) $q->found_posts;
    wp_reset_postdata();

    wp_send_json_success(['count' => $count]);
});

/* ================= AJAX: City Search (unchanged) ================= */

add_action('wp_ajax_nu_search_locations', function () {
    if (!current_user_can('manage_options')) wp_send_json_error('forbidden', 403);
    $nonce = $_GET['nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'nu_city_search')) wp_send_json_error('bad_nonce', 403);

    $s        = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
    $limit    = min(50, max(1, (int)($_GET['limit'] ?? 20)));
    $state_id = (int) ($_GET['state'] ?? 0);

    if ($s === '') wp_send_json_success(['items' => []]);

    $terms = get_terms([
        'taxonomy'   => 'rtcl_location',
        'hide_empty' => false,
        'number'     => $limit,
        'name__like' => $s,
        'orderby'    => 'name',
        'order'      => 'ASC',
    ]);
    if (is_wp_error($terms)) wp_send_json_success(['items' => []]);

    if ($state_id) {
        $filtered = [];
        foreach ($terms as $t) {
            $anc = get_ancestors($t->term_id, 'rtcl_location', 'taxonomy');
            $branch = array_merge([$t->term_id], $anc);
            if (in_array($state_id, $branch, true)) $filtered[] = $t;
        }
        $terms = $filtered;
    }

    $items = [];
    foreach ($terms as $t) {
        $chain = [$t->name];
        $p = $t;
        while ($p->parent) {
            $p = get_term($p->parent, 'rtcl_location');
            if (is_wp_error($p) || !$p || empty($p->term_id)) break;
            array_unshift($chain, $p->name);
            if ($p->parent === 0) break;
        }
        $label = implode(' » ', $chain);
        $items[] = ['id' => $t->term_id, 'text' => $label];
    }

    wp_send_json_success(['items' => $items]);
});

/* ================= Admin Page ================= */

function nu_render_admin_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'nu'));
    }

    // Form handlers
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        // States bulk
        if (isset($_POST['nu_update_states'])) {
            check_admin_referer('nu_states_action', 'nu_states_nonce');

            $states           = array_map('intval', (array)($_POST['nu_states'] ?? []));
            $new_number       = sanitize_text_field($_POST['nu_new_number_states'] ?? '');
            $include_children = !empty($_POST['nu_states_include_children']);

            if ($states && $new_number !== '') {
                $terms = $include_children ? nu_get_with_children($states) : array_values(array_unique($states));
                $count = nu_update_numbers_for_terms($terms, $new_number);
                echo '<div class="updated notice"><p><strong>' . esc_html($count) . ' listing(s) updated from selected state(s)!</strong></p></div>';
            } else {
                echo '<div class="error notice"><p>Please select at least one state and enter a number.</p></div>';
            }
        }

        // City update
        if (isset($_POST['nu_update_city'])) {
            check_admin_referer('nu_city_action', 'nu_city_nonce');

            $city_id          = (int) ($_POST['nu_city'] ?? 0);
            $include_children = !empty($_POST['nu_city_children']);
            $new_number       = sanitize_text_field($_POST['nu_new_number_city'] ?? '');

            if ($city_id && $new_number !== '') {
                $term_ids = [$city_id];
                if ($include_children) {
                    $kids = get_term_children($city_id, 'rtcl_location');
                    if (!is_wp_error($kids) && $kids) $term_ids = array_merge($term_ids, $kids);
                }
                $term_ids = array_values(array_unique(array_map('intval', $term_ids)));
                $count = nu_update_numbers_for_terms($term_ids, $new_number);

                echo '<div class="updated notice"><p><strong>' . esc_html($count) . ' listing(s) updated for the selected city' . ($include_children ? ' (with children)' : '') . '!</strong></p></div>';
            } else {
                echo '<div class="error notice"><p>Please select a city and enter a number.</p></div>';
            }
        }
    }

    // Top-level states (with counts padded by children — best-effort)
    $states = get_terms([
        'taxonomy'   => 'rtcl_location',
        'hide_empty' => false,
        'parent'     => 0,
        'pad_counts' => true,
        'orderby'    => 'name',
        'order'      => 'ASC',
    ]);

    ?>
    <div class="wrap nu-wrap">
        <h1>Bulk Update WhatsApp &amp; Phone Numbers</h1>

        <!-- 1) STATES (Searchable + Preview) -->
        <div class="nu-card">
            <h2>1) Update by Multiple States</h2>
            <p class="nu-muted">Quick filter, multi-select, and preview the impact before updating. By default we include child locations.</p>
            <form method="post">
                <?php wp_nonce_field('nu_states_action', 'nu_states_nonce'); ?>
                <input type="hidden" id="nu_states_nonce" value="<?php echo esc_attr( wp_create_nonce('nu_states_preview') ); ?>">

                <div class="nu-statebox">
                    <div class="nu-state-left">
                        <input id="nu_state_search" class="nu-search" type="search" placeholder="Search states..." />
                        <div id="nu_states_list" class="nu-list" aria-label="States">
                            <?php
                            if (!empty($states) && !is_wp_error($states)) :
                                foreach ($states as $st):
                                    $count = (int) ($st->count ?? 0);
                                    ?>
                                    <label data-name="<?php echo esc_attr($st->name); ?>">
                                        <input type="checkbox" name="nu_states[]" value="<?php echo esc_attr($st->term_id); ?>">
                                        <span><?php echo esc_html($st->name); ?></span>
                                        <span class="nu-badge"><?php echo number_format_i18n($count); ?></span>
                                    </label>
                                <?php endforeach;
                            else: ?>
                                <em>No states found.</em>
                            <?php endif; ?>
                        </div>
                        <div class="nu-actions">
                            <button type="button" class="button" id="nu_states_select_all">Select All</button>
                            <button type="button" class="button" id="nu_states_select_none">None</button>
                            <button type="button" class="button" id="nu_states_invert">Invert</button>
                            <label style="margin-left:auto;">
                                <input type="checkbox" id="nu_states_include_children" name="nu_states_include_children" checked>
                                Include child locations
                            </label>
                        </div>
                    </div>

                    <div class="nu-state-right">
                        <table class="form-table" role="presentation">
                            <tr>
                                <th scope="row"><label for="nu_new_number_states">New Number</label></th>
                                <td><input type="text" id="nu_new_number_states" name="nu_new_number_states" required style="min-width:320px;"></td>
                            </tr>
                        </table>
                        <div class="nu-flex" style="margin-top:8px;">
                            <button class="button" id="nu_states_preview">Preview impact</button>
                            <?php submit_button('Bulk Update (States)', 'primary', 'nu_update_states', false); ?>
                        </div>
                        <p class="nu-muted" style="margin-top:6px;">Badge shows approximate post count on that state (may vary by configuration).</p>
                    </div>
                </div>
            </form>
        </div>

        <!-- 2) CITY (Autocomplete – as before) -->
        <div class="nu-card">
            <h2>2) Update by City (Search)</h2>
            <form method="post">
                <?php wp_nonce_field('nu_city_action', 'nu_city_nonce', true, true); ?>
                <input type="hidden" id="nu_city_nonce" value="<?php echo esc_attr( wp_create_nonce('nu_city_search') ); ?>">
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="nu_city_state_filter">Filter by State (optional)</label></th>
                        <td>
                            <select id="nu_city_state_filter" name="nu_city_state_filter" style="min-width:320px;">
                                <option value="">— All States —</option>
                                <?php if (!empty($states) && !is_wp_error($states)): foreach ($states as $state): ?>
                                    <option value="<?php echo esc_attr($state->term_id); ?>"><?php echo esc_html($state->name); ?></option>
                                <?php endforeach; endif; ?>
                            </select>
                            <p class="nu-muted">Narrows search to a specific state branch.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="nu_city_search">City / Location</label></th>
                        <td>
                            <div class="nu-flex">
                                <input type="text" id="nu_city_search" class="regular-text" placeholder="Type to search city/location…" autocomplete="off" style="min-width:420px;">
                                <button type="button" class="button" id="nu_city_clear">Clear</button>
                            </div>
                            <input type="hidden" id="nu_city" name="nu_city" value="">
                            <p class="nu-muted" id="nu_city_selected_hint"></p>
                            <p><label><input type="checkbox" name="nu_city_children" value="1"> Include child locations</label></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="nu_new_number_city">New Number</label></th>
                        <td><input type="text" id="nu_new_number_city" name="nu_new_number_city" required style="min-width:320px;"></td>
                    </tr>
                </table>
                <?php submit_button('Update (City)', 'secondary', 'nu_update_city'); ?>
            </form>
        </div>

        <p class="nu-muted" style="margin-top:24px">
            Updates meta keys: <code>_rtcl_whatsapp_number</code>, <code>_rtcl_phone</code>, <code>phone</code>.
        </p>
    </div>
    <?php
}
